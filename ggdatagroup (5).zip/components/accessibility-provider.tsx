"use client"

import type React from "react"
import { createContext, useContext, useState, useEffect } from "react"

type AccessibilityOptions = {
  highContrast: boolean
  largeText: boolean
  reducedMotion: boolean
  screenReaderOptimized: boolean
}

type AccessibilityContextType = {
  options: AccessibilityOptions
  toggleHighContrast: () => void
  toggleLargeText: () => void
  toggleReducedMotion: () => void
  toggleScreenReaderOptimized: () => void
  resetOptions: () => void
}

const defaultOptions: AccessibilityOptions = {
  highContrast: false,
  largeText: false,
  reducedMotion: false,
  screenReaderOptimized: false,
}

const AccessibilityContext = createContext<AccessibilityContextType | undefined>(undefined)

export function AccessibilityProvider({ children }: { children: React.ReactNode }) {
  const [options, setOptions] = useState<AccessibilityOptions>(defaultOptions)

  // Load saved preferences on mount
  useEffect(() => {
    const savedOptions = localStorage.getItem("accessibility-options")
    if (savedOptions) {
      try {
        setOptions(JSON.parse(savedOptions))
      } catch (error) {
        console.error("Failed to parse saved accessibility options:", error)
      }
    }

    // Check for prefers-reduced-motion
    const prefersReducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches
    if (prefersReducedMotion) {
      setOptions((prev) => ({ ...prev, reducedMotion: true }))
    }
  }, [])

  // Apply classes to document based on options
  useEffect(() => {
    // Save options to localStorage
    localStorage.setItem("accessibility-options", JSON.stringify(options))

    // Apply classes to document
    const { highContrast, largeText, reducedMotion, screenReaderOptimized } = options

    if (highContrast) {
      document.documentElement.classList.add("high-contrast")
    } else {
      document.documentElement.classList.remove("high-contrast")
    }

    if (largeText) {
      document.documentElement.classList.add("large-text")
    } else {
      document.documentElement.classList.remove("large-text")
    }

    if (reducedMotion) {
      document.documentElement.classList.add("reduced-motion")
    } else {
      document.documentElement.classList.remove("reduced-motion")
    }

    if (screenReaderOptimized) {
      document.documentElement.classList.add("screen-reader-optimized")
    } else {
      document.documentElement.classList.remove("screen-reader-optimized")
    }
  }, [options])

  const toggleHighContrast = () => {
    setOptions((prev) => ({ ...prev, highContrast: !prev.highContrast }))
  }

  const toggleLargeText = () => {
    setOptions((prev) => ({ ...prev, largeText: !prev.largeText }))
  }

  const toggleReducedMotion = () => {
    setOptions((prev) => ({ ...prev, reducedMotion: !prev.reducedMotion }))
  }

  const toggleScreenReaderOptimized = () => {
    setOptions((prev) => ({ ...prev, screenReaderOptimized: !prev.screenReaderOptimized }))
  }

  const resetOptions = () => {
    setOptions(defaultOptions)
  }

  return (
    <AccessibilityContext.Provider
      value={{
        options,
        toggleHighContrast,
        toggleLargeText,
        toggleReducedMotion,
        toggleScreenReaderOptimized,
        resetOptions,
      }}
    >
      {children}
    </AccessibilityContext.Provider>
  )
}

export function useAccessibility() {
  const context = useContext(AccessibilityContext)
  if (context === undefined) {
    throw new Error("useAccessibility must be used within an AccessibilityProvider")
  }
  return context
}

