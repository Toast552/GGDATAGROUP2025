"use client"

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { MoreHorizontal, Mail, Phone, UserPlus } from "lucide-react"

const teamMembers = [
  {
    id: 1,
    name: "John Doe",
    email: "john@example.com",
    role: "Admin",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "JD",
    status: "active",
  },
  {
    id: 2,
    name: "Jane Smith",
    email: "jane@example.com",
    role: "Manager",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "JS",
    status: "active",
  },
  {
    id: 3,
    name: "Robert Johnson",
    email: "robert@example.com",
    role: "Developer",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "RJ",
    status: "active",
  },
  {
    id: 4,
    name: "Emily Davis",
    email: "emily@example.com",
    role: "Designer",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "ED",
    status: "inactive",
  },
  {
    id: 5,
    name: "Michael Wilson",
    email: "michael@example.com",
    role: "Developer",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "MW",
    status: "active",
  },
]

export function TeamMembers() {
  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-medium">Team Members</h3>
        <Button size="sm">
          <UserPlus className="h-4 w-4 mr-2" />
          Add Member
        </Button>
      </div>
      <div className="border rounded-md">
        <div className="grid grid-cols-5 p-4 text-sm font-medium border-b">
          <div className="col-span-2">Name</div>
          <div>Role</div>
          <div>Status</div>
          <div className="text-right">Actions</div>
        </div>
        <div className="divide-y">
          {teamMembers.map((member) => (
            <div key={member.id} className="grid grid-cols-5 p-4 text-sm items-center">
              <div className="col-span-2 flex items-center gap-3">
                <Avatar>
                  <AvatarImage src={member.avatar} alt={member.name} />
                  <AvatarFallback>{member.initials}</AvatarFallback>
                </Avatar>
                <div>
                  <div className="font-medium">{member.name}</div>
                  <div className="text-muted-foreground">{member.email}</div>
                </div>
              </div>
              <div>{member.role}</div>
              <div>
                <span
                  className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ${
                    member.status === "active"
                      ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"
                      : "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300"
                  }`}
                >
                  {member.status === "active" ? "Active" : "Inactive"}
                </span>
              </div>
              <div className="text-right">
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon">
                      <MoreHorizontal className="h-4 w-4" />
                      <span className="sr-only">Actions</span>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuLabel>Actions</DropdownMenuLabel>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem>
                      <Mail className="mr-2 h-4 w-4" />
                      <span>Email</span>
                    </DropdownMenuItem>
                    <DropdownMenuItem>
                      <Phone className="mr-2 h-4 w-4" />
                      <span>Call</span>
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem className="text-destructive">Remove</DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

