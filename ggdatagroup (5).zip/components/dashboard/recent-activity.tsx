"use client"

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

const activities = [
  {
    id: 1,
    user: {
      name: "John Doe",
      email: "john@example.com",
      avatar: "/placeholder.svg?height=32&width=32",
      initials: "JD",
    },
    action: "purchased",
    item: "Premium Plan",
    amount: "$79.00",
    date: "2 hours ago",
  },
  {
    id: 2,
    user: {
      name: "Jane Smith",
      email: "jane@example.com",
      avatar: "/placeholder.svg?height=32&width=32",
      initials: "JS",
    },
    action: "upgraded to",
    item: "Enterprise Plan",
    amount: "$199.00",
    date: "5 hours ago",
  },
  {
    id: 3,
    user: {
      name: "Robert Johnson",
      email: "robert@example.com",
      avatar: "/placeholder.svg?height=32&width=32",
      initials: "RJ",
    },
    action: "renewed",
    item: "Professional Plan",
    amount: "$79.00",
    date: "1 day ago",
  },
  {
    id: 4,
    user: {
      name: "Emily Davis",
      email: "emily@example.com",
      avatar: "/placeholder.svg?height=32&width=32",
      initials: "ED",
    },
    action: "purchased",
    item: "Starter Plan",
    amount: "$29.00",
    date: "2 days ago",
  },
  {
    id: 5,
    user: {
      name: "Michael Wilson",
      email: "michael@example.com",
      avatar: "/placeholder.svg?height=32&width=32",
      initials: "MW",
    },
    action: "upgraded to",
    item: "Professional Plan",
    amount: "$79.00",
    date: "3 days ago",
  },
]

export function RecentActivity() {
  return (
    <div className="space-y-8">
      {activities.map((activity) => (
        <div key={activity.id} className="flex items-center">
          <Avatar className="h-9 w-9">
            <AvatarImage src={activity.user.avatar} alt={activity.user.name} />
            <AvatarFallback>{activity.user.initials}</AvatarFallback>
          </Avatar>
          <div className="ml-4 space-y-1">
            <p className="text-sm font-medium leading-none">{activity.user.name}</p>
            <p className="text-sm text-muted-foreground">
              {activity.action} {activity.item}
            </p>
          </div>
          <div className="ml-auto text-right">
            <p className="text-sm font-medium">{activity.amount}</p>
            <p className="text-sm text-muted-foreground">{activity.date}</p>
          </div>
        </div>
      ))}
    </div>
  )
}

