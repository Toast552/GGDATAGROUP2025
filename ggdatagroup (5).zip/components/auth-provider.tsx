"use client"

import type React from "react"
import { createContext, useContext, useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { trackFeatureUsage } from "@/components/analytics-tracker"
import { logSecurityEvent } from "@/lib/security-utils"

// Define user interface
export interface User {
  id: string
  name: string
  email: string
  role: "user" | "admin"
}

// Define auth context
interface AuthContextType {
  user: User | null
  isAuthenticated: boolean
  isLoading: boolean
  login: (email: string, password: string) => Promise<{ success: boolean; message: string }>
  logout: () => void
  register: (name: string, email: string, password: string) => Promise<{ success: boolean; message: string }>
}

// Create auth context
const AuthContext = createContext<AuthContextType | undefined>(undefined)

// Mock users for demo
const mockUsers: User[] = [
  {
    id: "1",
    name: "Admin User",
    email: "admin@example.com",
    role: "admin",
  },
  {
    id: "2",
    name: "Test User",
    email: "user@example.com",
    role: "user",
  },
]

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const router = useRouter()

  // Check if user is logged in on mount
  useEffect(() => {
    const checkAuth = async () => {
      try {
        // In a real app, this would be an API call to validate the token
        const storedUser = localStorage.getItem("user")
        if (storedUser) {
          const parsedUser = JSON.parse(storedUser) as User
          setUser(parsedUser)

          // Log security event for successful authentication
          logSecurityEvent({
            type: "authentication",
            message: "User authenticated from stored credentials",
            data: { userId: parsedUser.id, userEmail: parsedUser.email },
            severity: "low",
          })

          // Track user login
          trackFeatureUsage("user_authenticated", {
            userRole: parsedUser.role,
            method: "stored_credentials",
          })
        }
      } catch (error) {
        console.error("Auth check failed:", error)
        localStorage.removeItem("user")
      } finally {
        setIsLoading(false)
      }
    }

    checkAuth()
  }, [])

  // Login function
  const login = async (email: string, password: string): Promise<{ success: boolean; message: string }> => {
    setIsLoading(true)

    try {
      // In a real app, this would be an API call to authenticate
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // Find user by email (mock authentication)
      const foundUser = mockUsers.find((u) => u.email === email)

      if (foundUser && password === "password") {
        // Set user in state and localStorage
        setUser(foundUser)
        localStorage.setItem("user", JSON.stringify(foundUser))

        // Log security event for successful login
        logSecurityEvent({
          type: "authentication",
          message: "User logged in successfully",
          data: { userId: foundUser.id, userEmail: foundUser.email },
          severity: "low",
        })

        // Track user login
        trackFeatureUsage("user_login", {
          userRole: foundUser.role,
          method: "credentials",
        })

        setIsLoading(false)
        return { success: true, message: "Login successful" }
      }

      // Log security event for failed login
      logSecurityEvent({
        type: "authentication_failure",
        message: "Failed login attempt",
        data: { attemptedEmail: email },
        severity: "medium",
      })

      // Track failed login
      trackFeatureUsage("login_failure")

      setIsLoading(false)
      return { success: false, message: "Invalid email or password" }
    } catch (error) {
      console.error("Login failed:", error)

      // Log security event for login error
      logSecurityEvent({
        type: "authentication_error",
        message: "Login process error",
        data: { error: error instanceof Error ? error.message : "Unknown error" },
        severity: "medium",
      })

      setIsLoading(false)
      return { success: false, message: "An error occurred during login" }
    }
  }

  // Logout function
  const logout = () => {
    // In a real app, this would also invalidate the token on the server
    localStorage.removeItem("user")
    setUser(null)

    // Log security event for logout
    if (user) {
      logSecurityEvent({
        type: "authentication",
        message: "User logged out",
        data: { userId: user.id, userEmail: user.email },
        severity: "low",
      })

      // Track user logout
      trackFeatureUsage("user_logout", { userRole: user.role })
    }

    router.push("/")
  }

  // Register function
  const register = async (
    name: string,
    email: string,
    password: string,
  ): Promise<{ success: boolean; message: string }> => {
    setIsLoading(true)

    try {
      // In a real app, this would be an API call to register
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // Check if user already exists
      const existingUser = mockUsers.find((u) => u.email === email)
      if (existingUser) {
        setIsLoading(false)
        return { success: false, message: "Email already in use" }
      }

      // Create new user (in a real app, this would be saved to the database)
      const newUser: User = {
        id: Math.random().toString(36).substring(2, 15),
        name,
        email,
        role: "user",
      }

      // Add to mock users (this is just for demo purposes)
      mockUsers.push(newUser)

      // Set user in state and localStorage
      setUser(newUser)
      localStorage.setItem("user", JSON.stringify(newUser))

      // Log security event for registration
      logSecurityEvent({
        type: "user_registration",
        message: "New user registered",
        data: { userId: newUser.id, userEmail: newUser.email },
        severity: "low",
      })

      // Track user registration
      trackFeatureUsage("user_registration")

      setIsLoading(false)
      return { success: true, message: "Registration successful" }
    } catch (error) {
      console.error("Registration failed:", error)

      // Log security event for registration error
      logSecurityEvent({
        type: "registration_error",
        message: "Registration process error",
        data: { error: error instanceof Error ? error.message : "Unknown error" },
        severity: "medium",
      })

      setIsLoading(false)
      return { success: false, message: "An error occurred during registration" }
    }
  }

  const value = {
    user,
    isAuthenticated: !!user,
    isLoading,
    login,
    logout,
    register,
  }

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

// Custom hook to use the auth context
export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}

