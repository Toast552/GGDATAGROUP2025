"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { AlertCircle, CheckCircle, Loader2 } from "lucide-react"
import { useLanguage } from "@/components/language-provider"
import {
  sanitizeInput,
  ValidationRules,
  validateFormData,
  initCSRFProtection,
  checkRateLimit,
  logSecurityEvent,
} from "@/lib/security-utils"
import { Checkbox } from "@/components/ui/checkbox"
import { trackFormSubmission, trackError } from "@/components/analytics-tracker"

export function SecureContactForm() {
  const [name, setName] = useState("")
  const [email, setEmail] = useState("")
  const [message, setMessage] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [isSuccess, setIsSuccess] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [validationErrors, setValidationErrors] = useState<Record<string, string>>({})
  const [csrfToken, setCsrfToken] = useState<string>("")
  const [acceptTerms, setAcceptTerms] = useState(false)
  const { t } = useLanguage()

  // Initialize CSRF protection
  useEffect(() => {
    const token = initCSRFProtection()
    setCsrfToken(token)
  }, [])

  const validateForm = () => {
    // Define validation rules
    const rules = {
      name: [
        ValidationRules.required("Name"),
        ValidationRules.minLength("Name", 2),
        ValidationRules.maxLength("Name", 50),
      ],
      email: [ValidationRules.required("Email"), ValidationRules.email("Email")],
      message: [
        ValidationRules.required("Message"),
        ValidationRules.minLength("Message", 10),
        ValidationRules.maxLength("Message", 1000),
      ],
      terms: [(value: string) => (!acceptTerms ? "You must accept the terms and conditions" : null)],
    }

    // Validate form data
    const errors = validateFormData({ name, email, message, terms: acceptTerms ? "accepted" : "" }, rules)

    // Set validation errors
    const errorMessages: Record<string, string> = {}
    for (const [field, error] of Object.entries(errors)) {
      if (error) {
        errorMessages[field] = error
      }
    }

    setValidationErrors(errorMessages)
    return Object.keys(errorMessages).length === 0
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)
    setIsSuccess(false)

    // Check for rate limiting (5 submissions per minute)
    const clientId = localStorage.getItem("client_id") || "anonymous"
    const isRateLimited = checkRateLimit(`contact_form:${clientId}`, 5, 60000)

    if (isRateLimited) {
      setError("Too many submissions. Please try again later.")
      logSecurityEvent({
        type: "rate_limit",
        message: "Contact form rate limit exceeded",
        data: { clientId, form: "contact" },
        severity: "medium",
      })
      trackError("rate_limit", "Contact form rate limit exceeded", { form: "contact" })
      return
    }

    // Validate form  'Contact form rate limit exceeded', { form: 'contact' });
    return
  }

  // Validate form
  if (!validateForm()) {
    trackError("validation_error", "Contact form validation failed", {
      form: "contact",
      errors: validationErrors,
    })
    return
  }

  setIsLoading(true)

  try {
    // Sanitize form data
    const sanitizedName = sanitizeInput(name)
    const sanitizedEmail = sanitizeInput(email)
    const sanitizedMessage = sanitizeInput(message)

    // Create form data with CSRF token
    const formData = new FormData()
    formData.append("name", sanitizedName)
    formData.append("email", sanitizedEmail)
    formData.append("message", sanitizedMessage)
    formData.append("csrf_token", csrfToken)

    // In a real app, this would be an API call to send the message
    await new Promise((resolve) => setTimeout(resolve, 1500))

    // Track successful submission
    trackFormSubmission("contact", {
      success: true,
      form_length: sanitizedMessage.length,
    })

    // Simulate successful submission
    setIsSuccess(true)
    setName("")
    setEmail("")
    setMessage("")
    setAcceptTerms(false)

    // Reset success message after 5 seconds
    setTimeout(() => {
      setIsSuccess(false)
    }, 5000)
  } catch (err) {
    setError(t("contact.error"))
    console.error("Error submitting form:", err)

    // Track error
    trackError("submission_error", "Contact form submission failed", {
      form: "contact",
      error: err instanceof Error ? err.message : "Unknown error",
    })

    // Log security event
    logSecurityEvent({
      type: "form_error",
      message: "Contact form submission failed",
      data: { error: err instanceof Error ? err.message : "Unknown error" },
      severity: "low",
    })
  } finally {
    setIsLoading(false)
  }
}

return (
    <Card>
      <CardHeader>
        <CardTitle>{t("contact.title")}</CardTitle>
        <CardDescription>{t("contact.subtitle")}</CardDescription>
      </CardHeader>
      <CardContent>
        {error && (
          <Alert variant="destructive" className="mb-4">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}
        {isSuccess && (
          <Alert className="mb-4 bg-green-50 text-green-800 dark:bg-green-900/20 dark:text-green-400">
            <CheckCircle className="h-4 w-4" />
            <AlertDescription>{t("contact.success")}</AlertDescription>
          </Alert>
        )}
        <form onSubmit={handleSubmit} className="space-y-4">
          <input type="hidden" name="csrf_token" value={csrfToken} />

          <div className="space-y-2">
            <Label htmlFor="name">{t("contact.name")}</Label>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className={validationErrors.name ? "border-red-500" : ""}
              aria-invalid={validationErrors.name ? "true" : "false"}
            />
            {validationErrors.name && <p className="text-sm text-red-500">{validationErrors.name}</p>}
          </div>

          <div className="space-y-2">
            <Label htmlFor="email">{t("contact.email")}</Label>
            <Input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className={validationErrors.email ? "border-red-500" : ""}
              aria-invalid={validationErrors.email ? "true" : "false"}
            />
            {validationErrors.email && <p className="text-sm text-red-500">{validationErrors.email}</p>}
          </div>

          <div className="space-y-2">
            <Label htmlFor="message">{t("contact.message")}</Label>
            <Textarea
              id="message"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              className={`min-h-[120px] ${validationErrors.message ? "border-red-500" : ""}`}
              aria-invalid={validationErrors.message ? "true" : "false"}
            />
            {validationErrors.message && <p className="text-sm text-red-500">{validationErrors.message}</p>}
          </div>

          <div className="flex items-center space-x-2">
            <Checkbox
              id="terms"
              checked={acceptTerms}
              onCheckedChange={(checked) => setAcceptTerms(checked as boolean)}
            />
            <label
              htmlFor="terms"
              className={`text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 ${
                validationErrors.terms ? "text-red-500" : ""
              }`}
            >
              I accept the terms and conditions and privacy policy
            </label>
          </div>
          {validationErrors.terms && <p className="text-sm text-red-500">{validationErrors.terms}</p>}
        </form>
      </CardContent>
      <CardFooter>
        <Button onClick={handleSubmit} disabled={isLoading} className="w-full">
          {isLoading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Sending...
            </>
          ) : (
            t("contact.submit")
          )}
        </Button>
      </CardFooter>
    </Card>
  );
}

