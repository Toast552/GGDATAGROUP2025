"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"

// Define available languages
export type Language = "en" | "es" | "fr" | "de" | "zh" | "ja"

// Define translation structure
interface Translations {
  [key: string]: {
    [key: string]: string
  }
}

// Define language context
interface LanguageContextType {
  language: Language
  setLanguage: (language: Language) => void
  t: (key: string) => string
}

// Create context
const LanguageContext = createContext<LanguageContextType | undefined>(undefined)

// Translations
const translations: Translations = {
  en: {
    "common.services": "Services",
    "common.contact": "Contact",
    "common.login": "Log In",
    "common.signup": "Sign Up",
    "common.search": "Search",
    "common.language": "Language",
    "common.typeMessage": "Type a message...",
    "footer.copyright": "All rights reserved.",
    "footer.privacyPolicy": "Privacy Policy",
    "footer.termsOfService": "Terms of Service",
    "footer.contactUs": "Contact Us",
    "services.marketData.title": "Market Data",
    "services.analytics.title": "Analytics",
    "services.infrastructure.title": "Infrastructure",
    "services.security.title": "Security",
    "services.global.title": "Global Coverage",
  },
  es: {
    "common.services": "Servicios",
    "common.contact": "Contacto",
    "common.login": "Iniciar Sesión",
    "common.signup": "Registrarse",
    "common.search": "Buscar",
    "common.language": "Idioma",
    "common.typeMessage": "Escribe un mensaje...",
    "footer.copyright": "Todos los derechos reservados.",
    "footer.privacyPolicy": "Política de Privacidad",
    "footer.termsOfService": "Términos de Servicio",
    "footer.contactUs": "Contáctenos",
    "services.marketData.title": "Datos de Mercado",
    "services.analytics.title": "Analítica",
    "services.infrastructure.title": "Infraestructura",
    "services.security.title": "Seguridad",
    "services.global.title": "Cobertura Global",
  },
  fr: {
    "common.services": "Services",
    "common.contact": "Contact",
    "common.login": "Connexion",
    "common.signup": "S'inscrire",
    "common.search": "Rechercher",
    "common.language": "Langue",
    "common.typeMessage": "Tapez un message...",
    "footer.copyright": "Tous droits réservés.",
    "footer.privacyPolicy": "Politique de Confidentialité",
    "footer.termsOfService": "Conditions d'Utilisation",
    "footer.contactUs": "Contactez-nous",
    "services.marketData.title": "Données de Marché",
    "services.analytics.title": "Analytique",
    "services.infrastructure.title": "Infrastructure",
    "services.security.title": "Sécurité",
    "services.global.title": "Couverture Mondiale",
  },
  de: {
    "common.services": "Dienstleistungen",
    "common.contact": "Kontakt",
    "common.login": "Anmelden",
    "common.signup": "Registrieren",
    "common.search": "Suchen",
    "common.language": "Sprache",
    "common.typeMessage": "Nachricht eingeben...",
    "footer.copyright": "Alle Rechte vorbehalten.",
    "footer.privacyPolicy": "Datenschutzrichtlinie",
    "footer.termsOfService": "Nutzungsbedingungen",
    "footer.contactUs": "Kontaktieren Sie uns",
    "services.marketData.title": "Marktdaten",
    "services.analytics.title": "Analytik",
    "services.infrastructure.title": "Infrastruktur",
    "services.security.title": "Sicherheit",
    "services.global.title": "Globale Abdeckung",
  },
  zh: {
    "common.services": "服务",
    "common.contact": "联系我们",
    "common.login": "登录",
    "common.signup": "注册",
    "common.search": "搜索",
    "common.language": "语言",
    "common.typeMessage": "输入消息...",
    "footer.copyright": "版权所有。",
    "footer.privacyPolicy": "隐私政策",
    "footer.termsOfService": "服务条款",
    "footer.contactUs": "联系我们",
    "services.marketData.title": "市场数据",
    "services.analytics.title": "分析",
    "services.infrastructure.title": "基础设施",
    "services.security.title": "安全",
    "services.global.title": "全球覆盖",
  },
  ja: {
    "common.services": "サービス",
    "common.contact": "お問い合わせ",
    "common.login": "ログイン",
    "common.signup": "登録",
    "common.search": "検索",
    "common.language": "言語",
    "common.typeMessage": "メッセージを入力...",
    "footer.copyright": "全著作権所有。",
    "footer.privacyPolicy": "プライバシーポリシー",
    "footer.termsOfService": "利用規約",
    "footer.contactUs": "お問い合わせ",
    "services.marketData.title": "市場データ",
    "services.analytics.title": "分析",
    "services.infrastructure.title": "インフラストラクチャ",
    "services.security.title": "セキュリティ",
    "services.global.title": "グローバルカバレッジ",
  },
}

// Provider component
export function LanguageProvider({ children }: { children: ReactNode }) {
  // Get initial language from localStorage or default to English
  const [language, setLanguageState] = useState<Language>("en")
  const [isLoaded, setIsLoaded] = useState(false)

  useEffect(() => {
    const storedLanguage = localStorage.getItem("language") as Language
    if (storedLanguage && Object.keys(translations).includes(storedLanguage)) {
      setLanguageState(storedLanguage)
    } else {
      // Try to detect browser language
      const browserLanguage = navigator.language.split("-")[0] as Language
      if (Object.keys(translations).includes(browserLanguage)) {
        setLanguageState(browserLanguage)
      }
    }
    setIsLoaded(true)
  }, [])

  // Update language and store in localStorage
  const setLanguage = (newLanguage: Language) => {
    setLanguageState(newLanguage)
    localStorage.setItem("language", newLanguage)

    // Update HTML lang attribute
    document.documentElement.lang = newLanguage
  }

  // Translation function
  const t = (key: string): string => {
    if (!translations[language] || !translations[language][key]) {
      // Fallback to English if translation is missing
      return translations.en[key] || key
    }
    return translations[language][key]
  }

  // Only render children after initial language is loaded
  if (!isLoaded) {
    return null
  }

  return <LanguageContext.Provider value={{ language, setLanguage, t }}>{children}</LanguageContext.Provider>
}

// Hook for using the language context
export function useLanguage() {
  const context = useContext(LanguageContext)
  if (context === undefined) {
    throw new Error("useLanguage must be used within a LanguageProvider")
  }
  return context
}

