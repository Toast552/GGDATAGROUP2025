import { AlertTriangle } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

interface DisclosureBannerProps {
  title?: string
  description?: string
  variant?: "default" | "warning" | "destructive"
}

export function DisclosureBanner({
  title = "Financial Risk Disclosure",
  description = "Financial markets involve risk. Past performance is not indicative of future results. All trading tools and information provided are for educational purposes only and do not constitute financial advice.",
  variant = "warning",
}: DisclosureBannerProps) {
  return (
    <div className="container py-4">
      <Alert variant={variant}>
        <AlertTriangle className="h-4 w-4" />
        <AlertTitle>{title}</AlertTitle>
        <AlertDescription>{description}</AlertDescription>
      </Alert>
    </div>
  )
}

