"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { SearchIcon, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { useLanguage } from "@/components/language-provider"
import { useDebounce } from "@/hooks/use-debounce"

export function Search() {
  const { t } = useLanguage()
  const [isOpen, setIsOpen] = useState(false)
  const [query, setQuery] = useState("")
  const debouncedQuery = useDebounce(query, 300)
  const [results, setResults] = useState([])
  const [isLoading, setIsLoading] = useState(false)
  const inputRef = useRef<HTMLInputElement>(null)
  const searchRef = useRef<HTMLDivElement>(null)

  // Focus input when search is opened
  useEffect(() => {
    if (isOpen && inputRef.current) {
      inputRef.current.focus()
    }
  }, [isOpen])

  // Close search when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setIsOpen(false)
      }
    }

    document.addEventListener("mousedown", handleClickOutside)
    return () => document.removeEventListener("mousedown", handleClickOutside)
  }, [])

  // Handle search query
  useEffect(() => {
    if (debouncedQuery.length < 2) {
      setResults([])
      return
    }

    const performSearch = async () => {
      setIsLoading(true)

      // Simulate API call with timeout
      setTimeout(() => {
        // Mock results
        const mockResults = [
          { id: 1, title: "Market Data API", url: "/services" },
          { id: 2, title: "Analytics Platform", url: "/services" },
          { id: 3, title: "Trading Infrastructure", url: "/services" },
          { id: 4, title: "Security Solutions", url: "/services" },
        ].filter((item) => item.title.toLowerCase().includes(debouncedQuery.toLowerCase()))

        setResults(mockResults)
        setIsLoading(false)
      }, 500)
    }

    performSearch()
  }, [debouncedQuery])

  // Sanitize input to prevent XSS
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const sanitizedValue = e.target.value.replace(/<\/?[^>]+(>|$)/g, "")
    setQuery(sanitizedValue)
  }

  return (
    <div ref={searchRef} className="relative">
      <Button variant="ghost" size="icon" onClick={() => setIsOpen(true)} className={isOpen ? "hidden" : ""}>
        <SearchIcon className="h-5 w-5" />
        <span className="sr-only">{t("common.search")}</span>
      </Button>

      {isOpen && (
        <div className="absolute right-0 top-0 z-50 w-screen max-w-sm">
          <div className="overflow-hidden rounded-md border bg-background shadow-lg animate-in fade-in-0 zoom-in-95">
            <div className="flex items-center border-b px-3">
              <SearchIcon className="mr-2 h-4 w-4 shrink-0 opacity-50" />
              <Input
                ref={inputRef}
                value={query}
                onChange={handleInputChange}
                placeholder={t("common.search")}
                className="flex h-10 w-full rounded-md bg-transparent py-3 text-sm outline-none placeholder:text-muted-foreground disabled:cursor-not-allowed disabled:opacity-50 border-0 focus-visible:ring-0"
              />
              <Button variant="ghost" size="icon" onClick={() => setIsOpen(false)} className="h-8 w-8">
                <X className="h-4 w-4" />
                <span className="sr-only">Close</span>
              </Button>
            </div>
            <div className="max-h-80 overflow-y-auto p-0">
              {isLoading ? (
                <div className="p-4 text-center text-sm text-muted-foreground">Searching...</div>
              ) : results.length > 0 ? (
                <div className="py-2">
                  {results.map((result: any) => (
                    <a
                      key={result.id}
                      href={result.url}
                      className="block px-4 py-2 text-sm hover:bg-muted"
                      onClick={() => setIsOpen(false)}
                    >
                      {result.title}
                    </a>
                  ))}
                </div>
              ) : query.length > 0 ? (
                <div className="p-4 text-center text-sm text-muted-foreground">No results found.</div>
              ) : null}
            </div>
            <div className="border-t p-2 text-xs text-muted-foreground">
              <span>Press ESC to close</span>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

