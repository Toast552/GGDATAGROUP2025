"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { RefreshCw, Check } from "lucide-react"

interface CaptchaProps {
  onVerify: (verified: boolean) => void
}

export function Captcha({ onVerify }: CaptchaProps) {
  const [loading, setLoading] = useState(false)
  const [verified, setVerified] = useState(false)
  const [captchaText, setCaptchaText] = useState("")
  const [userInput, setUserInput] = useState("")
  const [isRobotChecked, setIsRobotChecked] = useState(false)

  // Generate a random captcha text
  const generateCaptcha = () => {
    const chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789"
    let result = ""
    for (let i = 0; i < 6; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length))
    }
    setCaptchaText(result)
    setUserInput("")
    setVerified(false)
    onVerify(false)
  }

  // Initialize captcha on mount
  useEffect(() => {
    generateCaptcha()
  }, [])

  // Verify the captcha
  const verifyCaptcha = () => {
    setLoading(true)

    // Simulate server verification
    setTimeout(() => {
      const isValid = userInput === captchaText && isRobotChecked
      setVerified(isValid)
      onVerify(isValid)
      setLoading(false)

      if (!isValid) {
        generateCaptcha()
      }
    }, 1000)
  }

  return (
    <Card className="w-full">
      <CardContent className="p-4">
        {verified ? (
          <div className="flex items-center justify-center p-4 bg-green-50 dark:bg-green-900/20 rounded-md">
            <Check className="h-5 w-5 text-green-500 mr-2" />
            <span className="text-green-700 dark:text-green-300">Verification successful</span>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="text-sm font-medium">Verify you're human</div>
              <Button variant="ghost" size="sm" onClick={generateCaptcha} disabled={loading} className="h-8 w-8 p-0">
                <RefreshCw className="h-4 w-4" />
              </Button>
            </div>

            <div className="relative">
              <div
                className="bg-muted p-3 rounded-md text-center select-none"
                style={{
                  fontFamily: "monospace",
                  letterSpacing: "0.25em",
                  fontSize: "1.25rem",
                  fontWeight: "bold",
                  background: "repeating-linear-gradient(45deg, #f0f0f0, #f0f0f0 10px, #e0e0e0 10px, #e0e0e0 20px)",
                }}
              >
                {captchaText}
              </div>

              <input
                type="text"
                value={userInput}
                onChange={(e) => setUserInput(e.target.value)}
                placeholder="Enter the text above"
                className="mt-2 w-full p-2 border rounded-md"
                disabled={loading}
              />
            </div>

            <div className="flex items-center space-x-2">
              <Checkbox
                id="robot"
                checked={isRobotChecked}
                onCheckedChange={(checked) => setIsRobotChecked(checked as boolean)}
                disabled={loading}
              />
              <label
                htmlFor="robot"
                className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
              >
                I'm not a robot
              </label>
            </div>

            <Button className="w-full" onClick={verifyCaptcha} disabled={loading || !userInput || !isRobotChecked}>
              {loading ? "Verifying..." : "Verify"}
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

