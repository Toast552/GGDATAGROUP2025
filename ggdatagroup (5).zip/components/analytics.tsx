"use client"

import { useEffect } from "react"
import { usePathname, useSearchParams } from "next/navigation"

export function Analytics() {
  const pathname = usePathname()
  const searchParams = useSearchParams()

  useEffect(() => {
    // Track page views
    const url = pathname + (searchParams?.toString() ? `?${searchParams.toString()}` : "")
    trackPageView(url)
  }, [pathname, searchParams])

  return null
}

// Mock analytics tracking function
function trackPageView(url: string) {
  // In a real app, this would send data to your analytics service
  // like Google Analytics, Plausible, Fathom, etc.
  console.log(`Page view tracked: ${url}`)

  // Example implementation for Google Analytics
  if (typeof window !== "undefined" && "gtag" in window) {
    // @ts-ignore
    window.gtag("config", "G-MEASUREMENT_ID", {
      page_path: url,
    })
  }
}

// Error tracking function
export function trackError(error: Error, componentName?: string) {
  // In a real app, this would send data to your error monitoring service
  // like Sentry, LogRocket, etc.
  console.error(`Error in ${componentName || "unknown component"}:`, error)
}

// Event tracking function
export function trackEvent(category: string, action: string, label?: string, value?: number) {
  // In a real app, this would send data to your analytics service
  console.log(`Event tracked: ${category} / ${action} / ${label || "N/A"} / ${value || "N/A"}`)

  // Example implementation for Google Analytics
  if (typeof window !== "undefined" && "gtag" in window) {
    // @ts-ignore
    window.gtag("event", action, {
      event_category: category,
      event_label: label,
      value: value,
    })
  }
}

