"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { CheckCircle, AlertCircle, Info, Clock, RefreshCw } from "lucide-react"

interface LogEvent {
  id: string
  type: "success" | "error" | "info" | "warning"
  message: string
  timestamp: Date
  service: string
}

export function EventLog() {
  const [events, setEvents] = useState<LogEvent[]>([])
  const [loading, setLoading] = useState(true)

  // Generate mock events
  useEffect(() => {
    const generateEvents = () => {
      const eventTypes: ("success" | "error" | "info" | "warning")[] = ["success", "error", "info", "warning"]
      const services = ["API Gateway", "Database", "Authentication", "Market Data", "Analytics Engine"]
      const messages = [
        "Service health check completed",
        "Data sync completed successfully",
        "New market data feed connected",
        "System update deployed",
        "Temporary network latency detected",
        "Rate limit threshold adjusted",
        "Backup process completed",
        "New user registration spike detected",
        "Cache invalidation triggered",
        "Load balancer optimization applied",
      ]

      const mockEvents: LogEvent[] = []

      // Generate events from the past 24 hours
      for (let i = 0; i < 10; i++) {
        const hoursAgo = Math.floor(Math.random() * 24)
        const minutesAgo = Math.floor(Math.random() * 60)
        const timestamp = new Date()
        timestamp.setHours(timestamp.getHours() - hoursAgo)
        timestamp.setMinutes(timestamp.getMinutes() - minutesAgo)

        mockEvents.push({
          id: Math.random().toString(36).substring(2, 9),
          type: eventTypes[Math.floor(Math.random() * eventTypes.length)],
          message: messages[Math.floor(Math.random() * messages.length)],
          timestamp,
          service: services[Math.floor(Math.random() * services.length)],
        })
      }

      // Sort by timestamp (newest first)
      return mockEvents.sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())
    }

    setEvents(generateEvents())
    setLoading(false)

    // Periodically add new events
    const interval = setInterval(() => {
      if (Math.random() > 0.7) {
        // 30% chance of new event
        const newEvent: LogEvent = {
          id: Math.random().toString(36).substring(2, 9),
          type: ["success", "info", "warning", "error"][Math.floor(Math.random() * 4)] as
            | "success"
            | "error"
            | "info"
            | "warning",
          message:
            "New event: " +
            ["API request processed", "Data updated", "User authenticated", "Cache refreshed"][
              Math.floor(Math.random() * 4)
            ],
          timestamp: new Date(),
          service: ["API Gateway", "Database", "Authentication", "Market Data"][Math.floor(Math.random() * 4)],
        }

        setEvents((prev) => [newEvent, ...prev.slice(0, 9)]) // Keep only 10 events
      }
    }, 5000)

    return () => clearInterval(interval)
  }, [])

  // Format relative time
  const formatRelativeTime = (date: Date) => {
    const now = new Date()
    const diffMs = now.getTime() - date.getTime()
    const diffSec = Math.floor(diffMs / 1000)
    const diffMin = Math.floor(diffSec / 60)
    const diffHour = Math.floor(diffMin / 60)

    if (diffSec < 60) return `${diffSec}s ago`
    if (diffMin < 60) return `${diffMin}m ago`
    return `${diffHour}h ago`
  }

  // Get icon based on event type
  const getEventIcon = (type: LogEvent["type"]) => {
    switch (type) {
      case "success":
        return <CheckCircle className="h-5 w-5 text-green-500" />
      case "error":
        return <AlertCircle className="h-5 w-5 text-red-500" />
      case "warning":
        return <AlertCircle className="h-5 w-5 text-amber-500" />
      case "info":
        return <Info className="h-5 w-5 text-blue-500" />
      default:
        return <Info className="h-5 w-5" />
    }
  }

  // Get badge color based on event type
  const getEventBadgeVariant = (type: LogEvent["type"]): "default" | "secondary" | "destructive" | "outline" => {
    switch (type) {
      case "success":
        return "default"
      case "error":
        return "destructive"
      case "warning":
        return "secondary"
      case "info":
        return "outline"
      default:
        return "outline"
    }
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-xl">System Events</CardTitle>
        <div className="flex items-center text-sm text-muted-foreground">
          <Clock className="mr-1 h-4 w-4" />
          <span>Last 24 hours</span>
        </div>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="flex justify-center items-center py-8">
            <RefreshCw className="h-6 w-6 animate-spin text-muted-foreground" />
          </div>
        ) : (
          <div className="space-y-4">
            {events.map((event) => (
              <div key={event.id} className="flex items-start space-x-3 py-2">
                {getEventIcon(event.type)}
                <div className="flex-1 space-y-1">
                  <div className="flex items-center justify-between">
                    <p className="text-sm font-medium">{event.message}</p>
                    <span className="text-xs text-muted-foreground">{formatRelativeTime(event.timestamp)}</span>
                  </div>
                  <div className="flex items-center">
                    <Badge variant={getEventBadgeVariant(event.type)} className="mr-2">
                      {event.type}
                    </Badge>
                    <span className="text-xs text-muted-foreground">{event.service}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}

