"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Accessibility, Eye, Type, MousePointer2, RotateCcw } from "lucide-react"
import { useAccessibility } from "./accessibility-provider"

export function AccessibilityMenu() {
  const [open, setOpen] = useState(false)
  const {
    options,
    toggleHighContrast,
    toggleLargeText,
    toggleReducedMotion,
    toggleScreenReaderOptimized,
    resetOptions,
  } = useAccessibility()

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button
          variant="outline"
          size="icon"
          className="fixed bottom-4 right-4 z-50 rounded-full"
          aria-label="Accessibility options"
        >
          <Accessibility className="h-5 w-5" />
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Accessibility Options</DialogTitle>
          <DialogDescription>
            Customize your experience to make the site more accessible for your needs.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Eye className="h-4 w-4" />
              <Label htmlFor="high-contrast">High Contrast</Label>
            </div>
            <Switch
              id="high-contrast"
              checked={options.highContrast}
              onCheckedChange={toggleHighContrast}
              aria-label="Toggle high contrast mode"
            />
          </div>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Type className="h-4 w-4" />
              <Label htmlFor="large-text">Large Text</Label>
            </div>
            <Switch
              id="large-text"
              checked={options.largeText}
              onCheckedChange={toggleLargeText}
              aria-label="Toggle large text mode"
            />
          </div>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <MousePointer2 className="h-4 w-4" />
              <Label htmlFor="reduced-motion">Reduced Motion</Label>
            </div>
            <Switch
              id="reduced-motion"
              checked={options.reducedMotion}
              onCheckedChange={toggleReducedMotion}
              aria-label="Toggle reduced motion mode"
            />
          </div>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Accessibility className="h-4 w-4" />
              <Label htmlFor="screen-reader">Screen Reader Optimized</Label>
            </div>
            <Switch
              id="screen-reader"
              checked={options.screenReaderOptimized}
              onCheckedChange={toggleScreenReaderOptimized}
              aria-label="Toggle screen reader optimized mode"
            />
          </div>
          <Button
            variant="outline"
            className="mt-2"
            onClick={() => {
              resetOptions()
            }}
          >
            <RotateCcw className="h-4 w-4 mr-2" />
            Reset to Defaults
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}

