"use client"

import type React from "react"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/components/auth-provider"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Lock, LogIn } from "lucide-react"
import Link from "next/link"
import { useLanguage } from "@/components/language-provider"

interface ProtectedRouteProps {
  children: React.ReactNode
  requireAuth?: boolean
  requirePremium?: boolean
}

export function ProtectedRoute({ children, requireAuth = true, requirePremium = false }: ProtectedRouteProps) {
  const { isAuthenticated, isPremium, isLoading } = useAuth()
  const router = useRouter()
  const { t } = useLanguage()

  useEffect(() => {
    if (!isLoading && requireAuth && !isAuthenticated) {
      router.push("/login?redirect=" + encodeURIComponent(window.location.pathname))
    }
  }, [isLoading, isAuthenticated, requireAuth, router])

  if (isLoading) {
    return (
      <div className="flex justify-center items-center min-h-[60vh]">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    )
  }

  if (!isAuthenticated && requireAuth) {
    return (
      <div className="container py-12">
        <Card className="max-w-md mx-auto">
          <CardHeader>
            <div className="w-12 h-12 rounded-full bg-amber-100 dark:bg-amber-900 flex items-center justify-center mb-4">
              <LogIn className="h-6 w-6 text-amber-600 dark:text-amber-400" />
            </div>
            <CardTitle>{t("premium.loginRequired")}</CardTitle>
            <CardDescription>{t("premium.loginMessage")}</CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col gap-4">
            <Link href={`/login?redirect=${encodeURIComponent(window.location.pathname)}`}>
              <Button className="w-full">{t("premium.login")}</Button>
            </Link>
            <Link href="/">
              <Button variant="outline" className="w-full">
                {t("premium.goBack")}
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    )
  }

  if (requirePremium && !isPremium) {
    return (
      <div className="container py-12">
        <Card className="max-w-md mx-auto">
          <CardHeader>
            <div className="w-12 h-12 rounded-full bg-amber-100 dark:bg-amber-900 flex items-center justify-center mb-4">
              <Lock className="h-6 w-6 text-amber-600 dark:text-amber-400" />
            </div>
            <CardTitle>{t("premium.premiumRequired")}</CardTitle>
            <CardDescription>{t("premium.premiumMessage")}</CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col gap-4">
            <Link href="/pricing">
              <Button className="w-full">{t("premium.upgradeNow")}</Button>
            </Link>
            <Link href="/">
              <Button variant="outline" className="w-full">
                {t("premium.goBack")}
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    )
  }

  return <>{children}</>
}

