"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { logger } from "@/lib/logger"

interface ErrorBoundaryProps {
  children: React.ReactNode
}

export function ErrorBoundary({ children }: ErrorBoundaryProps) {
  const [error, setError] = useState<Error | null>(null)

  useEffect(() => {
    const handleError = (error: ErrorEvent) => {
      logger.error("Unhandled error:", error.error)
      setError(error.error)
    }

    window.addEventListener("error", handleError)
    return () => window.removeEventListener("error", handleError)
  }, [])

  if (error) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center p-4 text-center">
        <div className="max-w-md">
          <h1 className="mb-4 text-3xl font-bold">Something went wrong</h1>
          <p className="mb-8 text-muted-foreground">
            We apologize for the inconvenience. Our team has been notified of this issue.
          </p>
          <div className="mb-8 rounded-md bg-muted p-4 text-left">
            <p className="font-mono text-sm">{error.message}</p>
          </div>
          <div className="flex justify-center gap-4">
            <Button onClick={() => window.location.reload()}>Refresh Page</Button>
            <Button variant="outline" onClick={() => setError(null)}>
              Dismiss Error
            </Button>
          </div>
        </div>
      </div>
    )
  }

  return <>{children}</>
}

