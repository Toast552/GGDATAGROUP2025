"use client"

import { useEffect } from "react"

export function TidioChat() {
  useEffect(() => {
    // Load Tidio Chat script
    const script = document.createElement("script")
    script.src = "//code.tidio.co/your-tidio-key.js" // Replace with your actual Tidio key
    script.async = true
    document.body.appendChild(script)

    return () => {
      // Clean up
      document.body.removeChild(script)
      // @ts-ignore
      if (window.tidioChatApi) {
        // @ts-ignore
        window.tidioChatApi.hide()
        // @ts-ignore
        window.tidioChatApi.close()
      }
    }
  }, [])

  return null
}

