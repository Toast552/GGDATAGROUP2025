"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Settings, Bell, Moon, Globe, Lock, Eye, Activity } from "lucide-react"

interface SettingOption {
  id: string
  title: string
  description: string
  enabled: boolean
  icon: React.ReactNode
}

export function SettingsToggle() {
  const [settings, setSettings] = useState<SettingOption[]>([
    {
      id: "notifications",
      title: "Notifications",
      description: "Receive notifications about account activity and updates",
      enabled: true,
      icon: <Bell className="h-5 w-5" />,
    },
    {
      id: "darkMode",
      title: "Dark Mode",
      description: "Use dark theme for the interface",
      enabled: false,
      icon: <Moon className="h-5 w-5" />,
    },
    {
      id: "language",
      title: "Language Preferences",
      description: "Set your preferred language for the interface",
      enabled: true,
      icon: <Globe className="h-5 w-5" />,
    },
    {
      id: "privacy",
      title: "Enhanced Privacy",
      description: "Enable additional privacy features",
      enabled: false,
      icon: <Lock className="h-5 w-5" />,
    },
    {
      id: "visibility",
      title: "Profile Visibility",
      description: "Control who can see your profile information",
      enabled: true,
      icon: <Eye className="h-5 w-5" />,
    },
    {
      id: "analytics",
      title: "Usage Analytics",
      description: "Allow collection of anonymous usage data to improve our services",
      enabled: true,
      icon: <Activity className="h-5 w-5" />,
    },
  ])

  const toggleSetting = (id: string) => {
    setSettings(settings.map((setting) => (setting.id === id ? { ...setting, enabled: !setting.enabled } : setting)))
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center space-x-2">
          <Settings className="h-5 w-5" />
          <CardTitle>Settings</CardTitle>
        </div>
        <CardDescription>Manage your preferences and account settings</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {settings.map((setting) => (
          <div key={setting.id} className="flex items-center justify-between space-x-4">
            <div className="flex items-start space-x-3">
              <div className="mt-0.5 text-muted-foreground">{setting.icon}</div>
              <div>
                <Label htmlFor={setting.id} className="font-medium">
                  {setting.title}
                </Label>
                <p className="text-sm text-muted-foreground">{setting.description}</p>
              </div>
            </div>
            <Switch id={setting.id} checked={setting.enabled} onCheckedChange={() => toggleSetting(setting.id)} />
          </div>
        ))}
        <div className="pt-4">
          <Button className="w-full">Save Settings</Button>
        </div>
      </CardContent>
    </Card>
  )
}

