"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { AlertCircle, CheckCircle2, FileText } from "lucide-react"

interface DocuSignWaiverProps {
  onComplete?: () => void
  title?: string
  description?: string
}

export function DocuSignWaiver({
  onComplete,
  title = "Service Agreement",
  description = "Please review and sign the following agreement before proceeding",
}: DocuSignWaiverProps) {
  const [step, setStep] = useState(1)
  const [fullName, setFullName] = useState("")
  const [email, setEmail] = useState("")
  const [agreed, setAgreed] = useState(false)
  const [signature, setSignature] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isComplete, setIsComplete] = useState(false)

  // Add input validation and error handling
  const [errors, setErrors] = useState({
    fullName: "",
    email: "",
    signature: "",
  })

  const validateInputs = () => {
    let isValid = true
    const newErrors = {
      fullName: "",
      email: "",
      signature: "",
    }

    // Validate full name
    if (!fullName.trim()) {
      newErrors.fullName = "Full name is required"
      isValid = false
    } else if (fullName.trim().length < 3) {
      newErrors.fullName = "Full name must be at least 3 characters"
      isValid = false
    }

    // Validate email
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!email.trim()) {
      newErrors.email = "Email is required"
      isValid = false
    } else if (!emailRegex.test(email)) {
      newErrors.email = "Please enter a valid email address"
      isValid = false
    }

    // Validate signature
    if (!signature.trim()) {
      newErrors.signature = "Signature is required"
      isValid = false
    } else if (signature.trim().length < 3) {
      newErrors.signature = "Signature must be at least 3 characters"
      isValid = false
    }

    setErrors(newErrors)
    return isValid
  }

  // Update handleSubmit with validation
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    // Sanitize inputs
    const sanitizedFullName = fullName.trim().replace(/<\/?[^>]+(>|$)/g, "")
    const sanitizedEmail = email.trim().replace(/<\/?[^>]+(>|$)/g, "")
    const sanitizedSignature = signature.trim().replace(/<\/?[^>]+(>|$)/g, "")

    setFullName(sanitizedFullName)
    setEmail(sanitizedEmail)
    setSignature(sanitizedSignature)

    if (!validateInputs()) {
      return
    }

    setIsSubmitting(true)

    // Log the submission attempt (in a real app, this would go to a secure logging service)
    console.log(`DocuSign waiver submission attempt: ${sanitizedEmail}`)

    // Simulate API call to DocuSign
    setTimeout(() => {
      try {
        // In a real implementation, this would be an API call to DocuSign
        // with proper error handling

        // Success case
        setIsSubmitting(false)
        setIsComplete(true)

        // Log successful submission
        console.log(`DocuSign waiver successfully signed by: ${sanitizedEmail}`)

        if (onComplete) {
          onComplete()
        }
      } catch (error) {
        // Error case
        setIsSubmitting(false)
        console.error("Error submitting DocuSign waiver:", error)

        // Show error message to user
        alert("There was an error processing your signature. Please try again later.")
      }
    }, 2000)
  }

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <CardTitle>{title}</CardTitle>
        <CardDescription>{description}</CardDescription>
      </CardHeader>
      <CardContent>
        {isComplete ? (
          <div className="flex flex-col items-center justify-center py-6">
            <CheckCircle2 className="h-16 w-16 text-green-500 mb-4" />
            <h3 className="text-xl font-bold mb-2">Agreement Signed!</h3>
            <p className="text-center text-muted-foreground">
              Thank you for signing the agreement. You will receive a copy via email shortly.
            </p>
          </div>
        ) : (
          <div>
            {step === 1 && (
              <div className="space-y-4">
                <div className="flex items-center space-x-2 p-4 bg-muted rounded-md">
                  <FileText className="h-5 w-5 text-muted-foreground" />
                  <span className="text-sm font-medium">Please review the agreement</span>
                </div>

                <div className="h-64 overflow-y-auto border rounded-md p-4 text-sm text-muted-foreground">
                  <h3 className="font-bold mb-2">Crypto Mining and Services Agreement</h3>
                  <p className="mb-4">
                    This agreement ("Agreement") is entered into between GG Data Group ("Provider") and the undersigned
                    client ("Client").
                  </p>

                  <h4 className="font-semibold mb-1">1. Services</h4>
                  <p className="mb-2">
                    Provider agrees to provide cryptocurrency mining and related services as described in the service
                    details.
                  </p>

                  <h4 className="font-semibold mb-1">2. Risk Disclosure</h4>
                  <p className="mb-2">
                    Client acknowledges that cryptocurrency mining and trading involve significant risks, including but
                    not limited to:
                  </p>
                  <ul className="list-disc pl-5 mb-2">
                    <li>Volatility in cryptocurrency prices</li>
                    <li>Potential for hardware failures or downtime</li>
                    <li>Changes in mining difficulty and profitability</li>
                    <li>Regulatory changes that may affect operations</li>
                    <li>Network security risks</li>
                  </ul>

                  <h4 className="font-semibold mb-1">3. No Guaranteed Returns</h4>
                  <p className="mb-2">
                    Client understands that Provider makes no guarantees regarding mining profitability or returns on
                    investment. Mining results depend on various factors beyond Provider's control.
                  </p>

                  <h4 className="font-semibold mb-1">4. Limitation of Liability</h4>
                  <p className="mb-2">
                    Provider's liability is limited to the fees paid by Client for the services. Provider is not liable
                    for any indirect, consequential, or special damages.
                  </p>

                  <h4 className="font-semibold mb-1">5. Term and Termination</h4>
                  <p className="mb-2">
                    This Agreement begins on the date of signing and continues until terminated by either party with 30
                    days' written notice.
                  </p>

                  <h4 className="font-semibold mb-1">6. Governing Law</h4>
                  <p className="mb-4">
                    This Agreement is governed by the laws of the jurisdiction where Provider is located.
                  </p>

                  <p>
                    By signing below, Client acknowledges having read, understood, and agreed to all terms and
                    conditions in this Agreement.
                  </p>
                </div>

                <div className="flex items-center space-x-2">
                  <Checkbox id="terms" checked={agreed} onCheckedChange={(checked) => setAgreed(checked as boolean)} />
                  <label
                    htmlFor="terms"
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                  >
                    I have read and agree to the terms and conditions
                  </label>
                </div>

                <Button onClick={() => agreed && setStep(2)} disabled={!agreed} className="w-full">
                  Continue
                </Button>
              </div>
            )}

            {step === 2 && (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="fullName">Full Name</Label>
                  <Input
                    id="fullName"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    className={errors.fullName ? "border-red-500" : ""}
                    aria-invalid={errors.fullName ? "true" : "false"}
                    aria-describedby={errors.fullName ? "fullName-error" : undefined}
                  />
                  {errors.fullName && (
                    <p id="fullName-error" className="text-xs text-red-500 mt-1">
                      {errors.fullName}
                    </p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email">Email Address</Label>
                  <Input
                    id="email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className={errors.email ? "border-red-500" : ""}
                    aria-invalid={errors.email ? "true" : "false"}
                    aria-describedby={errors.email ? "email-error" : undefined}
                  />
                  {errors.email && (
                    <p id="email-error" className="text-xs text-red-500 mt-1">
                      {errors.email}
                    </p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="signature">Electronic Signature</Label>
                  <Input
                    id="signature"
                    value={signature}
                    onChange={(e) => setSignature(e.target.value)}
                    className={errors.signature ? "border-red-500" : ""}
                    aria-invalid={errors.signature ? "true" : "false"}
                    aria-describedby={errors.signature ? "signature-error" : undefined}
                  />
                  {errors.signature && (
                    <p id="signature-error" className="text-xs text-red-500 mt-1">
                      {errors.signature}
                    </p>
                  )}
                  <p className="text-xs text-muted-foreground">
                    By typing your name above, you are signing this agreement electronically.
                  </p>
                </div>

                <div className="flex items-center space-x-2 p-4 bg-yellow-50 dark:bg-yellow-950 border border-yellow-200 dark:border-yellow-800 rounded-md">
                  <AlertCircle className="h-5 w-5 text-yellow-600 dark:text-yellow-400" />
                  <span className="text-sm text-yellow-600 dark:text-yellow-400">
                    Please ensure all information is accurate before signing.
                  </span>
                </div>

                <div className="flex space-x-2">
                  <Button type="button" variant="outline" onClick={() => setStep(1)} className="flex-1">
                    Back
                  </Button>
                  <Button type="submit" disabled={isSubmitting || !fullName || !email || !signature} className="flex-1">
                    {isSubmitting ? "Signing..." : "Sign Agreement"}
                  </Button>
                </div>
              </form>
            )}
          </div>
        )}
      </CardContent>
      {isComplete && (
        <CardFooter>
          <Button onClick={() => window.location.reload()} className="w-full">
            Continue to Shop
          </Button>
        </CardFooter>
      )}
    </Card>
  )
}

