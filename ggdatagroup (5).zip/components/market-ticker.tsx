"use client"

import { useState, useEffect } from "react"
import { ArrowUp, ArrowDown } from "lucide-react"

interface MarketData {
  symbol: string
  price: number
  change: number
  changePercent: number
}

export function MarketTicker() {
  const [marketData, setMarketData] = useState<MarketData[]>([
    { symbol: "BTC/USD", price: 65432.1, change: 1234.56, changePercent: 1.92 },
    { symbol: "ETH/USD", price: 3456.78, change: -123.45, changePercent: -3.45 },
    { symbol: "AAPL", price: 187.65, change: 2.34, changePercent: 1.26 },
    { symbol: "MSFT", price: 415.32, change: 5.67, changePercent: 1.38 },
    { symbol: "AMZN", price: 178.9, change: -3.21, changePercent: -1.76 },
    { symbol: "GOOGL", price: 156.78, change: 1.23, changePercent: 0.79 },
    { symbol: "TSLA", price: 234.56, change: 7.89, changePercent: 3.48 },
    { symbol: "SPY", price: 512.34, change: 2.1, changePercent: 0.41 },
    { symbol: "QQQ", price: 435.67, change: 3.45, changePercent: 0.8 },
    { symbol: "NVDA", price: 876.54, change: 12.34, changePercent: 1.43 },
  ])

  // Simulate price updates
  useEffect(() => {
    const interval = setInterval(() => {
      setMarketData((prevData) =>
        prevData.map((item) => {
          // Random price change between -0.5% and 0.5%
          const randomChange = item.price * (Math.random() * 0.01 - 0.005)
          const newPrice = Number.parseFloat((item.price + randomChange).toFixed(2))
          const newChange = Number.parseFloat((item.change + randomChange).toFixed(2))
          const newChangePercent = Number.parseFloat(
            (item.changePercent + (randomChange / item.price) * 100).toFixed(2),
          )

          return {
            ...item,
            price: newPrice,
            change: newChange,
            changePercent: newChangePercent,
          }
        }),
      )
    }, 3000)

    return () => clearInterval(interval)
  }, [])

  return (
    <div className="w-full bg-muted/30 py-3 overflow-hidden border-y">
      <div className="flex animate-marquee whitespace-nowrap">
        {marketData.concat(marketData).map((item, index) => (
          <div key={index} className="flex items-center mx-6 font-medium">
            <span className="mr-2">{item.symbol}</span>
            <span className="mr-2">
              ${item.price.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </span>
            <span className={`flex items-center ${item.change >= 0 ? "text-green-600" : "text-red-500"}`}>
              {item.change >= 0 ? <ArrowUp className="h-3 w-3 mr-1" /> : <ArrowDown className="h-3 w-3 mr-1" />}
              {item.changePercent.toFixed(2)}%
            </span>
          </div>
        ))}
      </div>
    </div>
  )
}

