"use client"

import { useEffect } from "react"

interface Particle {
  x: number
  y: number
  size: number
  speedX: number
  speedY: number
  color: string
  alpha: number
  decreaseRate: number
}

export function MouseEffects() {
  useEffect(() => {
    const particles: Particle[] = []
    const colors = ["#FFD700", "#FFC107", "#FFEB3B", "#F9A825", "#FFA000"]

    const createRipple = (x: number, y: number) => {
      const ripple = document.createElement("div")
      ripple.className = "ripple-effect"
      ripple.style.left = `${x}px`
      ripple.style.top = `${y}px`
      document.body.appendChild(ripple)

      setTimeout(() => {
        ripple.remove()
      }, 1000)
    }

    const createParticles = (x: number, y: number, count: number) => {
      for (let i = 0; i < count; i++) {
        const size = Math.random() * 5 + 2
        const speedX = Math.random() * 4 - 2
        const speedY = Math.random() * 4 - 2
        const color = colors[Math.floor(Math.random() * colors.length)]
        const decreaseRate = Math.random() * 0.03 + 0.01

        particles.push({
          x,
          y,
          size,
          speedX,
          speedY,
          color,
          alpha: 1,
          decreaseRate,
        })
      }
    }

    const updateParticles = () => {
      for (let i = particles.length - 1; i >= 0; i--) {
        const p = particles[i]
        p.x += p.speedX
        p.y += p.speedY
        p.alpha -= p.decreaseRate

        if (p.alpha <= 0) {
          particles.splice(i, 1)
        }
      }
    }

    const drawParticles = () => {
      const canvas = document.getElementById("particle-canvas") as HTMLCanvasElement
      if (!canvas) return

      const ctx = canvas.getContext("2d")
      if (!ctx) return

      ctx.clearRect(0, 0, canvas.width, canvas.height)

      particles.forEach((p) => {
        ctx.globalAlpha = p.alpha
        ctx.fillStyle = p.color
        ctx.beginPath()
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2)
        ctx.fill()
      })
    }

    const animate = () => {
      updateParticles()
      drawParticles()
      requestAnimationFrame(animate)
    }

    const handleClick = (e: MouseEvent) => {
      createRipple(e.clientX, e.clientY)
      createParticles(e.clientX, e.clientY, 20)
    }

    const handleResize = () => {
      const canvas = document.getElementById("particle-canvas") as HTMLCanvasElement
      if (canvas) {
        canvas.width = window.innerWidth
        canvas.height = window.innerHeight
      }
    }

    // Create canvas
    const canvas = document.createElement("canvas")
    canvas.id = "particle-canvas"
    canvas.width = window.innerWidth
    canvas.height = window.innerHeight
    canvas.style.position = "fixed"
    canvas.style.top = "0"
    canvas.style.left = "0"
    canvas.style.pointerEvents = "none"
    canvas.style.zIndex = "9999"
    document.body.appendChild(canvas)

    // Add styles for ripple effect
    const style = document.createElement("style")
    style.textContent = `
      .ripple-effect {
        position: fixed;
        border-radius: 50%;
        background-color: rgba(255, 215, 0, 0.3);
        transform: scale(0);
        animation: ripple 1s linear;
        pointer-events: none;
        z-index: 9998;
      }
      
      @keyframes ripple {
        0% {
          width: 0;
          height: 0;
          opacity: 0.5;
          transform: scale(0);
        }
        100% {
          width: 200px;
          height: 200px;
          margin-left: -100px;
          margin-top: -100px;
          opacity: 0;
          transform: scale(1);
        }
      }
    `
    document.head.appendChild(style)

    // Add event listeners
    window.addEventListener("click", handleClick)
    window.addEventListener("resize", handleResize)

    // Start animation
    animate()

    // Cleanup
    return () => {
      window.removeEventListener("click", handleClick)
      window.removeEventListener("resize", handleResize)
      if (canvas) {
        document.body.removeChild(canvas)
      }
      if (style) {
        document.head.removeChild(style)
      }
    }
  }, [])

  return null
}

