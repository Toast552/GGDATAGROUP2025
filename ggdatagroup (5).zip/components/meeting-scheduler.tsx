"use client"

import type React from "react"

import { useState } from "react"
import { Calendar } from "@/components/ui/calendar"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { AlertCircle, CalendarIcon, Clock, Loader2 } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { sanitizeInput } from "@/lib/security"
import { useLanguage } from "@/components/language-provider"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { cn } from "@/lib/utils"
import { format } from "date-fns"

export function MeetingScheduler() {
  const { t } = useLanguage()
  const [date, setDate] = useState<Date | undefined>(undefined)
  const [timeSlot, setTimeSlot] = useState<string>("")
  const [name, setName] = useState("")
  const [email, setEmail] = useState("")
  const [topic, setTopic] = useState("")
  const [message, setMessage] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSuccess, setIsSuccess] = useState(false)
  const [error, setError] = useState<string | null>(null)

  // Generate available time slots (9 AM to 5 PM)
  const generateTimeSlots = () => {
    const slots = []
    for (let hour = 9; hour <= 17; hour++) {
      const hourFormatted = hour % 12 === 0 ? 12 : hour % 12
      const amPm = hour < 12 ? "AM" : "PM"
      slots.push(`${hourFormatted}:00 ${amPm}`)
      if (hour < 17) {
        slots.push(`${hourFormatted}:30 ${amPm}`)
      }
    }
    return slots
  }

  const timeSlots = generateTimeSlots()

  // Filter out past dates
  const disabledDays = (date: Date) => {
    const today = new Date()
    today.setHours(0, 0, 0, 0)
    return date < today || date.getDay() === 0 || date.getDay() === 6 // Disable weekends
  }

  const validateForm = () => {
    if (!date) {
      setError("Please select a date")
      return false
    }
    if (!timeSlot) {
      setError("Please select a time slot")
      return false
    }
    if (!name.trim()) {
      setError("Please enter your name")
      return false
    }
    if (!email.trim()) {
      setError("Please enter your email")
      return false
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(email)) {
      setError("Please enter a valid email address")
      return false
    }

    if (!topic.trim()) {
      setError("Please select a meeting topic")
      return false
    }

    return true
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)

    if (!validateForm()) {
      return
    }

    setIsSubmitting(true)

    try {
      // Sanitize inputs
      const sanitizedName = sanitizeInput(name)
      const sanitizedEmail = sanitizeInput(email)
      const sanitizedTopic = sanitizeInput(topic)
      const sanitizedMessage = sanitizeInput(message)

      // In a real application, you would send this data to your API
      // For demo purposes, we'll simulate an API call
      await new Promise((resolve) => setTimeout(resolve, 1500))

      console.log("Meeting scheduled:", {
        date: date?.toISOString().split("T")[0],
        timeSlot,
        name: sanitizedName,
        email: sanitizedEmail,
        topic: sanitizedTopic,
        message: sanitizedMessage,
      })

      setIsSuccess(true)

      // Reset form
      setDate(undefined)
      setTimeSlot("")
      setName("")
      setEmail("")
      setTopic("")
      setMessage("")
    } catch (error) {
      console.error("Error scheduling meeting:", error)
      setError("There was an error scheduling your meeting. Please try again later.")
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <Card className="w-full">
      <CardContent className="p-6">
        {isSuccess ? (
          <div className="text-center py-8">
            <div className="w-16 h-16 bg-green-100 dark:bg-green-900 rounded-full flex items-center justify-center mx-auto mb-4">
              <CalendarIcon className="h-8 w-8 text-green-600 dark:text-green-400" />
            </div>
            <h3 className="text-xl font-bold mb-2">{t("meeting.success")}</h3>
            <p className="text-muted-foreground mb-6">{t("meeting.successMessage")}</p>
            <Button onClick={() => setIsSuccess(false)}>{t("meeting.scheduleAnother")}</Button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-6">
            {error && (
              <Alert variant="destructive" className="mb-6">
                <AlertCircle className="h-4 w-4" />
                <AlertTitle>Error</AlertTitle>
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div>
                  <Label htmlFor="name">{t("meeting.name")}</Label>
                  <Input id="name" value={name} onChange={(e) => setName(e.target.value)} placeholder="John Doe" />
                </div>

                <div>
                  <Label htmlFor="email">{t("meeting.email")}</Label>
                  <Input
                    id="email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="john@example.com"
                  />
                </div>

                <div>
                  <Label htmlFor="topic">{t("meeting.topic")}</Label>
                  <Select value={topic} onValueChange={setTopic}>
                    <SelectTrigger id="topic">
                      <SelectValue placeholder="Select a topic" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="consultation">{t("meeting.topics.consultation")}</SelectItem>
                      <SelectItem value="mining">{t("meeting.topics.mining")}</SelectItem>
                      <SelectItem value="blockchain">{t("meeting.topics.blockchain")}</SelectItem>
                      <SelectItem value="ai">{t("meeting.topics.ai")}</SelectItem>
                      <SelectItem value="security">{t("meeting.topics.security")}</SelectItem>
                      <SelectItem value="other">{t("meeting.topics.other")}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="message">{t("meeting.additionalInfo")}</Label>
                  <Textarea
                    id="message"
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    placeholder="Please share any specific questions or information about your needs"
                    rows={4}
                  />
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <Label className="block mb-2">{t("meeting.date")}</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className={cn("w-full justify-start text-left font-normal", !date && "text-muted-foreground")}
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {date ? format(date, "PPP") : "Select a date"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar mode="single" selected={date} onSelect={setDate} disabled={disabledDays} initialFocus />
                    </PopoverContent>
                  </Popover>
                </div>

                <div>
                  <Label htmlFor="timeSlot">{t("meeting.time")}</Label>
                  <Select value={timeSlot} onValueChange={setTimeSlot}>
                    <SelectTrigger id="timeSlot" className="w-full">
                      <SelectValue placeholder="Select a time slot" />
                    </SelectTrigger>
                    <SelectContent>
                      {timeSlots.map((slot) => (
                        <SelectItem key={slot} value={slot}>
                          <div className="flex items-center">
                            <Clock className="mr-2 h-4 w-4" />
                            <span>{slot}</span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="bg-muted p-4 rounded-lg mt-4">
                  <h4 className="font-medium mb-2">Available Time Slots</h4>
                  <p className="text-sm text-muted-foreground mb-2">
                    Our business hours are Monday to Friday, 9:00 AM to 5:00 PM.
                  </p>
                  <p className="text-sm text-muted-foreground">
                    Meetings are scheduled in 30-minute increments. If you need a longer meeting, please mention it in
                    the additional information.
                  </p>
                </div>
              </div>
            </div>

            <Button type="submit" className="w-full" disabled={isSubmitting}>
              {isSubmitting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  {t("meeting.scheduling")}
                </>
              ) : (
                t("meeting.schedule")
              )}
            </Button>
          </form>
        )}
      </CardContent>
    </Card>
  )
}

