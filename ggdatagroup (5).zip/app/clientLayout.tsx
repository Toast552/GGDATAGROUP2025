"use client"
import { useEffect, useState } from "react"
import { useSearchParams } from "next/navigation"
import { useLanguage } from "@/components/language-provider"
import type React from "react"
import { Inter } from "next/font/google"
import "./globals.css"
import "./accessibility.css"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { ThemeProvider } from "@/components/theme-provider"
import { LanguageProvider } from "@/components/language-provider"
import { AuthProvider } from "@/components/auth-provider"
import { AccessibilityProvider } from "@/components/accessibility-provider"
import { AccessibilityMenu } from "@/components/accessibility-menu"
import { MouseEffects } from "@/components/mouse-effects"
import { ErrorBoundary } from "@/components/error-boundary"
import { Analytics } from "@/components/analytics"

const inter = Inter({ subsets: ["latin"] })

// Default export for the ClientLayout component
export default function ClientLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  // Add this effect to handle URL language parameter
  const searchParams = useSearchParams()
  const { setLanguage } = useLanguage()
  const [initialLangSet, setInitialLangSet] = useState(false)

  useEffect(() => {
    // Check for language parameter in URL
    const langParam = searchParams?.get("lang")
    if (langParam && ["en", "es", "fr", "de", "zh"].includes(langParam) && !initialLangSet) {
      try {
        setLanguage(langParam as any)
        setInitialLangSet(true)
      } catch (error) {
        console.error("Error setting language:", error)
      }
    }
  }, [searchParams, setLanguage, initialLangSet])

  return (
    <html lang="en" suppressHydrationWarning>
      <body className={inter.className}>
        <ThemeProvider attribute="class" defaultTheme="system" enableSystem disableTransitionOnChange>
          <LanguageProvider>
            <AuthProvider>
              <AccessibilityProvider>
                <ErrorBoundary>
                  <Analytics />
                  <div className="flex flex-col min-h-screen">
                    <Header />
                    <main className="flex-1">
                      <MouseEffects />
                      {children}
                    </main>
                    <Footer />
                  </div>
                  <AccessibilityMenu />
                </ErrorBoundary>
              </AccessibilityProvider>
            </AuthProvider>
          </LanguageProvider>
        </ThemeProvider>
      </body>
    </html>
  )
}

