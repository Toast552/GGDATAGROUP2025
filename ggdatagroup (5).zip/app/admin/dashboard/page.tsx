"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/components/auth-provider"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCaption, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  BarChart,
  LineChart,
  PieChart,
  Users,
  FileText,
  AlertTriangle,
  CheckCircle,
  XCircle,
  Shield,
  Globe,
  Search,
  RefreshCw,
  Download,
  Trash2,
  Edit,
  Eye,
  Lock,
  AlertCircle,
} from "lucide-react"
import { sanitizeInput, checkRateLimit, logSecurityEvent } from "@/lib/security-utils"
import { trackFeatureUsage, trackButtonClick } from "@/components/analytics-tracker"

// Mock data for the admin dashboard
const mockUsers = [
  { id: 1, name: "John Doe", email: "john@example.com", role: "user", status: "active", lastLogin: "2023-05-15" },
  { id: 2, name: "Jane Smith", email: "jane@example.com", role: "admin", status: "active", lastLogin: "2023-05-16" },
  { id: 3, name: "Bob Johnson", email: "bob@example.com", role: "user", status: "inactive", lastLogin: "2023-04-20" },
  { id: 4, name: "Alice Brown", email: "alice@example.com", role: "user", status: "active", lastLogin: "2023-05-14" },
  { id: 5, name: "Charlie Wilson", email: "charlie@example.com", role: "user", status: "pending", lastLogin: "Never" },
]

const mockEvents = [
  {
    id: 1,
    type: "error",
    message: "Payment processing failed",
    timestamp: "2023-05-16 14:23:45",
    source: "payment-service",
  },
  { id: 2, type: "info", message: "New user registered", timestamp: "2023-05-16 13:12:30", source: "auth-service" },
  {
    id: 3,
    type: "warning",
    message: "High CPU usage detected",
    timestamp: "2023-05-16 12:45:22",
    source: "monitoring",
  },
  {
    id: 4,
    type: "success",
    message: "Database backup completed",
    timestamp: "2023-05-16 12:00:00",
    source: "backup-service",
  },
  { id: 5, type: "error", message: "API rate limit exceeded", timestamp: "2023-05-16 11:30:15", source: "api-gateway" },
]

// Security metrics
const mockSecurityMetrics = {
  failedLogins: 23,
  blockedIPs: 5,
  suspiciousActivities: 12,
  vulnerabilitiesDetected: 3,
  lastSecurityScan: "2023-05-15 08:30:00",
  securityScore: 87,
}

// Traffic analytics
const mockTrafficAnalytics = {
  totalVisits: 12543,
  uniqueVisitors: 8721,
  averageSessionDuration: "2m 34s",
  bounceRate: "32%",
  topReferrers: [
    { source: "Google", visits: 4532 },
    { source: "Direct", visits: 3211 },
    { source: "Twitter", visits: 1245 },
    { source: "LinkedIn", visits: 987 },
  ],
  topPages: [
    { path: "/", visits: 5432 },
    { path: "/services", visits: 2345 },
    { path: "/contact", visits: 1234 },
    { path: "/about", visits: 987 },
  ],
}

export default function AdminDashboardPage() {
  const { user, isAuthenticated, isLoading } = useAuth()
  const router = useRouter()
  const [activeTab, setActiveTab] = useState("dashboard")
  const [searchTerm, setSearchTerm] = useState("")
  const [filteredUsers, setFilteredUsers] = useState(mockUsers)
  const [filteredEvents, setFilteredEvents] = useState(mockEvents)
  const [isRefreshing, setIsRefreshing] = useState(false)

  useEffect(() => {
    // Redirect if not authenticated or not an admin
    if (!isLoading && (!isAuthenticated || user?.role !== "admin")) {
      router.push("/login?redirect=/admin/dashboard")

      // Log security event for unauthorized access attempt
      logSecurityEvent({
        type: "unauthorized_access",
        message: "Unauthorized access attempt to admin dashboard",
        data: { user: user?.email || "unauthenticated" },
        severity: "high",
      })
    } else if (isAuthenticated && user?.role === "admin") {
      // Track admin dashboard access
      trackFeatureUsage("admin_dashboard_access")
    }
  }, [isAuthenticated, isLoading, router, user])

  useEffect(() => {
    // Filter users and events based on search term
    if (searchTerm) {
      const sanitizedSearchTerm = sanitizeInput(searchTerm).toLowerCase()

      setFilteredUsers(
        mockUsers.filter(
          (user) =>
            user.name.toLowerCase().includes(sanitizedSearchTerm) ||
            user.email.toLowerCase().includes(sanitizedSearchTerm) ||
            user.role.toLowerCase().includes(sanitizedSearchTerm) ||
            user.status.toLowerCase().includes(sanitizedSearchTerm),
        ),
      )

      setFilteredEvents(
        mockEvents.filter(
          (event) =>
            event.message.toLowerCase().includes(sanitizedSearchTerm) ||
            event.source.toLowerCase().includes(sanitizedSearchTerm) ||
            event.type.toLowerCase().includes(sanitizedSearchTerm),
        ),
      )
    } else {
      setFilteredUsers(mockUsers)
      setFilteredEvents(mockEvents)
    }
  }, [searchTerm])

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    // Check for rate limiting (10 searches per minute)
    const clientId = localStorage.getItem("client_id") || "anonymous"
    const isRateLimited = checkRateLimit(`admin_search:${clientId}`, 10, 60000)

    if (isRateLimited) {
      logSecurityEvent({
        type: "rate_limit",
        message: "Admin search rate limit exceeded",
        data: { clientId },
        severity: "medium",
      })
      return
    }

    setSearchTerm(e.target.value)
  }

  const handleRefresh = () => {
    setIsRefreshing(true)
    trackButtonClick("admin_refresh")

    // Simulate data refresh
    setTimeout(() => {
      setIsRefreshing(false)
    }, 1000)
  }

  const handleTabChange = (value: string) => {
    setActiveTab(value)
    trackFeatureUsage("admin_tab_change", { tab: value })
  }

  const handleUserAction = (action: string, userId: number) => {
    trackButtonClick("admin_user_action", { action, userId })
    // In a real app, this would call an API to perform the action
    console.log(`User action: ${action} for user ID: ${userId}`)
  }

  const getEventIcon = (type: string) => {
    switch (type) {
      case "error":
        return <XCircle className="h-5 w-5 text-red-500" />
      case "warning":
        return <AlertTriangle className="h-5 w-5 text-yellow-500" />
      case "success":
        return <CheckCircle className="h-5 w-5 text-green-500" />
      case "info":
      default:
        return <FileText className="h-5 w-5 text-blue-500" />
    }
  }

  if (isLoading || !isAuthenticated || user?.role !== "admin") {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    )
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <h1 className="text-3xl font-bold mb-6">Admin Dashboard</h1>

      <div className="mb-6 flex flex-col sm:flex-row justify-between gap-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
          <Input
            type="search"
            placeholder="Search users, events, or content..."
            value={searchTerm}
            onChange={handleSearch}
            className="pl-10 w-full sm:w-80"
          />
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={handleRefresh} disabled={isRefreshing}>
            <RefreshCw className={`h-4 w-4 mr-2 ${isRefreshing ? "animate-spin" : ""}`} />
            Refresh
          </Button>
          <Button variant="outline" size="sm">
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={handleTabChange} className="space-y-4">
        <TabsList className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 lg:grid-cols-6">
          <TabsTrigger value="dashboard" className="flex items-center gap-2">
            <BarChart className="h-4 w-4" />
            <span className="hidden sm:inline">Dashboard</span>
          </TabsTrigger>
          <TabsTrigger value="users" className="flex items-center gap-2">
            <Users className="h-4 w-4" />
            <span className="hidden sm:inline">Users</span>
          </TabsTrigger>
          <TabsTrigger value="content" className="flex items-center gap-2">
            <FileText className="h-4 w-4" />
            <span className="hidden sm:inline">Content</span>
          </TabsTrigger>
          <TabsTrigger value="logs" className="flex items-center gap-2">
            <AlertTriangle className="h-4 w-4" />
            <span className="hidden sm:inline">Logs</span>
          </TabsTrigger>
          <TabsTrigger value="security" className="flex items-center gap-2">
            <Shield className="h-4 w-4" />
            <span className="hidden sm:inline">Security</span>
          </TabsTrigger>
          <TabsTrigger value="analytics" className="flex items-center gap-2">
            <LineChart className="h-4 w-4" />
            <span className="hidden sm:inline">Analytics</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="dashboard" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Users</CardTitle>
                <Users className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{mockUsers.length}</div>
                <p className="text-xs text-muted-foreground">+12% from last month</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Active Sessions</CardTitle>
                <Users className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">342</div>
                <p className="text-xs text-muted-foreground">+5% from last hour</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Security Score</CardTitle>
                <Shield className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{mockSecurityMetrics.securityScore}%</div>
                <p className="text-xs text-muted-foreground">+2% from last scan</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Visits</CardTitle>
                <Globe className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{mockTrafficAnalytics.totalVisits.toLocaleString()}</div>
                <p className="text-xs text-muted-foreground">+8% from last week</p>
              </CardContent>
            </Card>
          </div>

          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle>Recent Activity</CardTitle>
                <CardDescription>System events from the last 24 hours</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {filteredEvents.slice(0, 5).map((event) => (
                    <div key={event.id} className="flex items-center gap-4 border-b pb-2">
                      {getEventIcon(event.type)}
                      <div>
                        <p className="text-sm font-medium">{event.message}</p>
                        <p className="text-xs text-muted-foreground">
                          {event.timestamp} • {event.source}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>User Distribution</CardTitle>
                <CardDescription>Active users by role</CardDescription>
              </CardHeader>
              <CardContent className="flex items-center justify-center p-6">
                <div className="flex items-center gap-8">
                  <div className="text-center">
                    <PieChart className="h-16 w-16 mx-auto text-primary" />
                    <div className="mt-2 space-y-1">
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 rounded-full bg-primary"></div>
                        <span className="text-sm">Admin (5%)</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 rounded-full bg-blue-400"></div>
                        <span className="text-sm">Moderator (15%)</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 rounded-full bg-blue-200"></div>
                        <span className="text-sm">User (80%)</span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="users" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>User Management</CardTitle>
              <CardDescription>Manage user accounts and permissions</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableCaption>A list of all registered users.</TableCaption>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Role</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Last Login</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredUsers.map((user) => (
                    <TableRow key={user.id}>
                      <TableCell className="font-medium">{user.name}</TableCell>
                      <TableCell>{user.email}</TableCell>
                      <TableCell>{user.role}</TableCell>
                      <TableCell>
                        <span
                          className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                            user.status === "active"
                              ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"
                              : user.status === "inactive"
                                ? "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300"
                                : "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300"
                          }`}
                        >
                          {user.status}
                        </span>
                      </TableCell>
                      <TableCell>{user.lastLogin}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleUserAction("view", user.id)}
                            title="View user"
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleUserAction("edit", user.id)}
                            title="Edit user"
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleUserAction("delete", user.id)}
                            title="Delete user"
                          >
                            <Trash2 className="h-4 w-4 text-red-500" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="security" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Failed Logins</CardTitle>
                <Lock className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{mockSecurityMetrics.failedLogins}</div>
                <p className="text-xs text-muted-foreground">Last 24 hours</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Blocked IPs</CardTitle>
                <Shield className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{mockSecurityMetrics.blockedIPs}</div>
                <p className="text-xs text-muted-foreground">Active blocks</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Suspicious Activities</CardTitle>
                <AlertTriangle className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{mockSecurityMetrics.suspiciousActivities}</div>
                <p className="text-xs text-muted-foreground">Requires review</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Vulnerabilities</CardTitle>
                <AlertCircle className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{mockSecurityMetrics.vulnerabilitiesDetected}</div>
                <p className="text-xs text-muted-foreground">Detected in last scan</p>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Security Audit Log</CardTitle>
              <CardDescription>Recent security events and activities</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableCaption>Security events from the last 7 days.</TableCaption>
                <TableHeader>
                  <TableRow>
                    <TableHead>Event</TableHead>
                    <TableHead>IP Address</TableHead>
                    <TableHead>User</TableHead>
                    <TableHead>Timestamp</TableHead>
                    <TableHead>Severity</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  <TableRow>
                    <TableCell className="font-medium">Failed login attempt</TableCell>
                    <TableCell>192.168.1.105</TableCell>
                    <TableCell>john@example.com</TableCell>
                    <TableCell>2023-05-16 14:23:45</TableCell>
                    <TableCell>
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300">
                        Medium
                      </span>
                    </TableCell>
                    <TableCell className="text-right">
                      <Button variant="ghost" size="sm">
                        Details
                      </Button>
                    </TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell className="font-medium">Suspicious file upload</TableCell>
                    <TableCell>203.0.113.42</TableCell>
                    <TableCell>alice@example.com</TableCell>
                    <TableCell>2023-05-16 12:45:22</TableCell>
                    <TableCell>
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300">
                        High
                      </span>
                    </TableCell>
                    <TableCell className="text-right">
                      <Button variant="ghost" size="sm">
                        Details
                      </Button>
                    </TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell className="font-medium">Admin login</TableCell>
                    <TableCell>192.168.1.1</TableCell>
                    <TableCell>admin@example.com</TableCell>
                    <TableCell>2023-05-16 10:30:15</TableCell>
                    <TableCell>
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300">
                        Info
                      </span>
                    </TableCell>
                    <TableCell className="text-right">
                      <Button variant="ghost" size="sm">
                        Details
                      </Button>
                    </TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analytics" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Card className="md:col-span-2">
              <CardHeader>
                <CardTitle>Traffic Overview</CardTitle>
                <CardDescription>Website traffic and user engagement metrics</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4 md:grid-cols-4">
                  <div className="space-y-2">
                    <p className="text-sm font-medium text-muted-foreground">Total Visits</p>
                    <p className="text-2xl font-bold">{mockTrafficAnalytics.totalVisits.toLocaleString()}</p>
                  </div>
                  <div className="space-y-2">
                    <p className="text-sm font-medium text-muted-foreground">Unique Visitors</p>
                    <p className="text-2xl font-bold">{mockTrafficAnalytics.uniqueVisitors.toLocaleString()}</p>
                  </div>
                  <div className="space-y-2">
                    <p className="text-sm font-medium text-muted-foreground">Avg. Session Duration</p>
                    <p className="text-2xl font-bold">{mockTrafficAnalytics.averageSessionDuration}</p>
                  </div>
                  <div className="space-y-2">
                    <p className="text-sm font-medium text-muted-foreground">Bounce Rate</p>
                    <p className="text-2xl font-bold">{mockTrafficAnalytics.bounceRate}</p>
                  </div>
                </div>

                <div className="h-[300px] mt-6 flex items-center justify-center border rounded">
                  <LineChart className="h-16 w-16 text-muted-foreground" />
                  <p className="ml-4 text-muted-foreground">Traffic visualization would appear here</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Top Referrers</CardTitle>
                <CardDescription>Sources driving traffic to your site</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {mockTrafficAnalytics.topReferrers.map((referrer, index) => (
                    <div key={index} className="flex items-center justify-between">
                      <div className="flex items-center">
                        <div className="w-2 h-2 rounded-full bg-primary mr-2"></div>
                        <span>{referrer.source}</span>
                      </div>
                      <span className="font-medium">{referrer.visits.toLocaleString()}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Top Pages</CardTitle>
                <CardDescription>Most visited pages on your site</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {mockTrafficAnalytics.topPages.map((page, index) => (
                    <div key={index} className="flex items-center justify-between">
                      <div className="flex items-center">
                        <div className="w-2 h-2 rounded-full bg-primary mr-2"></div>
                        <span>{page.path}</span>
                      </div>
                      <span className="font-medium">{page.visits.toLocaleString()}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="logs" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>System Logs</CardTitle>
              <CardDescription>View and filter system events</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableCaption>Recent system events and logs.</TableCaption>
                <TableHeader>
                  <TableRow>
                    <TableHead>Type</TableHead>
                    <TableHead>Message</TableHead>
                    <TableHead>Source</TableHead>
                    <TableHead>Timestamp</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredEvents.map((event) => (
                    <TableRow key={event.id}>
                      <TableCell>
                        <div className="flex items-center">
                          {getEventIcon(event.type)}
                          <span className="ml-2 capitalize">{event.type}</span>
                        </div>
                      </TableCell>
                      <TableCell className="font-medium">{event.message}</TableCell>
                      <TableCell>{event.source}</TableCell>
                      <TableCell>{event.timestamp}</TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="sm">
                          Details
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="content" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Content Management</CardTitle>
              <CardDescription>Manage website content and pages</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-end">
                  <Button>Create New Page</Button>
                </div>
                <Table>
                  <TableCaption>All published and draft content.</TableCaption>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Title</TableHead>
                      <TableHead>Author</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Published Date</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow>
                      <TableCell className="font-medium">Home Page</TableCell>
                      <TableCell>Admin</TableCell>
                      <TableCell>
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300">
                          Published
                        </span>
                      </TableCell>
                      <TableCell>2023-05-10</TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button variant="ghost" size="icon" title="View page">
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon" title="Edit page">
                            <Edit className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">Services Page</TableCell>
                      <TableCell>Admin</TableCell>
                      <TableCell>
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300">
                          Published
                        </span>
                      </TableCell>
                      <TableCell>2023-05-12</TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button variant="ghost" size="icon" title="View page">
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon" title="Edit page">
                            <Edit className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">About Us</TableCell>
                      <TableCell>Jane Smith</TableCell>
                      <TableCell>
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300">
                          Draft
                        </span>
                      </TableCell>
                      <TableCell>-</TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button variant="ghost" size="icon" title="View page">
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon" title="Edit page">
                            <Edit className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

