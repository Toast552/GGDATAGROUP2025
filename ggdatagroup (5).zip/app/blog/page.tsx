import Link from "next/link"
import Image from "next/image"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import { ChevronRight, Calendar, Clock } from "lucide-react"

// Mock blog posts data - in a real app, this would come from a CMS or API
const blogPosts = [
  {
    id: 1,
    title: "The Evolution of Algorithmic Trading in Modern Markets",
    excerpt:
      "Explore how algorithmic trading has transformed financial markets and the technologies driving its evolution.",
    content: "Full content would be here...",
    date: "March 15, 2023",
    author: {
      name: "Dr. Sarah Johnson",
      title: "Chief Data Scientist",
      image: "/placeholder.svg?height=80&width=80",
    },
    readTime: 8,
    slug: "evolution-algorithmic-trading",
    category: "Trading Technology",
    tags: ["Algorithmic Trading", "Market Analysis", "Technology"],
    image: "/placeholder.svg?height=600&width=1200",
    featured: true,
  },
  {
    id: 2,
    title: "Blockchain Technology: Beyond Cryptocurrency",
    excerpt:
      "Discover how blockchain technology is revolutionizing industries beyond cryptocurrency, from supply chain to healthcare.",
    content: "Full content would be here...",
    date: "April 22, 2023",
    author: {
      name: "Michael Chen",
      title: "Blockchain Specialist",
      image: "/placeholder.svg?height=80&width=80",
    },
    readTime: 10,
    slug: "blockchain-beyond-cryptocurrency",
    category: "Blockchain",
    tags: ["Blockchain", "DLT", "Enterprise Solutions"],
    image: "/placeholder.svg?height=600&width=1200",
    featured: false,
  },
  {
    id: 3,
    title: "AI-Powered Data Analytics: Transforming Financial Decision Making",
    excerpt:
      "Learn how artificial intelligence is revolutionizing data analytics and providing deeper insights for financial institutions.",
    content: "Full content would be here...",
    date: "May 10, 2023",
    author: {
      name: "Dr. Emily Rodriguez",
      title: "AI Research Lead",
      image: "/placeholder.svg?height=80&width=80",
    },
    readTime: 12,
    slug: "ai-powered-financial-analytics",
    category: "AI & Analytics",
    tags: ["Artificial Intelligence", "Data Analytics", "Finance"],
    image: "/placeholder.svg?height=600&width=1200",
    featured: true,
  },
  {
    id: 4,
    title: "Cybersecurity Best Practices for Financial Institutions",
    excerpt:
      "Explore comprehensive cybersecurity strategies to protect sensitive financial data and systems from evolving threats.",
    content: "Full content would be here...",
    date: "June 5, 2023",
    author: {
      name: "James Wilson",
      title: "Head of Cybersecurity",
      image: "/placeholder.svg?height=80&width=80",
    },
    readTime: 9,
    slug: "cybersecurity-financial-institutions",
    category: "Security",
    tags: ["Cybersecurity", "Risk Management", "Compliance"],
    image: "/placeholder.svg?height=600&width=1200",
    featured: false,
  },
  {
    id: 5,
    title: "Quantum Computing: The Next Frontier in Financial Technology",
    excerpt:
      "Understand how quantum computing is poised to transform financial modeling, cryptography, and risk assessment.",
    content: "Full content would be here...",
    date: "July 18, 2023",
    author: {
      name: "Dr. Robert Chang",
      title: "Quantum Computing Researcher",
      image: "/placeholder.svg?height=80&width=80",
    },
    readTime: 15,
    slug: "quantum-computing-finance",
    category: "Emerging Technology",
    tags: ["Quantum Computing", "Financial Technology", "Innovation"],
    image: "/placeholder.svg?height=600&width=1200",
    featured: false,
  },
  {
    id: 6,
    title: "Regulatory Technology (RegTech): Streamlining Compliance in Finance",
    excerpt:
      "Discover how RegTech solutions are helping financial institutions navigate complex regulatory landscapes more efficiently.",
    content: "Full content would be here...",
    date: "August 30, 2023",
    author: {
      name: "Lisa Thompson",
      title: "Regulatory Compliance Expert",
      image: "/placeholder.svg?height=80&width=80",
    },
    readTime: 11,
    slug: "regtech-financial-compliance",
    category: "Compliance",
    tags: ["RegTech", "Compliance", "Financial Regulation"],
    image: "/placeholder.svg?height=600&width=1200",
    featured: false,
  },
]

// Get featured posts
const featuredPosts = blogPosts.filter((post) => post.featured)

// Get all categories
const categories = Array.from(new Set(blogPosts.map((post) => post.category)))

export default function BlogPage() {
  return (
    <div className="container py-12">
      {/* Page Header */}
      <div className="max-w-4xl mx-auto text-center mb-12">
        <h1 className="text-4xl font-bold tracking-tight sm:text-5xl md:text-6xl mb-4">Insights & Analysis</h1>
        <p className="text-xl text-muted-foreground md:text-2xl max-w-2xl mx-auto">
          Expert perspectives on financial markets, technology, and data analytics from industry leaders.
        </p>
      </div>

      {/* Featured Posts Section */}
      {featuredPosts.length > 0 && (
        <section className="mb-16">
          <h2 className="text-2xl font-bold mb-6">Featured Articles</h2>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {featuredPosts.map((post) => (
              <Card key={post.id} className="overflow-hidden h-full flex flex-col">
                <div className="relative h-64 w-full">
                  <Image
                    src={post.image || "/placeholder.svg"}
                    alt={post.title}
                    fill
                    className="object-cover"
                    priority={post.id === 1}
                  />
                  <div className="absolute top-4 left-4 bg-primary text-primary-foreground px-3 py-1 rounded-full text-sm font-medium">
                    {post.category}
                  </div>
                </div>
                <CardHeader>
                  <CardTitle className="text-2xl">
                    <Link href={`/blog/${post.slug}`} className="hover:text-primary transition-colors">
                      {post.title}
                    </Link>
                  </CardTitle>
                  <CardDescription className="flex items-center gap-4 text-sm">
                    <span className="flex items-center">
                      <Calendar className="h-4 w-4 mr-1" />
                      {post.date}
                    </span>
                    <span className="flex items-center">
                      <Clock className="h-4 w-4 mr-1" />
                      {post.readTime} min read
                    </span>
                  </CardDescription>
                </CardHeader>
                <CardContent className="flex-grow">
                  <p className="text-muted-foreground">{post.excerpt}</p>
                </CardContent>
                <CardFooter className="flex justify-between items-center pt-4 border-t">
                  <div className="flex items-center">
                    <Image
                      src={post.author.image || "/placeholder.svg"}
                      alt={post.author.name}
                      width={32}
                      height={32}
                      className="rounded-full mr-2"
                    />
                    <div>
                      <p className="text-sm font-medium">{post.author.name}</p>
                      <p className="text-xs text-muted-foreground">{post.author.title}</p>
                    </div>
                  </div>
                  <Link href={`/blog/${post.slug}`}>
                    <Button variant="ghost" size="sm" className="group">
                      Read More
                      <ChevronRight className="ml-1 h-4 w-4 transition-transform group-hover:translate-x-1" />
                    </Button>
                  </Link>
                </CardFooter>
              </Card>
            ))}
          </div>
        </section>
      )}

      {/* Categories Section */}
      <section className="mb-12">
        <h2 className="text-2xl font-bold mb-6">Categories</h2>
        <div className="flex flex-wrap gap-3">
          {categories.map((category) => (
            <Link
              key={category}
              href={`/blog/category/${category.toLowerCase().replace(/\s+/g, "-")}`}
              className="px-4 py-2 bg-muted hover:bg-muted/80 rounded-full text-sm font-medium transition-colors"
            >
              {category}
            </Link>
          ))}
        </div>
      </section>

      <Separator className="my-12" />

      {/* All Posts Section */}
      <section>
        <h2 className="text-2xl font-bold mb-6">Latest Articles</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {blogPosts.map((post) => (
            <Card key={post.id} className="overflow-hidden h-full flex flex-col">
              <div className="relative h-48 w-full">
                <Image src={post.image || "/placeholder.svg"} alt={post.title} fill className="object-cover" />
              </div>
              <CardHeader className="pb-2">
                <div className="text-sm text-primary font-medium mb-1">{post.category}</div>
                <CardTitle className="line-clamp-2">
                  <Link href={`/blog/${post.slug}`} className="hover:text-primary transition-colors">
                    {post.title}
                  </Link>
                </CardTitle>
              </CardHeader>
              <CardContent className="flex-grow pb-2">
                <p className="text-muted-foreground text-sm line-clamp-3">{post.excerpt}</p>
              </CardContent>
              <CardFooter className="pt-2 border-t">
                <div className="flex items-center justify-between w-full">
                  <div className="flex items-center">
                    <Image
                      src={post.author.image || "/placeholder.svg"}
                      alt={post.author.name}
                      width={24}
                      height={24}
                      className="rounded-full mr-2"
                    />
                    <span className="text-xs">{post.author.name}</span>
                  </div>
                  <div className="flex items-center text-xs text-muted-foreground">
                    <Calendar className="h-3 w-3 mr-1" />
                    {post.date}
                  </div>
                </div>
              </CardFooter>
            </Card>
          ))}
        </div>

        <div className="mt-12 text-center">
          <Button variant="outline" size="lg">
            Load More Articles
          </Button>
        </div>
      </section>

      {/* Newsletter Section */}
      <section className="mt-20 bg-muted rounded-lg p-8 md:p-12">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-2xl md:text-3xl font-bold mb-4">Stay Informed</h2>

          <p className="text-lg text-muted-foreground mb-6">
            Subscribe to our newsletter for the latest insights, analysis, and market trends delivered directly to your
            inbox.
          </p>

          <form className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto">
            <input
              type="email"
              placeholder="Enter your email"
              className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
              required
            />
            <Button type="submit">Subscribe</Button>
          </form>
        </div>
      </section>
    </div>
  )
}

