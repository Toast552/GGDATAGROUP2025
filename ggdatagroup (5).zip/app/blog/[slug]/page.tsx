"use client"

import { Card } from "@/components/ui/card"

import { useParams } from "next/navigation"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { ChevronLeft, Calendar, Clock, Tag, Share2, Bookmark, ThumbsUp, MessageSquare } from "lucide-react"

// Mock blog posts data - in a real app, this would come from a CMS or API
const blogPosts = [
  {
    id: 1,
    title: "The Evolution of Algorithmic Trading in Modern Markets",
    excerpt:
      "Explore how algorithmic trading has transformed financial markets and the technologies driving its evolution.",
    content: `
      <p class="lead">Algorithmic trading has fundamentally transformed financial markets over the past two decades, evolving from simple automated execution systems to sophisticated strategies leveraging artificial intelligence and machine learning.</p>
      
      <h2>The Origins of Algorithmic Trading</h2>
      <p>The roots of algorithmic trading can be traced back to the 1970s with the introduction of the first electronic trading systems. However, it wasn't until the late 1990s and early 2000s that algorithmic trading began to gain significant traction in financial markets. The advent of electronic communication networks (ECNs) and improvements in computing power made it possible to execute trades with minimal human intervention.</p>
      
      <p>Early algorithmic trading strategies were primarily focused on execution algorithms designed to minimize market impact and transaction costs. These algorithms would break large orders into smaller pieces and execute them over time to avoid moving the market against the trader.</p>
      
      <h2>High-Frequency Trading: Speed Becomes the Competitive Edge</h2>
      <p>The mid-2000s saw the rise of high-frequency trading (HFT), a subset of algorithmic trading characterized by extremely high speeds, high turnover rates, and high order-to-trade ratios. HFT firms invested heavily in technology infrastructure to gain microsecond advantages over competitors:</p>
      
      <ul>
        <li>Co-location services, allowing traders to place their servers in the same data centers as exchanges</li>
        <li>Custom hardware solutions optimized for trading applications</li>
        <li>Ultra-low latency network connections between markets</li>
        <li>Specialized algorithms designed to capitalize on tiny price discrepancies</li>
      </ul>
      
      <p>By 2010, HFT accounted for over 60% of all U.S. equity trading volume, dramatically changing market microstructure and raising questions about market fairness and stability.</p>
      
      <h2>The Integration of Advanced Analytics and AI</h2>
      <p>The next evolutionary phase of algorithmic trading has been characterized by the integration of advanced analytics, big data, and artificial intelligence. Modern trading algorithms can:</p>
      
      <ul>
        <li>Process vast amounts of structured and unstructured data, including news, social media, and alternative data sources</li>
        <li>Identify complex patterns that would be impossible for human traders to detect</li>
        <li>Adapt to changing market conditions through machine learning techniques</li>
        <li>Manage risk more effectively by continuously monitoring multiple risk factors</li>
      </ul>
      
      <p>Deep learning models, in particular, have shown promise in capturing non-linear relationships in financial data and making more accurate predictions about market movements.</p>
      
      <h2>Regulatory Responses and Market Structure Changes</h2>
      <p>The rapid growth of algorithmic trading has prompted significant regulatory responses. After the 2010 "Flash Crash," when the Dow Jones Industrial Average dropped nearly 1,000 points in minutes before recovering, regulators implemented various measures:</p>
      
      <ul>
        <li>Circuit breakers to halt trading during extreme volatility</li>
        <li>Requirements for testing and risk controls for algorithmic trading systems</li>
        <li>Enhanced market surveillance capabilities</li>
        <li>Regulations specifically targeting high-frequency trading practices</li>
      </ul>
      
      <p>These regulatory changes have shaped the evolution of algorithmic trading strategies and the technology infrastructure supporting them.</p>
      
      <h2>The Future: Quantum Computing and Beyond</h2>
      <p>Looking ahead, several emerging technologies are poised to further transform algorithmic trading:</p>
      
      <ul>
        <li><strong>Quantum Computing:</strong> Promises to solve complex optimization problems that are currently intractable, potentially revolutionizing portfolio optimization and risk management</li>
        <li><strong>Federated Learning:</strong> Allows models to be trained across multiple decentralized devices holding local data samples, addressing privacy concerns</li>
        <li><strong>Explainable AI:</strong> Developing algorithms that can provide clear explanations for their trading decisions, addressing regulatory concerns about "black box" systems</li>
        <li><strong>Blockchain and DLT:</strong> May transform market infrastructure, enabling new types of algorithmic trading strategies in decentralized markets</li>
      </ul>
      
      <h2>Conclusion</h2>
      <p>Algorithmic trading has evolved from simple automated execution to sophisticated AI-driven strategies that can process vast amounts of data and adapt to changing market conditions. As technology continues to advance, the line between human and machine decision-making in financial markets will likely continue to blur, raising important questions about market structure, regulation, and the future of trading itself.</p>
      
      <p>For financial institutions and market participants, staying at the forefront of these technological developments will be crucial for maintaining competitive advantage in increasingly automated markets.</p>
    `,
    date: "March 15, 2023",
    author: {
      name: "Dr. Sarah Johnson",
      title: "Chief Data Scientist",
      bio: "Dr. Sarah Johnson has over 15 years of experience in quantitative finance and machine learning applications in financial markets. She holds a Ph.D. in Computer Science from MIT and previously worked at leading quantitative trading firms.",
      image: "/placeholder.svg?height=80&width=80",
    },
    readTime: 8,
    slug: "evolution-algorithmic-trading",
    category: "Trading Technology",
    tags: ["Algorithmic Trading", "Market Analysis", "Technology", "High-Frequency Trading", "AI"],
    image: "/placeholder.svg?height=600&width=1200",
    featured: true,
    relatedPosts: [2, 3, 5],
  },
  // Other blog posts...
]

// Function to get related posts
const getRelatedPosts = (currentPost) => {
  if (!currentPost.relatedPosts) return []
  return currentPost.relatedPosts.map((id) => blogPosts.find((post) => post.id === id)).filter(Boolean)
}

export default function BlogPostPage() {
  const params = useParams()
  const slug = params?.slug as string

  // Find the blog post with the matching slug
  const post = blogPosts.find((post) => post.slug === slug)

  // Get related posts
  const relatedPosts = post ? getRelatedPosts(post) : []

  // If post not found, show a message
  if (!post) {
    return (
      <div className="container py-12 text-center">
        <h1 className="text-3xl font-bold mb-4">Post Not Found</h1>
        <p className="text-muted-foreground mb-6">
          The blog post you're looking for doesn't exist or has been removed.
        </p>
        <Link href="/blog">
          <Button>Back to Blog</Button>
        </Link>
      </div>
    )
  }

  return (
    <div className="container py-12">
      <div className="max-w-4xl mx-auto">
        {/* Breadcrumb */}
        <div className="flex items-center text-sm text-muted-foreground mb-8">
          <Link href="/" className="hover:text-foreground">
            Home
          </Link>
          <span className="mx-2">/</span>
          <Link href="/blog" className="hover:text-foreground">
            Blog
          </Link>
          <span className="mx-2">/</span>
          <Link
            href={`/blog/category/${post.category.toLowerCase().replace(/\s+/g, "-")}`}
            className="hover:text-foreground"
          >
            {post.category}
          </Link>
          <span className="mx-2">/</span>
          <span className="text-foreground">{post.title}</span>
        </div>

        {/* Back to Blog */}
        <Link href="/blog" className="inline-flex items-center text-muted-foreground hover:text-foreground mb-6">
          <ChevronLeft className="mr-2 h-4 w-4" />
          Back to Blog
        </Link>

        {/* Post Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl mb-4">{post.title}</h1>

          <div className="flex flex-wrap items-center gap-4 mb-6 text-sm text-muted-foreground">
            <div className="flex items-center">
              <Calendar className="mr-2 h-4 w-4" />
              {post.date}
            </div>
            <div className="flex items-center">
              <Clock className="mr-2 h-4 w-4" />
              {post.readTime} min read
            </div>
            <div className="flex items-center">
              <Tag className="mr-2 h-4 w-4" />
              {post.category}
            </div>
          </div>

          <div className="flex items-center">
            <Image
              src={post.author.image || "/placeholder.svg"}
              alt={post.author.name}
              width={48}
              height={48}
              className="rounded-full mr-4"
            />
            <div>
              <p className="font-medium">{post.author.name}</p>
              <p className="text-sm text-muted-foreground">{post.author.title}</p>
            </div>
          </div>
        </div>

        {/* Featured Image */}
        <div className="relative h-[400px] w-full mb-8 rounded-lg overflow-hidden">
          <Image src={post.image || "/placeholder.svg"} alt={post.title} fill className="object-cover" priority />
        </div>

        {/* Post Content */}
        <div
          className="prose prose-lg dark:prose-invert max-w-none mb-12"
          dangerouslySetInnerHTML={{ __html: post.content }}
        />

        {/* Tags */}
        <div className="mb-8">
          <h3 className="text-lg font-medium mb-3">Tags</h3>
          <div className="flex flex-wrap gap-2">
            {post.tags.map((tag) => (
              <Link
                key={tag}
                href={`/blog/tag/${tag.toLowerCase().replace(/\s+/g, "-")}`}
                className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-muted hover:bg-muted/80 transition-colors"
              >
                {tag}
              </Link>
            ))}
          </div>
        </div>

        {/* Author Bio */}
        <div className="bg-muted p-6 rounded-lg mb-12">
          <div className="flex items-start">
            <Image
              src={post.author.image || "/placeholder.svg"}
              alt={post.author.name}
              width={80}
              height={80}
              className="rounded-full mr-6"
            />
            <div>
              <h3 className="text-xl font-bold mb-2">About {post.author.name}</h3>
              <p className="text-muted-foreground mb-4">{post.author.bio}</p>
              <div className="flex gap-3">
                <Button variant="outline" size="sm">
                  View Profile
                </Button>
                <Button variant="outline" size="sm">
                  Follow
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Social Sharing and Engagement */}
        <div className="flex justify-between items-center mb-12 py-4 border-y">
          <div className="flex gap-2">
            <Button variant="outline" size="sm" className="flex items-center gap-1">
              <ThumbsUp className="h-4 w-4" />
              <span>Like</span>
            </Button>
            <Button variant="outline" size="sm" className="flex items-center gap-1">
              <MessageSquare className="h-4 w-4" />
              <span>Comment</span>
            </Button>
            <Button variant="outline" size="sm" className="flex items-center gap-1">
              <Bookmark className="h-4 w-4" />
              <span>Save</span>
            </Button>
          </div>

          <div className="flex gap-2">
            <Button variant="outline" size="icon" aria-label="Share on Twitter">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="lucide lucide-twitter"
              >
                <path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z" />
              </svg>
            </Button>
            <Button variant="outline" size="icon" aria-label="Share on LinkedIn">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="lucide lucide-linkedin"
              >
                <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z" />
                <rect width="4" height="12" x="2" y="9" />
                <circle cx="4" cy="4" r="2" />
              </svg>
            </Button>
            <Button variant="outline" size="icon" aria-label="Share via Email">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="lucide lucide-mail"
              >
                <rect width="20" height="16" x="2" y="4" rx="2" />
                <path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7" />
              </svg>
            </Button>
            <Button variant="outline" size="icon" aria-label="Copy Link">
              <Share2 className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* Related Posts */}
        {relatedPosts.length > 0 && (
          <div className="mb-12">
            <h2 className="text-2xl font-bold mb-6">Related Articles</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {relatedPosts.map((relatedPost) => (
                <Card key={relatedPost.id} className="overflow-hidden h-full flex flex-col">
                  <div className="relative h-40 w-full">
                    <Image
                      src={relatedPost.image || "/placeholder.svg"}
                      alt={relatedPost.title}
                      fill
                      className="object-cover"
                    />
                  </div>
                  <div className="p-4 flex flex-col flex-grow">
                    <div className="text-sm text-primary font-medium mb-1">{relatedPost.category}</div>
                    <h3 className="text-lg font-medium mb-2 line-clamp-2">
                      <Link href={`/blog/${relatedPost.slug}`} className="hover:text-primary transition-colors">
                        {relatedPost.title}
                      </Link>
                    </h3>
                    <p className="text-sm text-muted-foreground line-clamp-2 mb-4">{relatedPost.excerpt}</p>
                    <div className="mt-auto flex items-center justify-between text-xs">
                      <span>{relatedPost.date}</span>
                      <span>{relatedPost.readTime} min read</span>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Comments Section Placeholder */}
        <div className="mb-12">
          <h2 className="text-2xl font-bold mb-6">Comments</h2>
          <div className="bg-muted p-8 rounded-lg text-center">
            <p className="text-muted-foreground mb-4">Join the discussion by signing in to leave a comment.</p>
            <Button>Sign In to Comment</Button>
          </div>
        </div>
      </div>
    </div>
  )
}

