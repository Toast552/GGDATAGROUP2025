import { type NextRequest, NextResponse } from "next/server"
import { z } from "zod"
import { logger } from "@/lib/logger"
import { sanitizeInput } from "@/lib/security-utils"

// Define the schema for contact form data
const contactFormSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  email: z.string().email("Invalid email address"),
  message: z.string().min(10, "Message must be at least 10 characters"),
  company: z.string().optional(),
  phone: z.string().optional(),
})

export async function POST(request: NextRequest) {
  try {
    // Parse and validate the request body
    const rawData = await request.json()

    // Sanitize inputs to prevent XSS
    const sanitizedData = {
      name: sanitizeInput(rawData.name),
      email: sanitizeInput(rawData.email),
      message: sanitizeInput(rawData.message),
      company: rawData.company ? sanitizeInput(rawData.company) : undefined,
      phone: rawData.phone ? sanitizeInput(rawData.phone) : undefined,
    }

    // Validate the sanitized data
    const result = contactFormSchema.safeParse(sanitizedData)

    if (!result.success) {
      logger.warn("Contact form validation failed", { errors: result.error.format() })
      return NextResponse.json({ success: false, errors: result.error.format() }, { status: 400 })
    }

    // In a real app, you would send an email, store in database, etc.
    logger.info("Contact form submission received", { data: result.data })

    // Simulate processing delay
    await new Promise((resolve) => setTimeout(resolve, 1000))

    return NextResponse.json(
      {
        success: true,
        message: "Thank you for your message. We'll get back to you soon!",
      },
      { status: 200 },
    )
  } catch (error) {
    logger.error("Error processing contact form", { error })
    return NextResponse.json(
      {
        success: false,
        message: "An error occurred while processing your request.",
      },
      { status: 500 },
    )
  }
}

