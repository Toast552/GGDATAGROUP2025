import { Card, CardContent } from "@/components/ui/card"

export default function AboutPage() {
  return (
    <div className="container py-10">
      <div className="max-w-3xl mx-auto text-center mb-10">
        <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl mb-4">About G&G Holdings</h1>
        <p className="text-muted-foreground md:text-xl">Learn more about our company and our mission</p>
      </div>

      <div className="grid grid-cols-1 gap-10 max-w-4xl mx-auto">
        <div>
          <h2 className="text-2xl font-bold mb-4">Our Story</h2>
          <p className="text-muted-foreground mb-4">
            G&G Holdings was founded with a clear vision: to make cryptography accessible, efficient, and profitable for
            everyone. What began as a small team of passionate crypto enthusiasts has grown into a trusted provider of
            cryptography solutions, hosting services, and educational resources.
          </p>
          <p className="text-muted-foreground">
            Our journey started when our founders recognized the challenges faced by individuals and businesses entering
            the world of cryptography. The complex technical requirements, high energy costs, and lack of reliable
            information created significant barriers to entry. G&G Holdings was established to address these challenges
            and provide comprehensive solutions that empower our clients to succeed.
          </p>
        </div>

        <Card className="bg-muted/50">
          <CardContent className="p-6">
            <h2 className="text-2xl font-bold mb-4">Our Mission</h2>
            <p className="mb-4">
              At G&G Holdings Group, we are passionate about educating, consulting, and empowering our clients to thrive
              in the dynamic world of cryptography. Our mission is to deliver customized solutions that align with your
              unique needs, helping you achieve your goals with confidence.
            </p>
            <p>
              We believe that cryptography should be accessible to everyone, regardless of technical expertise or scale
              of operation. Through our services, resources, and support, we aim to democratize access to cryptography
              and help our clients navigate this exciting and evolving field.
            </p>
          </CardContent>
        </Card>

        <div>
          <h2 className="text-2xl font-bold mb-4">Our Values</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="p-4 border rounded-lg">
              <h3 className="text-xl font-semibold mb-2">Integrity</h3>
              <p className="text-muted-foreground">
                We operate with complete transparency and honesty in all our dealings, ensuring our clients can trust
                our recommendations and services.
              </p>
            </div>
            <div className="p-4 border rounded-lg">
              <h3 className="text-xl font-semibold mb-2">Innovation</h3>
              <p className="text-muted-foreground">
                We continuously explore new technologies and approaches to provide cutting-edge solutions that keep our
                clients ahead of the curve.
              </p>
            </div>
            <div className="p-4 border rounded-lg">
              <h3 className="text-xl font-semibold mb-2">Education</h3>
              <p className="text-muted-foreground">
                We believe in empowering our clients through knowledge, providing resources and guidance that help them
                make informed decisions.
              </p>
            </div>
            <div className="p-4 border rounded-lg">
              <h3 className="text-xl font-semibold mb-2">Client Success</h3>
              <p className="text-muted-foreground">
                We measure our success by the success of our clients, focusing on long-term relationships and
                sustainable results.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

