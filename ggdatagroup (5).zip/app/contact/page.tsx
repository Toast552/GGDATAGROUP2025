import type { Metadata } from "next"
import { ContactForm } from "@/components/contact-form"

export const metadata: Metadata = {
  title: "Contact Us",
  description: "Get in touch with our team",
}

export default function ContactPage() {
  return (
    <div className="container py-12 md:py-16 lg:py-24">
      <div className="mx-auto max-w-4xl">
        <div className="text-center mb-12">
          <h1 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">Get in Touch</h1>
          <p className="mt-4 text-lg text-muted-foreground">
            Have questions about our platform? Want to schedule a demo? We're here to help.
          </p>
        </div>

        <div className="grid grid-cols-1 gap-8 md:grid-cols-2">
          <div>
            <h2 className="text-xl font-semibold mb-4">Contact Information</h2>
            <div className="space-y-4">
              <div>
                <p className="font-medium">Email</p>
                <p className="text-muted-foreground">support@saasify.com</p>
              </div>
              <div>
                <p className="font-medium">Phone</p>
                <p className="text-muted-foreground">+1 (555) 123-4567</p>
              </div>
              <div>
                <p className="font-medium">Address</p>
                <p className="text-muted-foreground">
                  123 SaaS Street
                  <br />
                  San Francisco, CA 94103
                  <br />
                  United States
                </p>
              </div>
              <div>
                <p className="font-medium">Hours</p>
                <p className="text-muted-foreground">
                  Monday - Friday: 9am - 5pm PST
                  <br />
                  Saturday - Sunday: Closed
                </p>
              </div>
            </div>
          </div>

          <div>
            <h2 className="text-xl font-semibold mb-4">Send us a Message</h2>
            <ContactForm />
          </div>
        </div>
      </div>
    </div>
  )
}

