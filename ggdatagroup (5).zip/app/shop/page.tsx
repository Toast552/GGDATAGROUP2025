"use client"

import { useState } from "react"
import Link from "next/link"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { DocuSignWaiver } from "@/components/docusign-waiver"
import { AlertTriangle, Info, Cpu, Server, Zap } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"

export default function ShopPage() {
  const [showWaiver, setShowWaiver] = useState(false)
  const [selectedProduct, setSelectedProduct] = useState<string | null>(null)

  const handleProductSelect = (productTitle: string) => {
    setSelectedProduct(productTitle)
    setShowWaiver(true)
  }

  const handleWaiverComplete = () => {
    // In a real app, this would redirect to checkout
    setTimeout(() => {
      setShowWaiver(false)
    }, 2000)
  }

  const miningProducts = [
    {
      title: "Bitmain KS5 Pro",
      description: "High-performance ASIC miner for Kaspa and other KHeavyHash algorithms",
      price: "$2,400",
      popular: true,
      new: true,
      features: [
        "Hashrate: 17.5 TH/s ±5%",
        "Power consumption: 3350W ±5%",
        "Power efficiency: 191 J/T ±5%",
        "Noise level: 75 dB",
        "Network connection: Ethernet",
        "Operating temperature: 5-35°C",
        "Dimensions: 400 x 195 x 290mm",
      ],
      image: "/placeholder.svg?height=200&width=300",
    },
    {
      title: "Basic Mining Setup",
      description: "Perfect for beginners looking to start their crypto mining journey",
      price: "$299",
      features: [
        "Easy setup process",
        "Basic monitoring tools",
        "Single cryptocurrency support",
        "Email support",
        "Setup guide included",
      ],
    },
    {
      title: "Advanced Mining Package",
      description: "Comprehensive solution for serious crypto miners",
      price: "$599",
      popular: true,
      features: [
        "Advanced setup with optimization",
        "Real-time monitoring dashboard",
        "Multi-cryptocurrency support",
        "Priority email & chat support",
        "Detailed analytics",
        "Performance optimization guide",
      ],
    },
    {
      title: "Enterprise Mining Solution",
      description: "Full-scale mining operation for businesses",
      price: "$1,299",
      features: [
        "Custom deployment & configuration",
        "Enterprise-grade monitoring",
        "Full cryptocurrency support",
        "24/7 dedicated support",
        "Advanced analytics & reporting",
        "Remote management tools",
        "Custom API integration",
      ],
    },
  ]

  const toolsProducts = [
    {
      title: "AI Analytics Tool",
      description: "AI-powered analytics for optimizing your mining operations",
      price: "$149/month",
      features: [
        "Predictive performance analysis",
        "Automatic optimization suggestions",
        "Market trend analysis",
        "Profitability forecasting",
        "Email reports",
        "API access",
      ],
    },
    {
      title: "Hosting Infrastructure",
      description: "Reliable hosting infrastructure for your mining hardware",
      price: "From $99/month",
      features: [
        "99.9% uptime guarantee",
        "Power management",
        "Cooling solutions",
        "Security monitoring",
        "Bandwidth allocation",
        "Scalable resources",
      ],
    },
  ]

  const servicesProducts = [
    {
      title: "Consulting Package",
      description: "Expert consulting to maximize your mining efficiency",
      price: "$499",
      features: [
        "2-hour consultation session",
        "Custom strategy development",
        "Hardware recommendations",
        "Software configuration",
        "Optimization tips",
        "Follow-up session",
      ],
    },
  ]

  // Add customer testimonials/quotes
  const testimonials = [
    {
      name: "John D.",
      role: "Crypto Investor",
      quote:
        "GG Data Group's mining solutions have significantly increased my ROI. Their team's expertise and support are unmatched in the industry.",
      avatar: "/placeholder.svg?height=60&width=60",
    },
    {
      name: "Sarah M.",
      role: "Tech Entrepreneur",
      quote:
        "The AI Analytics Tool has transformed how we approach market analysis. It's intuitive, powerful, and delivers actionable insights.",
      avatar: "/placeholder.svg?height=60&width=60",
    },
    {
      name: "Michael R.",
      role: "Financial Analyst",
      quote:
        "Their consulting services provided exactly what we needed to optimize our blockchain strategy. Highly recommended for businesses of all sizes.",
      avatar: "/placeholder.svg?height=60&width=60",
    },
  ]

  return (
    <div className="container py-10">
      {showWaiver ? (
        <div className="max-w-md mx-auto">
          <h2 className="text-2xl font-bold text-center mb-6">Complete Agreement for {selectedProduct}</h2>
          <DocuSignWaiver onComplete={handleWaiverComplete} />
        </div>
      ) : (
        <>
          <div className="max-w-3xl mx-auto text-center mb-6">
            <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl mb-4">
              Mining Hardware & Services
            </h1>
            <p className="text-muted-foreground md:text-xl mb-6">
              Explore our carefully selected mining hardware, tools, and services
            </p>

            <Alert variant="warning" className="mb-6 text-left">
              <AlertTriangle className="h-4 w-4" />
              <AlertTitle>Cryptocurrency Volatility Disclosure</AlertTitle>
              <AlertDescription className="space-y-2">
                <p>
                  Cryptocurrency prices are highly volatile and can fluctuate significantly over short periods of time.
                  This volatility can be attributed to various factors including market sentiment, regulatory
                  developments, technological advancements, and macroeconomic trends.
                </p>
                <p>
                  Mining profitability depends on multiple factors including market conditions, network difficulty,
                  energy costs, and hardware efficiency. Past performance is not indicative of future results.
                </p>
                <p>Before investing in cryptocurrency mining, please consider:</p>
                <ul className="list-disc pl-5 space-y-1">
                  <li>The potential for significant price fluctuations</li>
                  <li>Regulatory risks and compliance requirements</li>
                  <li>Technical challenges and hardware depreciation</li>
                  <li>Energy costs and environmental impact</li>
                  <li>Network difficulty adjustments affecting profitability</li>
                </ul>
                <p className="font-medium">
                  Please carefully consider these risks before investing in our mining solutions.
                </p>
              </AlertDescription>
            </Alert>
          </div>

          {/* Featured Product - KS5 Pro */}
          <div className="mb-12">
            <Card className="overflow-hidden">
              <div className="md:flex">
                <div className="md:w-1/3 bg-muted flex items-center justify-center p-6">
                  <img
                    src="/placeholder.svg?height=300&width=400"
                    alt="Bitmain KS5 Pro"
                    className="max-w-full h-auto"
                  />
                </div>
                <div className="md:w-2/3 p-6">
                  <div className="flex items-center gap-3 mb-2">
                    <h2 className="text-2xl font-bold">Bitmain KS5 Pro ASIC Miner</h2>
                    <Badge variant="default" className="bg-primary">
                      New
                    </Badge>
                  </div>
                  <div className="flex items-center gap-2 mb-4">
                    <Badge variant="outline" className="flex items-center gap-1">
                      <Cpu className="h-3 w-3" /> 17.5 TH/s
                    </Badge>
                    <Badge variant="outline" className="flex items-center gap-1">
                      <Zap className="h-3 w-3" /> 3350W
                    </Badge>
                    <Badge variant="outline" className="flex items-center gap-1">
                      <Server className="h-3 w-3" /> KHeavyHash
                    </Badge>
                  </div>
                  <p className="text-muted-foreground mb-4">
                    The Bitmain KS5 Pro is a high-performance ASIC miner designed specifically for mining Kaspa (KAS)
                    and other cryptocurrencies using the KHeavyHash algorithm. With its impressive hashrate and
                    competitive power efficiency, the KS5 Pro offers excellent mining capabilities for serious miners.
                  </p>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                    <div>
                      <h3 className="font-semibold mb-2">Key Specifications:</h3>
                      <ul className="space-y-1 text-sm">
                        <li className="flex items-center gap-2">
                          <span className="text-primary">•</span> Hashrate: 17.5 TH/s ±5%
                        </li>
                        <li className="flex items-center gap-2">
                          <span className="text-primary">•</span> Power consumption: 3350W ±5%
                        </li>
                        <li className="flex items-center gap-2">
                          <span className="text-primary">•</span> Power efficiency: 191 J/T ±5%
                        </li>
                        <li className="flex items-center gap-2">
                          <span className="text-primary">•</span> Noise level: 75 dB
                        </li>
                      </ul>
                    </div>
                    <div>
                      <h3 className="font-semibold mb-2">What's Included:</h3>
                      <ul className="space-y-1 text-sm">
                        <li className="flex items-center gap-2">
                          <span className="text-primary">•</span> KS5 Pro miner unit
                        </li>
                        <li className="flex items-center gap-2">
                          <span className="text-primary">•</span> Power supply unit
                        </li>
                        <li className="flex items-center gap-2">
                          <span className="text-primary">•</span> Power cords
                        </li>
                        <li className="flex items-center gap-2">
                          <span className="text-primary">•</span> Setup guide
                        </li>
                      </ul>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-3xl font-bold">$2,400.00</p>
                      <p className="text-sm text-muted-foreground">Free shipping • Limited stock available</p>
                    </div>
                    <Button size="lg" onClick={() => handleProductSelect("Bitmain KS5 Pro")}>
                      Add to Cart
                    </Button>
                  </div>
                </div>
              </div>
            </Card>
          </div>

          <Tabs defaultValue="mining" className="max-w-5xl mx-auto mb-10">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="mining">Mining Hardware</TabsTrigger>
              <TabsTrigger value="tools">Mining Tools</TabsTrigger>
              <TabsTrigger value="services">Consulting Services</TabsTrigger>
            </TabsList>
            <TabsContent value="mining" className="mt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {miningProducts.slice(1).map((product, index) => (
                  <Card key={index} className={`flex flex-col ${product.popular ? "border-primary" : ""} relative`}>
                    {product.popular && (
                      <div className="absolute top-0 right-0 bg-primary text-primary-foreground px-3 py-1 text-xs font-medium rounded-bl-lg rounded-tr-lg">
                        Popular
                      </div>
                    )}
                    <CardHeader>
                      <CardTitle>{product.title}</CardTitle>
                      <CardDescription>{product.description}</CardDescription>
                      <div className="mt-4">
                        <span className="text-3xl font-bold">{product.price}</span>
                      </div>
                    </CardHeader>
                    <CardContent className="flex-1">
                      <ul className="space-y-2">
                        {product.features.map((feature, i) => (
                          <li key={i} className="flex items-center">
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              width="24"
                              height="24"
                              viewBox="0 0 24 24"
                              fill="none"
                              stroke="currentColor"
                              strokeWidth="2"
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              className="h-4 w-4 mr-2 text-green-500"
                            >
                              <polyline points="20 6 9 17 4 12"></polyline>
                            </svg>
                            {feature}
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                    <CardFooter>
                      <Button className="w-full" onClick={() => handleProductSelect(product.title)}>
                        Get Started
                      </Button>
                    </CardFooter>
                  </Card>
                ))}
              </div>
            </TabsContent>
            <TabsContent value="tools" className="mt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {toolsProducts.map((product, index) => (
                  <Card key={index} className="flex flex-col">
                    <CardHeader>
                      <CardTitle>{product.title}</CardTitle>
                      <CardDescription>{product.description}</CardDescription>
                      <div className="mt-4">
                        <span className="text-3xl font-bold">{product.price}</span>
                      </div>
                    </CardHeader>
                    <CardContent className="flex-1">
                      <ul className="space-y-2">
                        {product.features.map((feature, i) => (
                          <li key={i} className="flex items-center">
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              width="24"
                              height="24"
                              viewBox="0 0 24 24"
                              fill="none"
                              stroke="currentColor"
                              strokeWidth="2"
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              className="h-4 w-4 mr-2 text-green-500"
                            >
                              <polyline points="20 6 9 17 4 12"></polyline>
                            </svg>
                            {feature}
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                    <CardFooter>
                      <Button className="w-full" onClick={() => handleProductSelect(product.title)}>
                        Get Started
                      </Button>
                    </CardFooter>
                  </Card>
                ))}
              </div>
            </TabsContent>
            <TabsContent value="services" className="mt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {servicesProducts.map((product, index) => (
                  <Card key={index} className="flex flex-col">
                    <CardHeader>
                      <CardTitle>{product.title}</CardTitle>
                      <CardDescription>{product.description}</CardDescription>
                      <div className="mt-4">
                        <span className="text-3xl font-bold">{product.price}</span>
                      </div>
                    </CardHeader>
                    <CardContent className="flex-1">
                      <ul className="space-y-2">
                        {product.features.map((feature, i) => (
                          <li key={i} className="flex items-center">
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              width="24"
                              height="24"
                              viewBox="0 0 24 24"
                              fill="none"
                              stroke="currentColor"
                              strokeWidth="2"
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              className="h-4 w-4 mr-2 text-green-500"
                            >
                              <polyline points="20 6 9 17 4 12"></polyline>
                            </svg>
                            {feature}
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                    <CardFooter>
                      <Button className="w-full" onClick={() => handleProductSelect(product.title)}>
                        Get Started
                      </Button>
                    </CardFooter>
                  </Card>
                ))}
              </div>
            </TabsContent>
          </Tabs>

          <div className="max-w-4xl mx-auto mt-12">
            <h2 className="text-2xl font-bold mb-6 text-center">What Our Clients Say</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {testimonials.map((testimonial, index) => (
                <Card key={index} className="border-primary/20">
                  <CardContent className="pt-6">
                    <div className="flex flex-col items-center mb-4">
                      <img
                        src={testimonial.avatar || "/placeholder.svg"}
                        alt={testimonial.name}
                        className="w-16 h-16 rounded-full mb-2"
                      />
                      <h3 className="font-bold">{testimonial.name}</h3>
                      <p className="text-sm text-muted-foreground">{testimonial.role}</p>
                    </div>
                    <p className="text-sm italic text-center">"{testimonial.quote}"</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          <div className="max-w-4xl mx-auto mt-12 p-6 bg-muted rounded-lg">
            <div className="flex items-start space-x-4">
              <Info className="h-6 w-6 text-primary flex-shrink-0 mt-1" />
              <div>
                <h3 className="text-xl font-bold mb-2">Mining Disclosure</h3>
                <div className="text-sm text-muted-foreground space-y-2">
                  <p>
                    <strong>Energy Consumption:</strong> Cryptocurrency mining requires significant electrical power.
                    Our hosting facilities use a mix of renewable and traditional energy sources. We are committed to
                    minimizing our environmental footprint while maintaining optimal mining performance.
                  </p>
                  <p>
                    <strong>Hardware Depreciation:</strong> Mining equipment depreciates over time due to wear and
                    technological advancements. Our maintenance programs are designed to extend hardware lifespan, but
                    depreciation should be factored into your investment calculations.
                  </p>
                  <p>
                    <strong>Network Difficulty:</strong> Mining difficulty typically increases over time as more miners
                    join the network. This can reduce mining rewards. Our analytics tools help forecast difficulty
                    changes to optimize your mining strategy.
                  </p>
                  <p>
                    <strong>Regulatory Considerations:</strong> Cryptocurrency regulations vary by jurisdiction and are
                    subject to change. We monitor regulatory developments and provide guidance, but customers are
                    responsible for compliance with local laws.
                  </p>
                  <p>
                    <strong>Environmental Impact:</strong> We recognize the environmental concerns associated with
                    cryptocurrency mining. Our facilities implement energy-efficient technologies and cooling systems to
                    minimize environmental impact.
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="max-w-3xl mx-auto text-center mt-12">
            <h2 className="text-2xl font-bold tracking-tighter sm:text-3xl mb-4">Need a Custom Solution?</h2>
            <p className="text-muted-foreground mb-6">
              Our team can create tailored cryptography and mining solutions for your specific needs
            </p>
            <Link href="/contact">
              <Button size="lg">Contact Our Team</Button>
            </Link>
          </div>
        </>
      )}
    </div>
  )
}

