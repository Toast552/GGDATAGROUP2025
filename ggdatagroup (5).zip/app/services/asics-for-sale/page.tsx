import Link from "next/link"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { DisclosureBanner } from "@/components/disclosure-banner"
import { Cpu, Zap, Server, ArrowRight, ShoppingCart } from "lucide-react"

export default function AsicsForSalePage() {
  return (
    <div className="container py-10">
      <div className="max-w-3xl mx-auto text-center mb-6">
        <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl mb-4">ASIC Miners for Sale</h1>
        <p className="text-muted-foreground md:text-xl">
          High-performance mining hardware for cryptocurrency enthusiasts
        </p>
      </div>

      <DisclosureBanner
        title="Cryptocurrency Mining Disclosure"
        description="Cryptocurrency mining involves significant electrical power consumption and hardware depreciation. Mining profitability depends on multiple factors including market conditions, network difficulty, and energy costs. Past performance is not indicative of future results."
      />

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-8">
        {/* Featured Product - KS5 Pro */}
        <Card className="col-span-1 md:col-span-3 lg:col-span-3 overflow-hidden">
          <div className="md:flex">
            <div className="md:w-1/3 bg-muted flex items-center justify-center p-6">
              <img src="/placeholder.svg?height=300&width=400" alt="Bitmain KS5 Pro" className="max-w-full h-auto" />
            </div>
            <div className="md:w-2/3 p-6">
              <div className="flex items-center gap-3 mb-2">
                <h2 className="text-2xl font-bold">Bitmain KS5 Pro ASIC Miner</h2>
                <Badge variant="default" className="bg-primary">
                  New
                </Badge>
              </div>
              <div className="flex items-center gap-2 mb-4">
                <Badge variant="outline" className="flex items-center gap-1">
                  <Cpu className="h-3 w-3" /> 17.5 TH/s
                </Badge>
                <Badge variant="outline" className="flex items-center gap-1">
                  <Zap className="h-3 w-3" /> 3350W
                </Badge>
                <Badge variant="outline" className="flex items-center gap-1">
                  <Server className="h-3 w-3" /> KHeavyHash
                </Badge>
              </div>
              <p className="text-muted-foreground mb-4">
                The Bitmain KS5 Pro is a high-performance ASIC miner designed specifically for mining Kaspa (KAS) and
                other cryptocurrencies using the KHeavyHash algorithm. With its impressive hashrate and competitive
                power efficiency, the KS5 Pro offers excellent mining capabilities for serious miners.
              </p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                <div>
                  <h3 className="font-semibold mb-2">Key Specifications:</h3>
                  <ul className="space-y-1 text-sm">
                    <li className="flex items-center gap-2">
                      <span className="text-primary">•</span> Hashrate: 17.5 TH/s ±5%
                    </li>
                    <li className="flex items-center gap-2">
                      <span className="text-primary">•</span> Power consumption: 3350W ±5%
                    </li>
                    <li className="flex items-center gap-2">
                      <span className="text-primary">•</span> Power efficiency: 191 J/T ±5%
                    </li>
                    <li className="flex items-center gap-2">
                      <span className="text-primary">•</span> Noise level: 75 dB
                    </li>
                  </ul>
                </div>
                <div>
                  <h3 className="font-semibold mb-2">What's Included:</h3>
                  <ul className="space-y-1 text-sm">
                    <li className="flex items-center gap-2">
                      <span className="text-primary">•</span> KS5 Pro miner unit
                    </li>
                    <li className="flex items-center gap-2">
                      <span className="text-primary">•</span> Power supply unit
                    </li>
                    <li className="flex items-center gap-2">
                      <span className="text-primary">•</span> Power cords
                    </li>
                    <li className="flex items-center gap-2">
                      <span className="text-primary">•</span> Setup guide
                    </li>
                  </ul>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-3xl font-bold">$2,400.00</p>
                  <p className="text-sm text-muted-foreground">Free shipping • Limited stock available</p>
                </div>
                <Link href="/checkout">
                  <Button size="lg" className="flex items-center gap-2">
                    <ShoppingCart className="h-4 w-4" />
                    Add to Cart
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </Card>

        {/* Other ASIC Miners */}
        <Card>
          <CardHeader>
            <CardTitle>Antminer S19 XP</CardTitle>
            <CardDescription>Bitcoin ASIC Miner</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="aspect-video bg-muted rounded-md flex items-center justify-center mb-4">
              <img src="/placeholder.svg?height=200&width=300" alt="Antminer S19 XP" className="max-w-full h-auto" />
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-medium">Hashrate:</span>
                <span>140 TH/s</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="font-medium">Power:</span>
                <span>3010W</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="font-medium">Algorithm:</span>
                <span>SHA-256</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="font-medium">Price:</span>
                <span className="text-xl font-bold">$3,899.00</span>
              </div>
            </div>
          </CardContent>
          <CardFooter>
            <Link href="/checkout" className="w-full">
              <Button className="w-full">Add to Cart</Button>
            </Link>
          </CardFooter>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Whatsminer M50S</CardTitle>
            <CardDescription>Bitcoin ASIC Miner</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="aspect-video bg-muted rounded-md flex items-center justify-center mb-4">
              <img src="/placeholder.svg?height=200&width=300" alt="Whatsminer M50S" className="max-w-full h-auto" />
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-medium">Hashrate:</span>
                <span>126 TH/s</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="font-medium">Power:</span>
                <span>3276W</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="font-medium">Algorithm:</span>
                <span>SHA-256</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="font-medium">Price:</span>
                <span className="text-xl font-bold">$3,499.00</span>
              </div>
            </div>
          </CardContent>
          <CardFooter>
            <Link href="/checkout" className="w-full">
              <Button className="w-full">Add to Cart</Button>
            </Link>
          </CardFooter>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Jasminer X4-1U</CardTitle>
            <CardDescription>Ethereum ASIC Miner</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="aspect-video bg-muted rounded-md flex items-center justify-center mb-4">
              <img src="/placeholder.svg?height=200&width=300" alt="Jasminer X4-1U" className="max-w-full h-auto" />
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-medium">Hashrate:</span>
                <span>520 MH/s</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="font-medium">Power:</span>
                <span>240W</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="font-medium">Algorithm:</span>
                <span>EtHash</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="font-medium">Price:</span>
                <span className="text-xl font-bold">$4,299.00</span>
              </div>
            </div>
          </CardContent>
          <CardFooter>
            <Link href="/checkout" className="w-full">
              <Button className="w-full">Add to Cart</Button>
            </Link>
          </CardFooter>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Goldshell KD6</CardTitle>
            <CardDescription>Kadena ASIC Miner</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="aspect-video bg-muted rounded-md flex items-center justify-center mb-4">
              <img src="/placeholder.svg?height=200&width=300" alt="Goldshell KD6" className="max-w-full h-auto" />
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-medium">Hashrate:</span>
                <span>35 TH/s</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="font-medium">Power:</span>
                <span>3500W</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="font-medium">Algorithm:</span>
                <span>Blake2s</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="font-medium">Price:</span>
                <span className="text-xl font-bold">$5,999.00</span>
              </div>
            </div>
          </CardContent>
          <CardFooter>
            <Link href="/checkout" className="w-full">
              <Button className="w-full">Add to Cart</Button>
            </Link>
          </CardFooter>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>iBeLink BM-K1+</CardTitle>
            <CardDescription>Kadena ASIC Miner</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="aspect-video bg-muted rounded-md flex items-center justify-center mb-4">
              <img src="/placeholder.svg?height=200&width=300" alt="iBeLink BM-K1+" className="max-w-full h-auto" />
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-medium">Hashrate:</span>
                <span>20 TH/s</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="font-medium">Power:</span>
                <span>3400W</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="font-medium">Algorithm:</span>
                <span>Blake2s</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="font-medium">Price:</span>
                <span className="text-xl font-bold">$4,799.00</span>
              </div>
            </div>
          </CardContent>
          <CardFooter>
            <Link href="/checkout" className="w-full">
              <Button className="w-full">Add to Cart</Button>
            </Link>
          </CardFooter>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Goldshell CK6</CardTitle>
            <CardDescription>Nervos CKB ASIC Miner</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="aspect-video bg-muted rounded-md flex items-center justify-center mb-4">
              <img src="/placeholder.svg?height=200&width=300" alt="Goldshell CK6" className="max-w-full h-auto" />
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-medium">Hashrate:</span>
                <span>19 TH/s</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="font-medium">Power:</span>
                <span>3300W</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="font-medium">Algorithm:</span>
                <span>Eaglesong</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="font-medium">Price:</span>
                <span className="text-xl font-bold">$3,999.00</span>
              </div>
            </div>
          </CardContent>
          <CardFooter>
            <Link href="/checkout" className="w-full">
              <Button className="w-full">Add to Cart</Button>
            </Link>
          </CardFooter>
        </Card>
      </div>

      <div className="mt-12 text-center">
        <h2 className="text-2xl font-bold mb-4">Why Choose Our ASIC Miners?</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto mb-8">
          <div className="flex flex-col items-center">
            <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="text-primary"
              >
                <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10" />
              </svg>
            </div>
            <h3 className="text-xl font-bold mb-2">Quality Assurance</h3>
            <p className="text-center text-muted-foreground">
              All our miners undergo rigorous testing to ensure optimal performance and reliability.
            </p>
          </div>
          <div className="flex flex-col items-center">
            <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="text-primary"
              >
                <path d="M14 9a2 2 0 0 1-2 2H6l-4 4V4c0-1.1.9-2 2-2h8a2 2 0 0 1 2 2v5Z" />
                <path d="M18 9h2a2 2 0 0 1 2 2v11l-4-4h-6a2 2 0 0 1-2-2v-1" />
              </svg>
            </div>
            <h3 className="text-xl font-bold mb-2">Expert Support</h3>
            <p className="text-center text-muted-foreground">
              Our team of mining experts is available to help with setup, optimization, and troubleshooting.
            </p>
          </div>
          <div className="flex flex-col items-center">
            <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="text-primary"
              >
                <rect width="20" height="14" x="2" y="5" rx="2" />
                <line x1="2" x2="22" y1="10" y2="10" />
              </svg>
            </div>
            <h3 className="text-xl font-bold mb-2">Secure Payment</h3>
            <p className="text-center text-muted-foreground">
              Multiple payment options including cryptocurrency, credit card, and wire transfer.
            </p>
          </div>
        </div>
        <Link href="/services">
          <Button variant="outline" className="mr-2">
            Back to Services
          </Button>
        </Link>
        <Link href="/contact">
          <Button>
            Contact for Bulk Orders
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </Link>
      </div>
    </div>
  )
}

