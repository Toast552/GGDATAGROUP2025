import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import {
  Code,
  Database,
  FileCode,
  Shield,
  BarChart3,
  MessageSquare,
  Network,
  Layers,
  Cloud,
  Lock,
  Zap,
  BrainCircuit,
  Smartphone,
  HeartPulse,
  DollarSign,
  Truck,
  Lightbulb,
  Gamepad2,
  BookOpen,
  Leaf,
  Radio,
  Umbrella,
} from "lucide-react"

export default function ServicesPage() {
  return (
    <div className="container py-10">
      <div className="max-w-3xl mx-auto text-center mb-10">
        <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl mb-4">Our Services</h1>
        <p className="text-muted-foreground md:text-xl">
          At GGDATAGROUP, we offer a wide range of services to help businesses and individuals succeed in the blockchain
          and technology space.
        </p>
      </div>

      {/* Main Services Section */}
      <div className="mb-16">
        <h2 className="text-2xl font-bold mb-6">Blockchain & Technology Services</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <Card className="transition-all hover:shadow-md">
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <Layers className="h-5 w-5 text-primary" />
                </div>
                <CardTitle>Blockchain Development</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                We develop custom blockchain solutions for businesses and individuals, including smart contracts,
                decentralized applications, and blockchain-based systems.
              </p>
            </CardContent>
          </Card>

          <Card className="transition-all hover:shadow-md">
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <MessageSquare className="h-5 w-5 text-primary" />
                </div>
                <CardTitle>Consulting Services</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                We offer consulting services to help businesses and individuals navigate the blockchain and technology
                space, including strategy development, risk assessment, and regulatory compliance.
              </p>
            </CardContent>
          </Card>

          <Card className="transition-all hover:shadow-md">
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <Code className="h-5 w-5 text-primary" />
                </div>
                <CardTitle>DApp Development</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                We develop custom decentralized applications (DApps) for businesses and individuals, including DApp
                development, testing, and deployment.
              </p>
            </CardContent>
          </Card>

          <Card className="transition-all hover:shadow-md">
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <Network className="h-5 w-5 text-primary" />
                </div>
                <CardTitle>Blockchain Integration</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                We integrate blockchain technology with existing systems and infrastructure, including API development,
                data migration, and system integration.
              </p>
            </CardContent>
          </Card>

          <Card className="transition-all hover:shadow-md">
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <Shield className="h-5 w-5 text-primary" />
                </div>
                <CardTitle>Security Audits</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                We conduct security audits to identify vulnerabilities and weaknesses in blockchain-based systems and
                applications.
              </p>
            </CardContent>
          </Card>

          <Card className="transition-all hover:shadow-md">
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <FileCode className="h-5 w-5 text-primary" />
                </div>
                <CardTitle>Smart Contract Auditing</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                We audit smart contracts to ensure they are secure, functional, and compliant with regulatory
                requirements.
              </p>
            </CardContent>
          </Card>

          <Card className="transition-all hover:shadow-md">
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <Database className="h-5 w-5 text-primary" />
                </div>
                <CardTitle>Blockchain Migration</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                We migrate existing systems and infrastructure to blockchain-based solutions, including data migration,
                system integration, and testing.
              </p>
            </CardContent>
          </Card>

          <Card className="transition-all hover:shadow-md">
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <BarChart3 className="h-5 w-5 text-primary" />
                </div>
                <CardTitle>Data Analytics</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                We provide data analytics services to help businesses and individuals understand and optimize their
                blockchain-based systems and applications.
              </p>
            </CardContent>
          </Card>

          <Card className="transition-all hover:shadow-md">
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <Zap className="h-5 w-5 text-primary" />
                </div>
                <CardTitle>Interoperability Solutions</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                We develop interoperability solutions to enable seamless communication and data exchange between
                different blockchain-based systems and applications.
              </p>
            </CardContent>
          </Card>
          <Card className="transition-all hover:shadow-md">
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <Lock className="h-5 w-5 text-primary" />
                </div>
                <CardTitle>Cryptography Solutions</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                We provide advanced cryptography solutions for secure data protection, encryption, and authentication to
                safeguard your sensitive information.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Industry Solutions Section */}
      <div className="mb-16">
        <h2 className="text-2xl font-bold mb-6">Industry Solutions</h2>
        <p className="text-muted-foreground mb-6">
          We provide industry-specific solutions for a range of industries, including:
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <Card className="transition-all hover:shadow-md">
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <HeartPulse className="h-5 w-5 text-primary" />
                </div>
                <CardTitle>Healthcare</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                We develop blockchain-based solutions for the healthcare industry, including electronic health records,
                medical research, and pharmaceutical supply chain management.
              </p>
            </CardContent>
          </Card>

          <Card className="transition-all hover:shadow-md">
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <DollarSign className="h-5 w-5 text-primary" />
                </div>
                <CardTitle>Finance</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                We develop blockchain-based solutions for the finance industry, including payment processing, securities
                trading, and asset management.
              </p>
            </CardContent>
          </Card>

          <Card className="transition-all hover:shadow-md">
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <Truck className="h-5 w-5 text-primary" />
                </div>
                <CardTitle>Supply Chain Management</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                We develop blockchain-based solutions for supply chain management, including inventory management,
                shipping and logistics, and quality control.
              </p>
            </CardContent>
          </Card>

          <Card className="transition-all hover:shadow-md">
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <Lightbulb className="h-5 w-5 text-primary" />
                </div>
                <CardTitle>Energy Management</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                We develop blockchain-based solutions for energy management, including energy trading, grid management,
                and renewable energy systems.
              </p>
            </CardContent>
          </Card>

          <Card className="transition-all hover:shadow-md">
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <Gamepad2 className="h-5 w-5 text-primary" />
                </div>
                <CardTitle>Gaming</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                We develop blockchain-based solutions for the gaming industry, including game development, virtual
                assets, and gaming platforms.
              </p>
            </CardContent>
          </Card>

          <Card className="transition-all hover:shadow-md">
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <BookOpen className="h-5 w-5 text-primary" />
                </div>
                <CardTitle>Intellectual Property</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                We develop blockchain-based solutions for intellectual property management, including patent management,
                copyright management, and trademark management.
              </p>
            </CardContent>
          </Card>

          <Card className="transition-all hover:shadow-md">
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <Leaf className="h-5 w-5 text-primary" />
                </div>
                <CardTitle>Agriculture</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                We develop blockchain-based solutions for the agriculture industry, including farm management, supply
                chain management, and agricultural finance.
              </p>
            </CardContent>
          </Card>

          <Card className="transition-all hover:shadow-md">
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <Radio className="h-5 w-5 text-primary" />
                </div>
                <CardTitle>Telecommunications</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                We develop blockchain-based solutions for the telecommunications industry, including network management,
                data analytics, and customer service.
              </p>
            </CardContent>
          </Card>

          <Card className="transition-all hover:shadow-md">
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <Umbrella className="h-5 w-5 text-primary" />
                </div>
                <CardTitle>Insurance</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                We develop blockchain-based solutions for the insurance industry, including claims processing, risk
                assessment, and policy management.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Technology Solutions Section */}
      <div className="mb-16">
        <h2 className="text-2xl font-bold mb-6">Technology Solutions</h2>
        <p className="text-muted-foreground mb-6">
          We provide technology solutions for a range of technologies, including:
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <Card className="transition-all hover:shadow-md">
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <Layers className="h-5 w-5 text-primary" />
                </div>
                <CardTitle>Blockchain Platforms</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                We develop solutions on a range of blockchain platforms, including Ethereum, Bitcoin, and Hyperledger.
              </p>
            </CardContent>
          </Card>

          <Card className="transition-all hover:shadow-md">
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <FileCode className="h-5 w-5 text-primary" />
                </div>
                <CardTitle>Smart Contracts</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                We develop smart contracts on a range of blockchain platforms, including Ethereum, Bitcoin, and
                Hyperledger.
              </p>
            </CardContent>
          </Card>

          <Card className="transition-all hover:shadow-md">
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <Code className="h-5 w-5 text-primary" />
                </div>
                <CardTitle>Decentralized Applications</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                We develop DApps on a range of blockchain platforms, including Ethereum, Bitcoin, and Hyperledger.
              </p>
            </CardContent>
          </Card>

          <Card className="transition-all hover:shadow-md">
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <Database className="h-5 w-5 text-primary" />
                </div>
                <CardTitle>Blockchain-Based Systems</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                We develop blockchain-based systems for a range of industries and applications, including supply chain
                management, energy management, and healthcare.
              </p>
            </CardContent>
          </Card>

          <Card className="transition-all hover:shadow-md">
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <BrainCircuit className="h-5 w-5 text-primary" />
                </div>
                <CardTitle>AI and Machine Learning</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                We develop AI and ML solutions for a range of applications, including data analytics, predictive
                modeling, and automation.
              </p>
            </CardContent>
          </Card>

          <Card className="transition-all hover:shadow-md">
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <Smartphone className="h-5 w-5 text-primary" />
                </div>
                <CardTitle>Internet of Things (IoT)</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                We develop IoT solutions for a range of applications, including industrial automation, smart cities, and
                wearable devices.
              </p>
            </CardContent>
          </Card>

          <Card className="transition-all hover:shadow-md">
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <Cloud className="h-5 w-5 text-primary" />
                </div>
                <CardTitle>Cloud Computing</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                We develop cloud computing solutions for a range of applications, including data storage, data
                analytics, and software development.
              </p>
            </CardContent>
          </Card>

          <Card className="transition-all hover:shadow-md">
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <Lock className="h-5 w-5 text-primary" />
                </div>
                <CardTitle>Cybersecurity</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                We develop cybersecurity solutions for a range of applications, including threat detection, incident
                response, and security consulting.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* CTA Section */}
      <div className="max-w-3xl mx-auto text-center">
        <h2 className="text-2xl font-bold mb-4">Ready to Transform Your Business?</h2>
        <p className="text-muted-foreground mb-6">
          Contact us today to discuss how our blockchain and technology solutions can help your business succeed.
        </p>
        <Link href="/contact">
          <Button size="lg">Contact Our Team</Button>
        </Link>
      </div>
    </div>
  )
}

