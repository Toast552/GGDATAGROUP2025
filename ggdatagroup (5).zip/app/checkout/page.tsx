"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Separator } from "@/components/ui/separator"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { AlertCircle, CreditCard, Bitcoin, DollarSign, CheckCircle2, Loader2 } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { sanitizeInput } from "@/lib/security"

export default function CheckoutPage() {
  const router = useRouter()
  const [paymentMethod, setPaymentMethod] = useState("credit-card")
  const [isProcessing, setIsProcessing] = useState(false)
  const [isComplete, setIsComplete] = useState(false)
  const [formErrors, setFormErrors] = useState({
    name: "",
    email: "",
    address: "",
    city: "",
    zip: "",
    cardNumber: "",
    cardExpiry: "",
    cardCvc: "",
  })

  // Update the cartItems array to be dynamic based on URL parameters
  const [cartItems, setCartItems] = useState(() => {
    // In a real app, this would come from a cart state or API
    // For demo purposes, we'll check if there's a URL parameter
    if (typeof window !== "undefined") {
      const urlParams = new URLSearchParams(window.location.search)
      const productId = urlParams.get("product")
      const productName = urlParams.get("name")
      const productPrice = urlParams.get("price")

      if (productId && productName && productPrice) {
        return [
          {
            id: productId,
            name: productName,
            price: Number.parseFloat(productPrice),
            quantity: 1,
          },
          {
            id: "shipping",
            name: "Shipping & Handling",
            price: 75,
            quantity: 1,
          },
        ]
      }
    }

    // Default items if no URL parameters
    return [
      {
        id: "ks5-pro",
        name: "Bitmain KS5 Pro ASIC Miner",
        price: 2400,
        quantity: 1,
      },
      {
        id: "shipping",
        name: "Shipping & Handling",
        price: 75,
        quantity: 1,
      },
    ]
  })

  const subtotal = cartItems.reduce((total, item) => total + item.price * item.quantity, 0)
  const tax = subtotal * 0.07 // 7% tax
  const total = subtotal + tax

  const validateForm = (formData: FormData) => {
    const newErrors = {
      name: "",
      email: "",
      address: "",
      city: "",
      zip: "",
      cardNumber: "",
      cardExpiry: "",
      cardCvc: "",
    }

    let isValid = true

    // Basic validation
    const name = formData.get("name") as string
    if (!name || name.trim().length < 3) {
      newErrors.name = "Full name is required (minimum 3 characters)"
      isValid = false
    }

    const email = formData.get("email") as string
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!email || !emailRegex.test(email)) {
      newErrors.email = "Valid email is required"
      isValid = false
    }

    const address = formData.get("address") as string
    if (!address || address.trim().length < 5) {
      newErrors.address = "Address is required"
      isValid = false
    }

    const city = formData.get("city") as string
    if (!city || city.trim().length < 2) {
      newErrors.city = "City is required"
      isValid = false
    }

    const zip = formData.get("zip") as string
    if (!zip || zip.trim().length < 5) {
      newErrors.zip = "ZIP/Postal code is required"
      isValid = false
    }

    // Credit card validation (only if credit card payment is selected)
    if (paymentMethod === "credit-card") {
      const cardNumber = formData.get("cardNumber") as string
      if (!cardNumber || cardNumber.replace(/\s/g, "").length < 15) {
        newErrors.cardNumber = "Valid card number is required"
        isValid = false
      }

      const cardExpiry = formData.get("cardExpiry") as string
      const expiryRegex = /^(0[1-9]|1[0-2])\/([0-9]{2})$/
      if (!cardExpiry || !expiryRegex.test(cardExpiry)) {
        newErrors.cardExpiry = "Valid expiry date (MM/YY) is required"
        isValid = false
      }

      const cardCvc = formData.get("cardCvc") as string
      if (!cardCvc || cardCvc.length < 3) {
        newErrors.cardCvc = "Valid CVC is required"
        isValid = false
      }
    }

    setFormErrors(newErrors)
    return isValid
  }

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()

    const formData = new FormData(e.currentTarget)

    // Sanitize inputs
    for (const [key, value] of formData.entries()) {
      if (typeof value === "string") {
        formData.set(key, sanitizeInput(value))
      }
    }

    if (!validateForm(formData)) {
      return
    }

    setIsProcessing(true)

    try {
      // Simulate payment processing
      // In a real app, this would be an API call to your payment processor
      await new Promise((resolve) => setTimeout(resolve, 2000))

      // Process payment based on selected method
      if (paymentMethod === "credit-card") {
        // Stripe integration would go here
        console.log("Processing credit card payment via Stripe")
      } else if (paymentMethod === "crypto") {
        // Coinpal integration would go here
        console.log("Processing cryptocurrency payment via Coinpal")
      } else if (paymentMethod === "paypal") {
        // PayPal integration would go here
        console.log("Processing payment via PayPal")
      }

      // Simulate successful payment
      setIsComplete(true)

      // In a real app, you would create an order in WooCommerce here
      console.log("Creating order in WooCommerce")

      // Reset form
      e.currentTarget.reset()
    } catch (error) {
      console.error("Payment processing error:", error)
      alert("There was an error processing your payment. Please try again.")
    } finally {
      setIsProcessing(false)
    }
  }

  const formatCardNumber = (input: string) => {
    // Remove all non-digit characters
    const digits = input.replace(/\D/g, "")

    // Add space after every 4 digits
    const formatted = digits.replace(/(\d{4})(?=\d)/g, "$1 ")

    // Limit to 19 characters (16 digits + 3 spaces)
    return formatted.slice(0, 19)
  }

  const formatExpiryDate = (input: string) => {
    // Remove all non-digit characters
    const digits = input.replace(/\D/g, "")

    // Format as MM/YY
    if (digits.length > 2) {
      return `${digits.slice(0, 2)}/${digits.slice(2, 4)}`
    }

    return digits
  }

  if (isComplete) {
    return (
      <div className="container py-10">
        <div className="max-w-md mx-auto">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-center mb-4">
                <div className="w-16 h-16 bg-green-100 dark:bg-green-900 rounded-full flex items-center justify-center">
                  <CheckCircle2 className="h-8 w-8 text-green-600 dark:text-green-400" />
                </div>
              </div>
              <CardTitle className="text-center text-2xl">Payment Successful!</CardTitle>
              <CardDescription className="text-center">
                Your order has been placed and is being processed.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="border rounded-md p-4">
                <h3 className="font-medium mb-2">Order Summary</h3>
                <div className="space-y-2">
                  {cartItems.map((item) => (
                    <div key={item.id} className="flex justify-between">
                      <span>
                        {item.quantity} × {item.name}
                      </span>
                      <span>${item.price.toFixed(2)}</span>
                    </div>
                  ))}
                  <Separator className="my-2" />
                  <div className="flex justify-between font-medium">
                    <span>Total</span>
                    <span>${total.toFixed(2)}</span>
                  </div>
                </div>
              </div>
              <p className="text-sm text-muted-foreground text-center">
                A confirmation email has been sent to your email address.
              </p>
            </CardContent>
            <CardFooter>
              <Button className="w-full" onClick={() => router.push("/shop")}>
                Continue Shopping
              </Button>
            </CardFooter>
          </Card>
        </div>
      </div>
    )
  }

  return (
    <div className="container py-10">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <h1 className="text-3xl font-bold mb-6">Checkout</h1>

          <form onSubmit={handleSubmit}>
            <Card className="mb-6">
              <CardHeader>
                <CardTitle>Shipping Information</CardTitle>
                <CardDescription>Enter your shipping details</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Full Name</Label>
                    <Input
                      id="name"
                      name="name"
                      placeholder="John Doe"
                      className={formErrors.name ? "border-red-500" : ""}
                    />
                    {formErrors.name && <p className="text-sm text-red-500">{formErrors.name}</p>}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="email">Email Address</Label>
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      placeholder="john@example.com"
                      className={formErrors.email ? "border-red-500" : ""}
                    />
                    {formErrors.email && <p className="text-sm text-red-500">{formErrors.email}</p>}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="address">Street Address</Label>
                    <Input
                      id="address"
                      name="address"
                      placeholder="123 Main St"
                      className={formErrors.address ? "border-red-500" : ""}
                    />
                    {formErrors.address && <p className="text-sm text-red-500">{formErrors.address}</p>}
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="city">City</Label>
                      <Input
                        id="city"
                        name="city"
                        placeholder="New York"
                        className={formErrors.city ? "border-red-500" : ""}
                      />
                      {formErrors.city && <p className="text-sm text-red-500">{formErrors.city}</p>}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="zip">ZIP / Postal Code</Label>
                      <Input
                        id="zip"
                        name="zip"
                        placeholder="10001"
                        className={formErrors.zip ? "border-red-500" : ""}
                      />
                      {formErrors.zip && <p className="text-sm text-red-500">{formErrors.zip}</p>}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="mb-6">
              <CardHeader>
                <CardTitle>Payment Method</CardTitle>
                <CardDescription>Select your preferred payment method</CardDescription>
              </CardHeader>
              <CardContent>
                <Tabs value={paymentMethod} onValueChange={setPaymentMethod}>
                  <TabsList className="grid grid-cols-3 mb-4">
                    <TabsTrigger value="credit-card" className="flex items-center gap-2">
                      <CreditCard className="h-4 w-4" />
                      <span>Credit Card</span>
                    </TabsTrigger>
                    <TabsTrigger value="crypto" className="flex items-center gap-2">
                      <Bitcoin className="h-4 w-4" />
                      <span>Cryptocurrency</span>
                    </TabsTrigger>
                    <TabsTrigger value="paypal" className="flex items-center gap-2">
                      <DollarSign className="h-4 w-4" />
                      <span>PayPal</span>
                    </TabsTrigger>
                  </TabsList>

                  <TabsContent value="credit-card" className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="cardNumber">Card Number</Label>
                      <Input
                        id="cardNumber"
                        name="cardNumber"
                        placeholder="4242 4242 4242 4242"
                        className={formErrors.cardNumber ? "border-red-500" : ""}
                        onChange={(e) => {
                          e.target.value = formatCardNumber(e.target.value)
                        }}
                      />
                      {formErrors.cardNumber && <p className="text-sm text-red-500">{formErrors.cardNumber}</p>}
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="cardExpiry">Expiry Date</Label>
                        <Input
                          id="cardExpiry"
                          name="cardExpiry"
                          placeholder="MM/YY"
                          className={formErrors.cardExpiry ? "border-red-500" : ""}
                          onChange={(e) => {
                            e.target.value = formatExpiryDate(e.target.value)
                          }}
                        />
                        {formErrors.cardExpiry && <p className="text-sm text-red-500">{formErrors.cardExpiry}</p>}
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="cardCvc">CVC</Label>
                        <Input
                          id="cardCvc"
                          name="cardCvc"
                          placeholder="123"
                          maxLength={4}
                          className={formErrors.cardCvc ? "border-red-500" : ""}
                        />
                        {formErrors.cardCvc && <p className="text-sm text-red-500">{formErrors.cardCvc}</p>}
                      </div>
                    </div>

                    <div className="flex items-center">
                      <img src="/placeholder.svg?height=30&width=120" alt="Payment processors" className="h-8" />
                      <span className="text-xs text-muted-foreground ml-2">Powered by Stripe</span>
                    </div>
                  </TabsContent>

                  <TabsContent value="crypto" className="space-y-4">
                    <Alert>
                      <AlertCircle className="h-4 w-4" />
                      <AlertTitle>Cryptocurrency Payment</AlertTitle>
                      <AlertDescription>
                        We accept Bitcoin (BTC), Ethereum (ETH), and other major cryptocurrencies. You'll receive
                        payment instructions after clicking "Place Order".
                      </AlertDescription>
                    </Alert>

                    <div className="flex items-center">
                      <img src="/placeholder.svg?height=30&width=120" alt="Crypto payment processors" className="h-8" />
                      <span className="text-xs text-muted-foreground ml-2">Powered by Coinpal</span>
                    </div>
                  </TabsContent>

                  <TabsContent value="paypal" className="space-y-4">
                    <Alert>
                      <AlertCircle className="h-4 w-4" />
                      <AlertTitle>PayPal Payment</AlertTitle>
                      <AlertDescription>
                        You'll be redirected to PayPal to complete your payment after clicking "Place Order".
                      </AlertDescription>
                    </Alert>

                    <div className="flex items-center">
                      <img src="/placeholder.svg?height=30&width=120" alt="PayPal" className="h-8" />
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>

            <Button type="submit" size="lg" className="w-full" disabled={isProcessing}>
              {isProcessing ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Processing...
                </>
              ) : (
                `Place Order - $${total.toFixed(2)}`
              )}
            </Button>
          </form>
        </div>

        <div>
          <Card>
            <CardHeader>
              <CardTitle>Order Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {cartItems.map((item) => (
                <div key={item.id} className="flex justify-between">
                  <div>
                    <p className="font-medium">{item.name}</p>
                    <p className="text-sm text-muted-foreground">Quantity: {item.quantity}</p>
                  </div>
                  <p className="font-medium">${item.price.toFixed(2)}</p>
                </div>
              ))}

              <Separator />

              <div className="flex justify-between">
                <p>Subtotal</p>
                <p>${subtotal.toFixed(2)}</p>
              </div>

              <div className="flex justify-between">
                <p>Tax (7%)</p>
                <p>${tax.toFixed(2)}</p>
              </div>

              <Separator />

              <div className="flex justify-between font-bold">
                <p>Total</p>
                <p>${total.toFixed(2)}</p>
              </div>
            </CardContent>
            <CardFooter>
              <p className="text-xs text-muted-foreground">
                By placing your order, you agree to our Terms of Service and Privacy Policy.
              </p>
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  )
}

