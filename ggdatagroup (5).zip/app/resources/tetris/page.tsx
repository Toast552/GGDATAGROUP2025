"use client"

import { useState, useEffect, useCallback, useRef } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { DisclosureBanner } from "@/components/disclosure-banner"
import { Play, Pause, RotateCw, ArrowDown, ArrowLeft, ArrowRight, RefreshCw, Volume2, VolumeX } from "lucide-react"

// Tetris piece types
const TETROMINOS = {
  0: { shape: [[0]], color: "0, 0, 0" },
  I: {
    shape: [
      [0, "I", 0, 0],
      [0, "I", 0, 0],
      [0, "I", 0, 0],
      [0, "I", 0, 0],
    ],
    color: "80, 227, 230",
  },
  J: {
    shape: [
      [0, "J", 0],
      [0, "J", 0],
      ["J", "J", 0],
    ],
    color: "36, 95, 223",
  },
  L: {
    shape: [
      [0, "L", 0],
      [0, "L", 0],
      [0, "L", "L"],
    ],
    color: "223, 173, 36",
  },
  O: {
    shape: [
      ["O", "O"],
      ["O", "O"],
    ],
    color: "223, 217, 36",
  },
  S: {
    shape: [
      [0, "S", "S"],
      ["S", "S", 0],
      [0, 0, 0],
    ],
    color: "48, 211, 56",
  },
  T: {
    shape: [
      [0, 0, 0],
      ["T", "T", "T"],
      [0, "T", 0],
    ],
    color: "132, 61, 198",
  },
  Z: {
    shape: [
      ["Z", "Z", 0],
      [0, "Z", "Z"],
      [0, 0, 0],
    ],
    color: "227, 78, 78",
  },
}

// Random tetromino generator
const randomTetromino = () => {
  const tetrominos = "IJLOSTZ"
  const randTetromino = tetrominos[Math.floor(Math.random() * tetrominos.length)]
  return TETROMINOS[randTetromino]
}

// Create stage
const createStage = () => Array.from(Array(20), () => Array(10).fill([0, "clear"]))

// Check if collision
const checkCollision = (player, stage, { x: moveX, y: moveY }) => {
  for (let y = 0; y < player.tetromino.length; y += 1) {
    for (let x = 0; x < player.tetromino[0].length; x += 1) {
      // 1. Check that we're on an actual Tetromino cell
      if (player.tetromino[y][x] !== 0) {
        if (
          // 2. Check that our move is inside the game areas height (y)
          // We shouldn't go through the bottom of the play area
          !stage[y + player.pos.y + moveY] ||
          // 3. Check that our move is inside the game areas width (x)
          !stage[y + player.pos.y + moveY][x + player.pos.x + moveX] ||
          // 4. Check that the cell we're moving to isn't set to clear
          stage[y + player.pos.y + moveY][x + player.pos.x + moveX][1] !== "clear"
        ) {
          return true
        }
      }
    }
  }
  return false
}

export default function TetrisPage() {
  const [stage, setStage] = useState(createStage())
  const [player, setPlayer] = useState({
    pos: { x: 0, y: 0 },
    tetromino: TETROMINOS[0].shape,
    collided: false,
  })
  const [dropTime, setDropTime] = useState(null)
  const [gameOver, setGameOver] = useState(false)
  const [score, setScore] = useState(0)
  const [rows, setRows] = useState(0)
  const [level, setLevel] = useState(1)
  const [isPaused, setIsPaused] = useState(false)
  const [isGameStarted, setIsGameStarted] = useState(false)
  const [isMuted, setIsMuted] = useState(true)
  const [highScore, setHighScore] = useState(0)

  const playerRef = useRef(player)
  const audioRef = useRef<HTMLAudioElement | null>(null)

  useEffect(() => {
    playerRef.current = player
  }, [player])

  useEffect(() => {
    // Load high score from localStorage
    const savedHighScore = localStorage.getItem("tetris-high-score")
    if (savedHighScore) {
      setHighScore(Number.parseInt(savedHighScore, 10))
    }

    // Setup audio
    const audio = new Audio("/tetris-theme.mp3")
    audio.loop = true
    audio.volume = 0.5
    audioRef.current = audio

    return () => {
      if (audioRef.current) {
        audioRef.current.pause()
        audioRef.current = null
      }
    }
  }, [])

  const toggleSound = () => {
    setIsMuted(!isMuted)
    if (audioRef.current) {
      if (isMuted) {
        audioRef.current.play().catch((e) => console.error("Audio play failed:", e))
      } else {
        audioRef.current.pause()
      }
    }
  }

  const resetPlayer = useCallback(() => {
    const newTetromino = randomTetromino()
    setPlayer({
      pos: { x: 4, y: 0 },
      tetromino: newTetromino.shape,
      collided: false,
    })
  }, [])

  // Sweep completed rows
  const sweepRows = useCallback(
    (newStage) => {
      let rowsCleared = 0
      const stage = newStage.reduce((acc, row) => {
        if (row.findIndex((cell) => cell[0] === 0) === -1) {
          rowsCleared += 1
          acc.unshift(new Array(newStage[0].length).fill([0, "clear"]))
          return acc
        }
        acc.push(row)
        return acc
      }, [])

      if (rowsCleared > 0) {
        // Calculate score based on rows cleared and level
        const newScore = score + rowsCleared * 100 * level
        setScore(newScore)
        setRows((prev) => prev + rowsCleared)

        // Update high score if needed
        if (newScore > highScore) {
          setHighScore(newScore)
          localStorage.setItem("tetris-high-score", newScore.toString())
        }
      }

      return stage
    },
    [level, score, highScore],
  )

  // Update stage
  const updateStage = useCallback(
    (prevStage) => {
      // First flush the stage
      const newStage = prevStage.map((row) => row.map((cell) => (cell[1] === "clear" ? [0, "clear"] : cell)))

      // Then draw the tetromino
      playerRef.current.tetromino.forEach((row, y) => {
        row.forEach((value, x) => {
          if (value !== 0) {
            newStage[y + playerRef.current.pos.y][x + playerRef.current.pos.x] = [
              value,
              `${playerRef.current.collided ? "merged" : "clear"}`,
            ]
          }
        })
      })

      // Then check if we collided
      if (playerRef.current.collided) {
        resetPlayer()
        return sweepRows(newStage)
      }

      return newStage
    },
    [resetPlayer, sweepRows],
  )

  // Start game
  const startGame = () => {
    // Reset everything
    setStage(createStage())
    resetPlayer()
    setGameOver(false)
    setScore(0)
    setRows(0)
    setLevel(1)
    setDropTime(1000)
    setIsPaused(false)
    setIsGameStarted(true)

    // Start music if not muted
    if (!isMuted && audioRef.current) {
      audioRef.current.currentTime = 0
      audioRef.current.play().catch((e) => console.error("Audio play failed:", e))
    }
  }

  // Pause game
  const pauseGame = () => {
    if (isGameStarted && !gameOver) {
      setIsPaused(!isPaused)
      if (isPaused) {
        setDropTime(1000 / level)
        if (!isMuted && audioRef.current) {
          audioRef.current.play().catch((e) => console.error("Audio play failed:", e))
        }
      } else {
        setDropTime(null)
        if (audioRef.current) {
          audioRef.current.pause()
        }
      }
    }
  }

  // Move player
  const movePlayer = (dir) => {
    setPlayer((prev) => {
      if (!checkCollision(prev, stage, { x: dir, y: 0 })) {
        return {
          ...prev,
          pos: { x: prev.pos.x + dir, y: prev.pos.y },
        }
      }
      return prev
    })
  }

  // Rotate player
  const rotate = (matrix, dir) => {
    // Make the rows become cols (transpose)
    const rotatedTetro = matrix.map((_, index) => matrix.map((col) => col[index]))
    // Reverse each row to get a rotated matrix
    if (dir > 0) return rotatedTetro.map((row) => row.reverse())
    return rotatedTetro.reverse()
  }

  const rotatePlayer = useCallback(
    (dir) => {
      const clonedPlayer = JSON.parse(JSON.stringify(player))
      clonedPlayer.tetromino = rotate(clonedPlayer.tetromino, dir)

      // Check collision on rotation
      let offset = 1
      while (checkCollision(clonedPlayer, stage, { x: 0, y: 0 })) {
        clonedPlayer.pos.x += offset
        offset = -(offset + (offset > 0 ? 1 : -1))
        if (offset > clonedPlayer.tetromino[0].length) {
          rotate(clonedPlayer.tetromino, -dir)
          return
        }
      }

      setPlayer(clonedPlayer)
    },
    [player, stage],
  )

  // Drop player
  const drop = useCallback(() => {
    // Increase level when player has cleared 10 rows
    if (rows > level * 10) {
      setLevel((prev) => prev + 1)
      // Also increase speed
      setDropTime(1000 / (level + 1) + 200)
    }

    setPlayer((prev) => {
      if (!checkCollision(prev, stage, { x: 0, y: 1 })) {
        return {
          ...prev,
          pos: { x: prev.pos.x, y: prev.pos.y + 1 },
          collided: false,
        }
      } else {
        // Game over
        if (prev.pos.y < 1) {
          setGameOver(true)
          setDropTime(null)
          setIsGameStarted(false)
          if (audioRef.current) {
            audioRef.current.pause()
          }
        }
        return {
          ...prev,
          collided: true,
        }
      }
    })
  }, [level, rows, stage])

  // Drop player fast
  const dropPlayer = useCallback(() => {
    if (!isPaused && isGameStarted) {
      drop()
    }
  }, [isPaused, isGameStarted, drop])

  // Move player left or right
  const move = useCallback(
    (dir) => {
      if (!isPaused && isGameStarted && !gameOver) {
        movePlayer(dir)
      }
    },
    [isPaused, isGameStarted, gameOver, movePlayer],
  )

  // Handle key presses
  useEffect(() => {
    if (gameOver || isPaused) return

    const handleKeyDown = (e) => {
      if (isGameStarted) {
        switch (e.keyCode) {
          case 37: // Left arrow
            move(-1)
            break
          case 39: // Right arrow
            move(1)
            break
          case 40: // Down arrow
            dropPlayer()
            break
          case 38: // Up arrow
            rotatePlayer(1)
            break
          default:
            break
        }
      }
    }

    document.addEventListener("keydown", handleKeyDown)
    return () => {
      document.removeEventListener("keydown", handleKeyDown)
    }
  }, [gameOver, dropPlayer, move, rotatePlayer, isGameStarted, isPaused])

  // Start the game interval
  useEffect(() => {
    if (dropTime !== null && !isPaused) {
      const interval = setInterval(() => {
        drop()
      }, dropTime)
      return () => {
        clearInterval(interval)
      }
    }
  }, [drop, dropTime, isPaused])

  // Update the stage
  useEffect(() => {
    if (isGameStarted && !gameOver) {
      setStage((prev) => updateStage(prev))
    }
  }, [updateStage, gameOver, isGameStarted])

  // Update level based on rows cleared
  useEffect(() => {
    if (rows >= level * 10) {
      setLevel((prev) => prev + 1)
      setDropTime(1000 / (level + 1) + 200)
    }
  }, [rows, level])

  return (
    <div className="container py-10">
      <div className="max-w-3xl mx-auto text-center mb-6">
        <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl mb-4">Tetris Game</h1>
        <p className="text-muted-foreground md:text-xl">Take a break and enjoy a classic game of Tetris</p>
      </div>

      <DisclosureBanner
        title="Just For Fun"
        description="This Tetris game is provided for entertainment purposes only. Take a break from your financial analysis and enjoy a classic game!"
        variant="default"
      />

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto mt-8">
        <div className="md:col-span-2">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle>Game Board</CardTitle>
                <Button variant="ghost" size="icon" onClick={toggleSound} aria-label={isMuted ? "Unmute" : "Mute"}>
                  {isMuted ? <VolumeX className="h-5 w-5" /> : <Volume2 className="h-5 w-5" />}
                </Button>
              </div>
              <CardDescription>Use arrow keys to play or the controls below</CardDescription>
            </CardHeader>
            <CardContent className="flex justify-center">
              <div
                className="relative border-2 border-gray-800 dark:border-gray-200"
                style={{ width: "300px", height: "600px" }}
              >
                {gameOver ? (
                  <div className="absolute inset-0 bg-black/80 flex flex-col items-center justify-center text-white p-4">
                    <h2 className="text-2xl font-bold mb-4">Game Over</h2>
                    <p className="mb-2">Score: {score}</p>
                    <p className="mb-4">Level: {level}</p>
                    <Button onClick={startGame}>Play Again</Button>
                  </div>
                ) : (
                  <>
                    {stage.map((row, y) => (
                      <div key={y} className="flex">
                        {row.map((cell, x) => (
                          <div
                            key={x}
                            className={`w-[30px] h-[30px] border border-gray-900/20 dark:border-gray-100/20 ${
                              cell[0] !== 0 ? `bg-[rgb(${TETROMINOS[cell[0]].color})]` : "bg-black/10 dark:bg-white/5"
                            }`}
                          ></div>
                        ))}
                      </div>
                    ))}
                  </>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        <div>
          <Card className="mb-6">
            <CardHeader>
              <CardTitle>Game Stats</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <p className="text-sm text-muted-foreground">Score</p>
                  <p className="text-2xl font-bold">{score}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">High Score</p>
                  <p className="text-2xl font-bold">{highScore}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Rows Cleared</p>
                  <p className="text-2xl font-bold">{rows}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Level</p>
                  <p className="text-2xl font-bold">{level}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Controls</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {!isGameStarted ? (
                  <Button onClick={startGame} className="w-full">
                    <Play className="mr-2 h-4 w-4" />
                    Start Game
                  </Button>
                ) : (
                  <Button onClick={pauseGame} className="w-full">
                    {isPaused ? <Play className="mr-2 h-4 w-4" /> : <Pause className="mr-2 h-4 w-4" />}
                    {isPaused ? "Resume" : "Pause"}
                  </Button>
                )}

                <div className="grid grid-cols-3 gap-2">
                  <Button
                    variant="outline"
                    onClick={() => move(-1)}
                    disabled={!isGameStarted || gameOver || isPaused}
                    className="flex flex-col items-center py-6"
                  >
                    <ArrowLeft className="h-6 w-6 mb-1" />
                    <span className="text-xs">Left</span>
                  </Button>
                  <Button
                    variant="outline"
                    onClick={dropPlayer}
                    disabled={!isGameStarted || gameOver || isPaused}
                    className="flex flex-col items-center py-6"
                  >
                    <ArrowDown className="h-6 w-6 mb-1" />
                    <span className="text-xs">Down</span>
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => move(1)}
                    disabled={!isGameStarted || gameOver || isPaused}
                    className="flex flex-col items-center py-6"
                  >
                    <ArrowRight className="h-6 w-6 mb-1" />
                    <span className="text-xs">Right</span>
                  </Button>
                </div>

                <Button
                  variant="outline"
                  onClick={() => rotatePlayer(1)}
                  disabled={!isGameStarted || gameOver || isPaused}
                  className="w-full"
                >
                  <RotateCw className="mr-2 h-4 w-4" />
                  Rotate
                </Button>

                {gameOver && (
                  <Button onClick={startGame} className="w-full">
                    <RefreshCw className="mr-2 h-4 w-4" />
                    Play Again
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      <div className="max-w-3xl mx-auto mt-12 text-center">
        <h2 className="text-2xl font-bold mb-4">How to Play</h2>
        <div className="text-left space-y-2 mb-8">
          <p>• Use the arrow keys or buttons to move and rotate the falling pieces.</p>
          <p>• Complete horizontal lines to clear them and earn points.</p>
          <p>• The game speeds up as you level up.</p>
          <p>• The game ends when the pieces stack up to the top of the board.</p>
        </div>
        <Button variant="outline" onClick={() => window.history.back()}>
          Return to Resources
        </Button>
      </div>
    </div>
  )
}

