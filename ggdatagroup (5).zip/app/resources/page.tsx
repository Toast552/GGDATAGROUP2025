import Link from "next/link"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Terminal, Bot, Gamepad2, BookOpen } from "lucide-react"

export default function ResourcesPage() {
  return (
    <div className="container py-12">
      <div className="max-w-3xl mx-auto text-center mb-10">
        <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl mb-4">Resources</h1>
        <p className="text-muted-foreground md:text-xl">
          Explore our tools and resources to enhance your financial data analysis
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <Card className="flex flex-col h-full">
          <CardHeader>
            <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
              <Terminal className="h-6 w-6 text-primary" />
            </div>
            <CardTitle>TERMINAL</CardTitle>
            <CardDescription>Access real-time market data and analytics with our powerful terminal</CardDescription>
          </CardHeader>
          <CardContent className="flex-grow">
            <p className="text-sm text-muted-foreground">
              Our terminal provides comprehensive financial data, advanced charting tools, and real-time market insights
              to help you make informed decisions.
            </p>
          </CardContent>
          <CardFooter>
            <Link href="/resources/terminal" className="w-full">
              <Button variant="default" className="w-full">
                Launch Terminal
              </Button>
            </Link>
          </CardFooter>
        </Card>

        <Card className="flex flex-col h-full">
          <CardHeader>
            <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
              <Bot className="h-6 w-6 text-primary" />
            </div>
            <CardTitle>AI Model</CardTitle>
            <CardDescription>Leverage AI-powered insights for trading and market analysis</CardDescription>
          </CardHeader>
          <CardContent className="flex-grow">
            <p className="text-sm text-muted-foreground">
              Our AI model uses advanced machine learning algorithms to analyze market trends, predict price movements,
              and optimize trading strategies.
            </p>
          </CardContent>
          <CardFooter>
            <Link href="/resources/ai-trading" className="w-full">
              <Button variant="default" className="w-full">
                Explore AI Model
              </Button>
            </Link>
          </CardFooter>
        </Card>

        <Card className="flex flex-col h-full">
          <CardHeader>
            <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
              <Gamepad2 className="h-6 w-6 text-primary" />
            </div>
            <CardTitle>Tetris</CardTitle>
            <CardDescription>Take a break and enjoy a classic game of Tetris</CardDescription>
          </CardHeader>
          <CardContent className="flex-grow">
            <p className="text-sm text-muted-foreground">
              Sometimes you need a mental break. Our Tetris game provides a fun way to relax while still keeping your
              mind sharp and focused.
            </p>
          </CardContent>
          <CardFooter>
            <Link href="/resources/tetris" className="w-full">
              <Button variant="default" className="w-full">
                Play Tetris
              </Button>
            </Link>
          </CardFooter>
        </Card>

        <Card className="flex flex-col h-full md:col-span-2 lg:col-span-3">
          <CardHeader>
            <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
              <BookOpen className="h-6 w-6 text-primary" />
            </div>
            <CardTitle>Knowledge Base</CardTitle>
            <CardDescription>Explore our comprehensive guides and tutorials</CardDescription>
          </CardHeader>
          <CardContent className="flex-grow">
            <p className="text-sm text-muted-foreground">
              Our knowledge base contains detailed guides, tutorials, and documentation to help you get the most out of
              our services and tools.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
              <div className="bg-muted rounded-lg p-4">
                <h3 className="font-medium mb-2">Getting Started</h3>
                <p className="text-sm text-muted-foreground mb-4">Learn the basics of our platform and services</p>
                <Link href="/resources/knowledge/getting-started">
                  <Button variant="outline" size="sm">
                    Read More
                  </Button>
                </Link>
              </div>
              <div className="bg-muted rounded-lg p-4">
                <h3 className="font-medium mb-2">Advanced Techniques</h3>
                <p className="text-sm text-muted-foreground mb-4">Master advanced data analysis methods</p>
                <Link href="/resources/knowledge/advanced">
                  <Button variant="outline" size="sm">
                    Read More
                  </Button>
                </Link>
              </div>
              <div className="bg-muted rounded-lg p-4">
                <h3 className="font-medium mb-2">API Documentation</h3>
                <p className="text-sm text-muted-foreground mb-4">Integrate our services with your applications</p>
                <Link href="/resources/knowledge/api">
                  <Button variant="outline" size="sm">
                    Read More
                  </Button>
                </Link>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

