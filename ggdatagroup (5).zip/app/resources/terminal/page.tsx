"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { TerminalIcon, Search, RefreshCw, Download, BarChart3, LineChart, PieChart } from "lucide-react"
import { sanitizeInput } from "@/lib/security"
import { ProtectedRoute } from "@/components/protected-route"

export default function TerminalPage() {
  return (
    <ProtectedRoute requirePremium>
      <div className="container py-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold tracking-tighter mb-2 flex items-center">
              <TerminalIcon className="mr-2 h-8 w-8" />
              TERMINAL
            </h1>
            <p className="text-muted-foreground">Access real-time market data and advanced analytics</p>
          </div>
          <div className="mt-4 md:mt-0 flex items-center space-x-2">
            <Button variant="outline" size="sm">
              <RefreshCw className="h-4 w-4 mr-2" />
              Refresh
            </Button>
            <Button variant="outline" size="sm">
              <Download className="h-4 w-4 mr-2" />
              Export
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle>Search</CardTitle>
                <CardDescription>Find assets and market data</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="relative">
                    <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input
                      type="search"
                      placeholder="Search symbols..."
                      className="pl-8"
                      onChange={(e) => {
                        // Sanitize input
                        const sanitizedValue = sanitizeInput(e.target.value)
                        console.log("Searching for:", sanitizedValue)
                      }}
                    />
                  </div>

                  <div className="space-y-2">
                    <h3 className="text-sm font-medium">Popular Searches</h3>
                    <ul className="space-y-1">
                      <li>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="w-full justify-start text-muted-foreground hover:text-foreground"
                        >
                          BTC/USD
                        </Button>
                      </li>
                      <li>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="w-full justify-start text-muted-foreground hover:text-foreground"
                        >
                          ETH/USD
                        </Button>
                      </li>
                      <li>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="w-full justify-start text-muted-foreground hover:text-foreground"
                        >
                          S&P 500
                        </Button>
                      </li>
                      <li>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="w-full justify-start text-muted-foreground hover:text-foreground"
                        >
                          NASDAQ
                        </Button>
                      </li>
                      <li>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="w-full justify-start text-muted-foreground hover:text-foreground"
                        >
                          Gold
                        </Button>
                      </li>
                    </ul>
                  </div>

                  <div className="space-y-2">
                    <h3 className="text-sm font-medium">Watchlist</h3>
                    <ul className="space-y-1">
                      <li>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="w-full justify-start text-muted-foreground hover:text-foreground"
                        >
                          BTC/USD
                        </Button>
                      </li>
                      <li>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="w-full justify-start text-muted-foreground hover:text-foreground"
                        >
                          ETH/USD
                        </Button>
                      </li>
                      <li>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="w-full justify-start text-muted-foreground hover:text-foreground"
                        >
                          SOL/USD
                        </Button>
                      </li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="lg:col-span-3">
            <Card className="h-full">
              <CardHeader>
                <Tabs defaultValue="chart">
                  <div className="flex justify-between items-center">
                    <CardTitle>BTC/USD</CardTitle>
                    <TabsList>
                      <TabsTrigger value="chart">
                        <LineChart className="h-4 w-4 mr-2" />
                        Chart
                      </TabsTrigger>
                      <TabsTrigger value="orderbook">
                        <BarChart3 className="h-4 w-4 mr-2" />
                        Order Book
                      </TabsTrigger>
                      <TabsTrigger value="analytics">
                        <PieChart className="h-4 w-4 mr-2" />
                        Analytics
                      </TabsTrigger>
                    </TabsList>
                  </div>
                  <CardDescription className="flex justify-between items-center mt-2">
                    <span>Bitcoin to US Dollar</span>
                    <span className="font-medium text-green-500">$43,256.78 (+2.34%)</span>
                  </CardDescription>
                </Tabs>
              </CardHeader>
              <CardContent>
                <TabsContent value="chart" className="mt-0">
                  <div className="aspect-[16/9] bg-muted rounded-md flex items-center justify-center">
                    <div className="text-center">
                      <LineChart className="h-16 w-16 mx-auto text-muted-foreground" />
                      <p className="mt-2 text-sm text-muted-foreground">Interactive chart would be displayed here</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-6">
                    <div className="bg-muted p-3 rounded-md">
                      <div className="text-sm text-muted-foreground">24h High</div>
                      <div className="font-medium">$44,123.45</div>
                    </div>
                    <div className="bg-muted p-3 rounded-md">
                      <div className="text-sm text-muted-foreground">24h Low</div>
                      <div className="font-medium">$41,987.65</div>
                    </div>
                    <div className="bg-muted p-3 rounded-md">
                      <div className="text-sm text-muted-foreground">24h Volume</div>
                      <div className="font-medium">$1.2B</div>
                    </div>
                    <div className="bg-muted p-3 rounded-md">
                      <div className="text-sm text-muted-foreground">Market Cap</div>
                      <div className="font-medium">$823.4B</div>
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="orderbook" className="mt-0">
                  <div className="grid grid-cols-2 gap-6">
                    <div>
                      <h3 className="text-sm font-medium mb-2">Bids</h3>
                      <div className="space-y-1">
                        {[
                          { price: 43250.25, amount: 1.2345 },
                          { price: 43245.5, amount: 0.8765 },
                          { price: 43240.75, amount: 2.1098 },
                          { price: 43235.0, amount: 1.5432 },
                          { price: 43230.25, amount: 3.2109 },
                        ].map((bid, index) => (
                          <div key={index} className="flex justify-between text-sm">
                            <span className="text-green-500">${bid.price.toFixed(2)}</span>
                            <span>{bid.amount.toFixed(4)}</span>
                            <span>${(bid.price * bid.amount).toFixed(2)}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div>
                      <h3 className="text-sm font-medium mb-2">Asks</h3>
                      <div className="space-y-1">
                        {[
                          { price: 43260.5, amount: 0.9876 },
                          { price: 43265.25, amount: 1.3579 },
                          { price: 43270.0, amount: 0.6543 },
                          { price: 43275.75, amount: 2.468 },
                          { price: 43280.5, amount: 1.1122 },
                        ].map((ask, index) => (
                          <div key={index} className="flex justify-between text-sm">
                            <span className="text-red-500">${ask.price.toFixed(2)}</span>
                            <span>{ask.amount.toFixed(4)}</span>
                            <span>${(ask.price * ask.amount).toFixed(2)}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="analytics" className="mt-0">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="bg-muted p-4 rounded-md">
                      <h3 className="text-sm font-medium mb-2">Price Correlation</h3>
                      <div className="aspect-[4/3] flex items-center justify-center">
                        <PieChart className="h-12 w-12 text-muted-foreground" />
                      </div>
                    </div>

                    <div className="bg-muted p-4 rounded-md">
                      <h3 className="text-sm font-medium mb-2">Volume Analysis</h3>
                      <div className="aspect-[4/3] flex items-center justify-center">
                        <BarChart3 className="h-12 w-12 text-muted-foreground" />
                      </div>
                    </div>

                    <div className="md:col-span-2 bg-muted p-4 rounded-md">
                      <h3 className="text-sm font-medium mb-2">Technical Indicators</h3>
                      <div className="grid grid-cols-3 gap-4">
                        <div className="text-center">
                          <div className="text-sm text-muted-foreground">RSI (14)</div>
                          <div className="font-medium">58.34</div>
                        </div>
                        <div className="text-center">
                          <div className="text-sm text-muted-foreground">MACD</div>
                          <div className="font-medium">125.67</div>
                        </div>
                        <div className="text-center">
                          <div className="text-sm text-muted-foreground">MA (50)</div>
                          <div className="font-medium">$42,876.54</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </TabsContent>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </ProtectedRoute>
  )
}

