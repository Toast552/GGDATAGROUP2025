"use client"

import { AIChatbot } from "@/components/ai-chatbot"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Bot, LineChart, Zap, Database } from "lucide-react"
import { ProtectedRoute } from "@/components/protected-route"

export default function AIModelPage() {
  return (
    <ProtectedRoute requirePremium>
      <div className="container py-12">
        <div className="max-w-3xl mx-auto text-center mb-10">
          <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl mb-4">AI Model</h1>
          <p className="text-muted-foreground md:text-xl">
            Leverage the power of artificial intelligence for advanced market analysis and insights
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <Card className="h-full">
              <CardHeader>
                <CardTitle>AI Assistant</CardTitle>
                <CardDescription>Chat with our AI assistant to get market insights and analysis</CardDescription>
              </CardHeader>
              <CardContent>
                <AIChatbot />
              </CardContent>
            </Card>
          </div>

          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>AI Model Features</CardTitle>
                <CardDescription>Explore the capabilities of our AI model</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-start">
                    <div className="mr-4 mt-1">
                      <LineChart className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-medium">Market Analysis</h3>
                      <p className="text-sm text-muted-foreground">Real-time analysis of market trends and patterns</p>
                    </div>
                  </div>

                  <div className="flex items-start">
                    <div className="mr-4 mt-1">
                      <Zap className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-medium">Predictive Insights</h3>
                      <p className="text-sm text-muted-foreground">
                        Advanced algorithms to forecast potential market movements
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start">
                    <div className="mr-4 mt-1">
                      <Database className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-medium">Data Integration</h3>
                      <p className="text-sm text-muted-foreground">
                        Seamless integration with multiple data sources for comprehensive analysis
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start">
                    <div className="mr-4 mt-1">
                      <Bot className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-medium">Natural Language Processing</h3>
                      <p className="text-sm text-muted-foreground">
                        Communicate with our AI using natural language to get insights
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Model Performance</CardTitle>
                <CardDescription>Track the performance of our AI model</CardDescription>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="accuracy">
                  <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger value="accuracy">Accuracy</TabsTrigger>
                    <TabsTrigger value="speed">Speed</TabsTrigger>
                    <TabsTrigger value="coverage">Coverage</TabsTrigger>
                  </TabsList>
                  <TabsContent value="accuracy" className="pt-4">
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Market Prediction</span>
                        <span className="text-sm font-medium">87%</span>
                      </div>
                      <div className="w-full bg-muted rounded-full h-2">
                        <div className="bg-primary h-2 rounded-full" style={{ width: "87%" }}></div>
                      </div>

                      <div className="flex justify-between items-center mt-4">
                        <span className="text-sm">Trend Analysis</span>
                        <span className="text-sm font-medium">92%</span>
                      </div>
                      <div className="w-full bg-muted rounded-full h-2">
                        <div className="bg-primary h-2 rounded-full" style={{ width: "92%" }}></div>
                      </div>

                      <div className="flex justify-between items-center mt-4">
                        <span className="text-sm">Risk Assessment</span>
                        <span className="text-sm font-medium">85%</span>
                      </div>
                      <div className="w-full bg-muted rounded-full h-2">
                        <div className="bg-primary h-2 rounded-full" style={{ width: "85%" }}></div>
                      </div>
                    </div>
                  </TabsContent>
                  <TabsContent value="speed" className="pt-4">
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Response Time</span>
                        <span className="text-sm font-medium">0.3s</span>
                      </div>
                      <div className="w-full bg-muted rounded-full h-2">
                        <div className="bg-primary h-2 rounded-full" style={{ width: "95%" }}></div>
                      </div>

                      <div className="flex justify-between items-center mt-4">
                        <span className="text-sm">Processing Speed</span>
                        <span className="text-sm font-medium">0.5s</span>
                      </div>
                      <div className="w-full bg-muted rounded-full h-2">
                        <div className="bg-primary h-2 rounded-full" style={{ width: "90%" }}></div>
                      </div>

                      <div className="flex justify-between items-center mt-4">
                        <span className="text-sm">Data Retrieval</span>
                        <span className="text-sm font-medium">0.2s</span>
                      </div>
                      <div className="w-full bg-muted rounded-full h-2">
                        <div className="bg-primary h-2 rounded-full" style={{ width: "97%" }}></div>
                      </div>
                    </div>
                  </TabsContent>
                  <TabsContent value="coverage" className="pt-4">
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Market Coverage</span>
                        <span className="text-sm font-medium">95%</span>
                      </div>
                      <div className="w-full bg-muted rounded-full h-2">
                        <div className="bg-primary h-2 rounded-full" style={{ width: "95%" }}></div>
                      </div>

                      <div className="flex justify-between items-center mt-4">
                        <span className="text-sm">Asset Types</span>
                        <span className="text-sm font-medium">88%</span>
                      </div>
                      <div className="w-full bg-muted rounded-full h-2">
                        <div className="bg-primary h-2 rounded-full" style={{ width: "88%" }}></div>
                      </div>

                      <div className="flex justify-between items-center mt-4">
                        <span className="text-sm">Data Sources</span>
                        <span className="text-sm font-medium">92%</span>
                      </div>
                      <div className="w-full bg-muted rounded-full h-2">
                        <div className="bg-primary h-2 rounded-full" style={{ width: "92%" }}></div>
                      </div>
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </ProtectedRoute>
  )
}

