import Link from "next/link"
import Image from "next/image"
import { ArrowRight, Check } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { ChatBox } from "@/components/chat-box"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export const metadata = {
  title: "Home",
}

// Client component to use translations
function HomeContent() {
  return (
    <main className="flex-1">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-b from-background to-muted/30 pt-24 pb-16 md:pt-32 md:pb-24">
        <div className="absolute inset-0 bg-grid-pattern opacity-[0.02] pointer-events-none" />
        <div className="absolute top-0 right-0 w-full h-full overflow-hidden pointer-events-none">
          <div className="absolute -top-24 -right-24 w-96 h-96 bg-primary/10 rounded-full blur-3xl opacity-30" />
          <div className="absolute top-1/3 -left-24 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl opacity-30" />
        </div>

        <div className="container px-4 mx-auto relative z-10">
          <div className="flex flex-col items-center text-center max-w-4xl mx-auto">
            <div className="inline-flex items-center px-3 py-1 rounded-full border border-border bg-background/80 backdrop-blur-sm mb-6">
              <span className="text-xs font-medium mr-2">New</span>
              <span className="text-xs text-muted-foreground">Advanced Analytics Dashboard</span>
            </div>

            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight mb-6 bg-clip-text text-transparent bg-gradient-to-r from-primary to-blue-600">
              The Modern SaaS Platform for Your Business
            </h1>

            <p className="text-xl text-muted-foreground max-w-2xl mb-8">
              Streamline your operations, gain valuable insights, and scale your business with our all-in-one SaaS
              solution.
            </p>

            <div className="flex flex-wrap justify-center gap-4 mb-12">
              <Button size="lg" className="rounded-full gap-2 px-6">
                Get Started <ArrowRight className="h-4 w-4" />
              </Button>
              <Button size="lg" variant="outline" className="rounded-full">
                Book a Demo
              </Button>
            </div>

            <div className="relative w-full max-w-5xl mx-auto rounded-xl overflow-hidden shadow-2xl border border-border/50">
              <Image
                src="/placeholder.svg?height=800&width=1600&text=SaaSify+Dashboard"
                alt="SaaSify Dashboard"
                width={1600}
                height={800}
                className="w-full h-auto"
                priority
              />
              <div className="absolute inset-0 bg-gradient-to-t from-background/80 to-transparent opacity-0 hover:opacity-100 transition-opacity duration-300 flex items-end justify-center pb-8">
                <Button variant="secondary" className="rounded-full">
                  View Demo
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <div className="text-center">
              <p className="text-3xl md:text-4xl font-bold text-primary mb-2">10k+</p>
              <p className="text-sm text-muted-foreground">Active Users</p>
            </div>
            <div className="text-center">
              <p className="text-3xl md:text-4xl font-bold text-primary mb-2">99.9%</p>
              <p className="text-sm text-muted-foreground">Uptime</p>
            </div>
            <div className="text-center">
              <p className="text-3xl md:text-4xl font-bold text-primary mb-2">500+</p>
              <p className="text-sm text-muted-foreground">Enterprise Clients</p>
            </div>
            <div className="text-center">
              <p className="text-3xl md:text-4xl font-bold text-primary mb-2">24/7</p>
              <p className="text-sm text-muted-foreground">Support</p>
            </div>
          </div>
        </div>
      </section>

      {/* Trusted By Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-center text-xl font-medium text-muted-foreground mb-12">
            Trusted by leading companies worldwide
          </h2>
          <div className="flex flex-wrap justify-center items-center gap-12 md:gap-16">
            {[1, 2, 3, 4, 5].map((i) => (
              <div
                key={i}
                className="grayscale opacity-60 hover:grayscale-0 hover:opacity-100 transition-all duration-300"
              >
                <Image
                  src={`/placeholder.svg?height=40&width=160&text=PARTNER ${i}`}
                  alt={`Partner Logo ${i}`}
                  width={160}
                  height={40}
                />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Tabs Section */}
      <section className="py-24 bg-muted/20">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl font-bold mb-4">Comprehensive SaaS Solutions</h2>
            <p className="text-xl text-muted-foreground">
              Explore our suite of products designed to help your business grow and succeed
            </p>
          </div>

          <Tabs defaultValue="analytics" className="max-w-5xl mx-auto">
            <TabsList className="grid w-full grid-cols-3 mb-12">
              <TabsTrigger value="analytics">Analytics</TabsTrigger>
              <TabsTrigger value="automation">Automation</TabsTrigger>
              <TabsTrigger value="collaboration">Collaboration</TabsTrigger>
            </TabsList>

            <TabsContent value="analytics" className="border rounded-xl p-6 bg-card">
              <div className="grid md:grid-cols-2 gap-8 items-center">
                <div>
                  <h3 className="text-2xl font-bold mb-4">Advanced Analytics</h3>
                  <p className="text-muted-foreground mb-6">
                    Transform raw data into actionable insights with our comprehensive analytics platform.
                  </p>
                  <ul className="space-y-3 mb-8">
                    <li className="flex items-start">
                      <Check className="h-5 w-5 text-primary mr-2 mt-0.5" />
                      <span>Real-time data visualization and reporting</span>
                    </li>
                    <li className="flex items-start">
                      <Check className="h-5 w-5 text-primary mr-2 mt-0.5" />
                      <span>Custom dashboards for different departments</span>
                    </li>
                    <li className="flex items-start">
                      <Check className="h-5 w-5 text-primary mr-2 mt-0.5" />
                      <span>Predictive analytics powered by machine learning</span>
                    </li>
                    <li className="flex items-start">
                      <Check className="h-5 w-5 text-primary mr-2 mt-0.5" />
                      <span>Export and share reports with stakeholders</span>
                    </li>
                  </ul>
                  <Button asChild>
                    <Link href="/features/analytics">Learn More</Link>
                  </Button>
                </div>
                <div className="relative rounded-lg overflow-hidden shadow-lg">
                  <Image
                    src="/placeholder.svg?height=400&width=600&text=Analytics+Dashboard"
                    alt="Analytics Dashboard"
                    width={600}
                    height={400}
                    className="w-full h-auto"
                  />
                </div>
              </div>
            </TabsContent>

            <TabsContent value="automation" className="border rounded-xl p-6 bg-card">
              <div className="grid md:grid-cols-2 gap-8 items-center">
                <div>
                  <h3 className="text-2xl font-bold mb-4">Workflow Automation</h3>
                  <p className="text-muted-foreground mb-6">
                    Streamline your business processes with powerful automation tools that save time and reduce errors.
                  </p>
                  <ul className="space-y-3 mb-8">
                    <li className="flex items-start">
                      <Check className="h-5 w-5 text-primary mr-2 mt-0.5" />
                      <span>Visual workflow builder with drag-and-drop interface</span>
                    </li>
                    <li className="flex items-start">
                      <Check className="h-5 w-5 text-primary mr-2 mt-0.5" />
                      <span>Trigger-based actions and conditional logic</span>
                    </li>
                    <li className="flex items-start">
                      <Check className="h-5 w-5 text-primary mr-2 mt-0.5" />
                      <span>Integration with 100+ third-party services</span>
                    </li>
                    <li className="flex items-start">
                      <Check className="h-5 w-5 text-primary mr-2 mt-0.5" />
                      <span>Automated reporting and notifications</span>
                    </li>
                  </ul>
                  <Button asChild>
                    <Link href="/features/automation">Learn More</Link>
                  </Button>
                </div>
                <div className="relative rounded-lg overflow-hidden shadow-lg">
                  <Image
                    src="/placeholder.svg?height=400&width=600&text=Workflow+Automation"
                    alt="Workflow Automation"
                    width={600}
                    height={400}
                    className="w-full h-auto"
                  />
                </div>
              </div>
            </TabsContent>

            <TabsContent value="collaboration" className="border rounded-xl p-6 bg-card">
              <div className="grid md:grid-cols-2 gap-8 items-center">
                <div>
                  <h3 className="text-2xl font-bold mb-4">Team Collaboration</h3>
                  <p className="text-muted-foreground mb-6">
                    Enhance team productivity with our suite of collaboration tools designed for modern workplaces.
                  </p>
                  <ul className="space-y-3 mb-8">
                    <li className="flex items-start">
                      <Check className="h-5 w-5 text-primary mr-2 mt-0.5" />
                      <span>Real-time document editing and sharing</span>
                    </li>
                    <li className="flex items-start">
                      <Check className="h-5 w-5 text-primary mr-2 mt-0.5" />
                      <span>Project management with task tracking</span>
                    </li>
                    <li className="flex items-start">
                      <Check className="h-5 w-5 text-primary mr-2 mt-0.5" />
                      <span>Team chat and video conferencing</span>
                    </li>
                    <li className="flex items-start">
                      <Check className="h-5 w-5 text-primary mr-2 mt-0.5" />
                      <span>Shared calendars and scheduling tools</span>
                    </li>
                  </ul>
                  <Button asChild>
                    <Link href="/features/collaboration">Learn More</Link>
                  </Button>
                </div>
                <div className="relative rounded-lg overflow-hidden shadow-lg">
                  <Image
                    src="/placeholder.svg?height=400&width=600&text=Team+Collaboration"
                    alt="Team Collaboration"
                    width={600}
                    height={400}
                    className="w-full h-auto"
                  />
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-24">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl font-bold mb-4">Simple, Transparent Pricing</h2>
            <p className="text-xl text-muted-foreground">Choose the plan that's right for your business</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            <PricingCard
              title="Starter"
              price="$29"
              description="Perfect for small teams and startups"
              features={[
                "Up to 5 team members",
                "Basic analytics",
                "10 automation workflows",
                "Email support",
                "1GB storage",
              ]}
              buttonText="Get Started"
              buttonVariant="outline"
            />

            <PricingCard
              title="Professional"
              price="$79"
              description="Ideal for growing businesses"
              features={[
                "Up to 20 team members",
                "Advanced analytics",
                "Unlimited automation workflows",
                "Priority support",
                "10GB storage",
                "Custom integrations",
              ]}
              buttonText="Get Started"
              buttonVariant="default"
              highlighted={true}
            />

            <PricingCard
              title="Enterprise"
              price="$199"
              description="For large organizations with complex needs"
              features={[
                "Unlimited team members",
                "Enterprise-grade analytics",
                "Unlimited automation workflows",
                "24/7 dedicated support",
                "100GB storage",
                "Custom integrations",
                "On-premise deployment option",
                "SLA guarantees",
              ]}
              buttonText="Contact Sales"
              buttonVariant="outline"
            />
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-24 bg-muted/20">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl font-bold mb-4">What Our Customers Say</h2>
            <p className="text-xl text-muted-foreground">
              Don't just take our word for it - hear from some of our satisfied customers
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            <TestimonialCard
              quote="SaaSify has transformed how we manage our business operations. The analytics tools have given us insights we never had before."
              author="Sarah Johnson"
              position="CEO, TechStart Inc."
              image="/placeholder.svg?height=80&width=80"
            />

            <TestimonialCard
              quote="The automation features have saved our team countless hours of manual work. The ROI on this platform has been incredible."
              author="Michael Chen"
              position="CTO, GrowthLabs"
              image="/placeholder.svg?height=80&width=80"
            />

            <TestimonialCard
              quote="As a remote-first company, the collaboration tools have been essential for keeping our team connected and productive."
              author="Emily Rodriguez"
              position="COO, RemoteWorks"
              image="/placeholder.svg?height=80&width=80"
            />
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-24">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl font-bold mb-4">Frequently Asked Questions</h2>
            <p className="text-xl text-muted-foreground">Find answers to common questions about our platform</p>
          </div>

          <div className="max-w-3xl mx-auto space-y-4">
            <FaqItem
              question="How does the 14-day trial work?"
              answer="Our 14-day trial gives you full access to all features of the Professional plan. No credit card is required to start, and you can cancel anytime. At the end of the trial, you can choose to upgrade to a paid plan or downgrade to our free tier."
            />

            <FaqItem
              question="Can I change my plan later?"
              answer="Yes, you can upgrade, downgrade, or cancel your plan at any time. If you upgrade, the new features will be available immediately. If you downgrade, the changes will take effect at the start of your next billing cycle."
            />

            <FaqItem
              question="Is there a setup fee?"
              answer="No, there are no setup fees for any of our plans. You only pay the advertised monthly or annual subscription fee."
            />

            <FaqItem
              question="Do you offer discounts for nonprofits or educational institutions?"
              answer="Yes, we offer special pricing for nonprofits, educational institutions, and open-source projects. Please contact our sales team for more information."
            />

            <FaqItem
              question="How secure is my data?"
              answer="We take security very seriously. All data is encrypted both in transit and at rest. We use industry-standard security practices, regular security audits, and maintain compliance with SOC 2, GDPR, and other relevant standards."
            />
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-primary/20 to-blue-600/20 pointer-events-none" />
        <div className="absolute inset-0 bg-grid-pattern opacity-[0.03] pointer-events-none" />

        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-4xl mx-auto bg-card border rounded-2xl p-12 shadow-xl">
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold mb-4">Ready to Transform Your Business?</h2>
              <p className="text-xl text-muted-foreground">
                Join thousands of companies that trust SaaSify for their business needs
              </p>
            </div>

            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Button size="lg" className="rounded-full">
                Start Free Trial
              </Button>
              <Button size="lg" variant="outline" className="rounded-full">
                Schedule a Demo
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Chat Box */}
      <ChatBox />
    </main>
  )
}

// Helper Components
function PricingCard({
  title,
  price,
  description,
  features,
  buttonText,
  buttonVariant = "default",
  highlighted = false,
}) {
  return (
    <Card
      className={`border ${highlighted ? "border-primary shadow-lg ring-1 ring-primary" : "border-border"} h-full flex flex-col`}
    >
      <CardHeader>
        <CardTitle className="text-2xl">{title}</CardTitle>
        <CardDescription>{description}</CardDescription>
        <div className="mt-4">
          <span className="text-4xl font-bold">{price}</span>
          <span className="text-muted-foreground">/month</span>
        </div>
      </CardHeader>
      <CardContent className="flex-grow">
        <ul className="space-y-3">
          {features.map((feature, index) => (
            <li key={index} className="flex items-start">
              <Check className="h-5 w-5 text-primary mr-2 mt-0.5" />
              <span>{feature}</span>
            </li>
          ))}
        </ul>
      </CardContent>
      <CardFooter>
        <Button variant={buttonVariant} className="w-full">
          {buttonText}
        </Button>
      </CardFooter>
    </Card>
  )
}

function TestimonialCard({ quote, author, position, image }) {
  return (
    <Card className="bg-card border-none shadow-lg h-full">
      <CardContent className="pt-6">
        <div className="flex flex-col h-full">
          <div className="mb-6">
            <svg className="h-8 w-8 text-primary/40" fill="currentColor" viewBox="0 0 32 32" aria-hidden="true">
              <path d="M9.352 4C4.456 7.456 1 13.12 1 19.36c0 5.088 3.072 8.064 6.624 8.064 3.36 0 5.856-2.688 5.856-5.856 0-3.168-2.208-5.472-5.088-5.472-.576 0-1.344.096-1.536.192.48-3.264 3.552-7.104 6.624-9.024L9.352 4zm16.512 0c-4.8 3.456-8.256 9.12-8.256 15.36 0 5.088 3.072 8.064 6.624 8.064 3.264 0 5.856-2.688 5.856-5.856 0-3.168-2.304-5.472-5.184-5.472-.576 0-1.248.096-1.44.192.48-3.264 3.456-7.104 6.528-9.024L25.864 4z" />
            </svg>
          </div>
          <p className="text-lg mb-6 flex-1">{quote}</p>
          <div className="flex items-center">
            <Image
              src={image || "/placeholder.svg"}
              alt={author}
              width={40}
              height={40}
              className="rounded-full mr-4"
            />
            <div>
              <p className="font-medium">{author}</p>
              <p className="text-sm text-muted-foreground">{position}</p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

function FaqItem({ question, answer }) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg">{question}</CardTitle>
      </CardHeader>
      <CardContent>
        <p className="text-muted-foreground">{answer}</p>
      </CardContent>
    </Card>
  )
}

// Server component wrapper
export default function Home() {
  return <HomeContent />
}

