export default function PrivacyPolicyPage() {
  return (
    <div className="container py-12">
      <div className="max-w-3xl mx-auto">
        <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl mb-6">Privacy Policy</h1>

        <div className="prose dark:prose-invert max-w-none">
          <p className="lead">Last updated: March 6, 2025</p>

          <h2>1. Introduction</h2>
          <p>
            GG Data Group ("we", "our", or "us") is committed to protecting your privacy. This Privacy Policy explains
            how we collect, use, disclose, and safeguard your information when you visit our website or use our
            services.
          </p>

          <h2>2. Information We Collect</h2>
          <p>We may collect information about you in a variety of ways. The information we may collect includes:</p>
          <h3>2.1 Personal Data</h3>
          <p>
            Personally identifiable information, such as your name, email address, telephone number, and other similar
            information that you voluntarily provide to us when registering or using our services.
          </p>
          <h3>2.2 Derivative Data</h3>
          <p>
            Information our servers automatically collect when you access our website, such as your IP address, browser
            type, operating system, access times, and the pages you have viewed.
          </p>
          <h3>2.3 Financial Data</h3>
          <p>
            Financial information, such as data related to your payment method (e.g., valid credit card number, card
            brand, expiration date) that we may collect when you purchase our services.
          </p>

          <h2>3. Use of Your Information</h2>
          <p>
            Having accurate information about you permits us to provide you with a smooth, efficient, and customized
            experience. Specifically, we may use information collected about you via the website to:
          </p>
          <ul>
            <li>Create and manage your account</li>
            <li>Process payments and refunds</li>
            <li>Offer new products, services, and/or recommendations to you</li>
            <li>Increase the efficiency and operation of our website</li>
            <li>Monitor and analyze usage and trends to improve your experience with our website</li>
            <li>Notify you of updates to our website</li>
            <li>Resolve disputes and troubleshoot problems</li>
            <li>Prevent fraudulent transactions, monitor against theft, and protect against criminal activity</li>
          </ul>

          <h2>4. Disclosure of Your Information</h2>
          <p>
            We may share information we have collected about you in certain situations. Your information may be
            disclosed as follows:
          </p>
          <h3>4.1 By Law or to Protect Rights</h3>
          <p>
            If we believe the release of information about you is necessary to respond to legal process, to investigate
            or remedy potential violations of our policies, or to protect the rights, property, and safety of others, we
            may share your information as permitted or required by any applicable law, rule, or regulation.
          </p>
          <h3>4.2 Third-Party Service Providers</h3>
          <p>
            We may share your information with third parties that perform services for us or on our behalf, including
            payment processing, data analysis, email delivery, hosting services, customer service, and marketing
            assistance.
          </p>
          <h3>4.3 Marketing Communications</h3>
          <p>
            With your consent, or with an opportunity for you to withdraw consent, we may share your information with
            third parties for marketing purposes.
          </p>

          <h2>5. Security of Your Information</h2>
          <p>
            We use administrative, technical, and physical security measures to help protect your personal information.
            While we have taken reasonable steps to secure the personal information you provide to us, please be aware
            that despite our efforts, no security measures are perfect or impenetrable, and no method of data
            transmission can be guaranteed against any interception or other type of misuse.
          </p>

          <h2>6. Your Rights</h2>
          <p>You have certain rights regarding the personal information we collect about you:</p>
          <ul>
            <li>The right to access personal information we hold about you</li>
            <li>
              The right to request that we correct any personal information if it is found to be inaccurate or out of
              date
            </li>
            <li>
              The right to request that your personal information is erased where it is no longer necessary for us to
              retain such data
            </li>
            <li>The right to withdraw your consent to the processing at any time</li>
            <li>
              The right to request that we provide you with your personal information and, where possible, to transmit
              that data directly to another data controller
            </li>
            <li>
              The right, where there is a dispute in relation to the accuracy or processing of your personal data, to
              request a restriction is placed on further processing
            </li>
            <li>The right to object to the processing of personal data</li>
            <li>The right to lodge a complaint with a supervisory authority</li>
          </ul>

          <h2>7. Contact Us</h2>
          <p>If you have questions or comments about this Privacy Policy, please contact us at:</p>
          <p>
            GG Data Group
            <br />
            123 Business Ave, Suite 500
            <br />
            New York, NY 10001
            <br />
            Email: privacy@ggdatagroup.com
            <br />
            Phone: +1 (555) 123-4567
          </p>
        </div>
      </div>
    </div>
  )
}

