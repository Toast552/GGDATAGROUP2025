"use client"

import { useState, useEffect } from "react"

// Types for crypto data
export interface CryptoData {
  id: string
  symbol: string
  name: string
  image: string
  current_price: number
  market_cap: number
  market_cap_rank: number
  price_change_percentage_24h: number
  price_change_percentage_7d?: number
  total_volume: number
  lastUpdated: Date
}

// Function to fetch crypto data from CoinGecko
export async function fetchCryptoData(
  coins: string[] = ["bitcoin", "ethereum", "ripple", "cardano", "solana", "polkadot", "dogecoin"],
  currency = "usd",
): Promise<CryptoData[]> {
  try {
    const coinsString = coins.join(",")
    const url = `https://api.coingecko.com/api/v3/coins/markets?vs_currency=${currency}&ids=${coinsString}&order=market_cap_desc&per_page=${coins.length}&page=1&sparkline=false&price_change_percentage=24h,7d`

    const response = await fetch(url, {
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      next: { revalidate: 60 }, // Revalidate every 60 seconds
    })

    if (!response.ok) {
      throw new Error(`Failed to fetch crypto data: ${response.status}`)
    }

    const data = await response.json()

    return data.map((coin: any) => ({
      ...coin,
      lastUpdated: new Date(),
    }))
  } catch (error) {
    console.error("Error fetching crypto data:", error)
    // Return fallback data in case of error
    return coins.map((coin, index) => ({
      id: coin,
      symbol: coin.substring(0, 3).toUpperCase(),
      name: coin.charAt(0).toUpperCase() + coin.slice(1),
      image: `/placeholder.svg?height=32&width=32`,
      current_price: 0,
      market_cap: 0,
      market_cap_rank: index + 1,
      price_change_percentage_24h: 0,
      total_volume: 0,
      lastUpdated: new Date(),
    }))
  }
}

// Hook for real-time crypto data
export function useCryptoData(coins?: string[], currency = "usd", interval = 60000) {
  const [cryptoData, setCryptoData] = useState<CryptoData[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<Error | null>(null)

  useEffect(() => {
    let isMounted = true

    const fetchData = async () => {
      try {
        setLoading(true)
        const data = await fetchCryptoData(coins, currency)
        if (isMounted) {
          setCryptoData(data)
          setError(null)
        }
      } catch (err) {
        if (isMounted) {
          setError(err instanceof Error ? err : new Error("Unknown error"))
        }
      } finally {
        if (isMounted) {
          setLoading(false)
        }
      }
    }

    // Initial fetch
    fetchData()

    // Set up interval for real-time updates
    const intervalId = setInterval(fetchData, interval)

    // Cleanup
    return () => {
      isMounted = false
      clearInterval(intervalId)
    }
  }, [coins, currency, interval])

  return { cryptoData, loading, error }
}

// Function to get historical crypto data
export async function fetchCryptoHistoricalData(coinId: string, currency = "usd", days = 30) {
  try {
    const url = `https://api.coingecko.com/api/v3/coins/${coinId}/market_chart?vs_currency=${currency}&days=${days}`

    const response = await fetch(url, {
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      next: { revalidate: 3600 }, // Revalidate every hour
    })

    if (!response.ok) {
      throw new Error(`Failed to fetch historical data: ${response.status}`)
    }

    return await response.json()
  } catch (error) {
    console.error("Error fetching historical crypto data:", error)
    return { prices: [], market_caps: [], total_volumes: [] }
  }
}

