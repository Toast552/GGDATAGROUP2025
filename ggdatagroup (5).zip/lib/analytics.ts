/**
 * Analytics service for tracking website traffic and user behavior
 */

// Define analytics event types
export type AnalyticsEventType =
  | "page_view"
  | "user_engagement"
  | "form_submission"
  | "button_click"
  | "error"
  | "search"
  | "login"
  | "signup"
  | "logout"
  | "feature_usage"
  | "custom"

// Define analytics event interface
export interface AnalyticsEvent {
  type: AnalyticsEventType
  name: string
  properties?: Record<string, any>
  timestamp?: number
}

// Define user properties interface
export interface UserProperties {
  userId?: string
  userRole?: string
  userLanguage?: string
  userCountry?: string
  userDevice?: string
  userBrowser?: string
  userOS?: string
  [key: string]: any
}

class AnalyticsService {
  private initialized = false
  private userProperties: UserProperties = {}
  private debugMode = false

  /**
   * Initialize the analytics service
   * @param options Configuration options
   */
  public init(
    options: {
      googleAnalyticsId?: string
      debug?: boolean
      userProperties?: UserProperties
    } = {},
  ): void {
    if (this.initialized) {
      return
    }

    this.debugMode = options.debug || false

    if (options.userProperties) {
      this.userProperties = { ...this.userProperties, ...options.userProperties }
    }

    // Initialize Google Analytics if ID is provided
    if (options.googleAnalyticsId && typeof window !== "undefined") {
      this.initGoogleAnalytics(options.googleAnalyticsId)
    }

    // Detect and set basic user properties
    this.detectUserProperties()

    this.initialized = true
    this.debug("Analytics initialized", options)
  }

  /**
   * Initialize Google Analytics
   * @param measurementId Google Analytics measurement ID
   */
  private initGoogleAnalytics(measurementId: string): void {
    try {
      const script = document.createElement("script")
      script.async = true
      script.src = `https://www.googletagmanager.com/gtag/js?id=${measurementId}`
      document.head.appendChild(script)

      window.dataLayer = window.dataLayer || []
      function gtag(...args: any[]) {
        window.dataLayer.push(args)
      }
      // @ts-ignore
      window.gtag = gtag
      // @ts-ignore
      gtag("js", new Date())
      // @ts-ignore
      gtag("config", measurementId, {
        send_page_view: false, // We'll track page views manually
      })

      this.debug("Google Analytics initialized", { measurementId })
    } catch (error) {
      console.error("Failed to initialize Google Analytics:", error)
    }
  }

  /**
   * Detect and set basic user properties
   */
  private detectUserProperties(): void {
    if (typeof window === "undefined") {
      return
    }

    try {
      const userAgent = navigator.userAgent
      const language = navigator.language

      // Detect browser
      let browser = "Unknown"
      if (userAgent.indexOf("Chrome") > -1) browser = "Chrome"
      else if (userAgent.indexOf("Safari") > -1) browser = "Safari"
      else if (userAgent.indexOf("Firefox") > -1) browser = "Firefox"
      else if (userAgent.indexOf("MSIE") > -1 || userAgent.indexOf("Trident") > -1) browser = "Internet Explorer"
      else if (userAgent.indexOf("Edge") > -1) browser = "Edge"

      // Detect OS
      let os = "Unknown"
      if (userAgent.indexOf("Windows") > -1) os = "Windows"
      else if (userAgent.indexOf("Mac") > -1) os = "MacOS"
      else if (userAgent.indexOf("Linux") > -1) os = "Linux"
      else if (userAgent.indexOf("Android") > -1) os = "Android"
      else if (userAgent.indexOf("iOS") > -1 || userAgent.indexOf("iPhone") > -1 || userAgent.indexOf("iPad") > -1)
        os = "iOS"

      // Detect device type
      let device = "Desktop"
      if (userAgent.indexOf("Mobile") > -1) device = "Mobile"
      else if (userAgent.indexOf("Tablet") > -1 || userAgent.indexOf("iPad") > -1) device = "Tablet"

      this.userProperties = {
        ...this.userProperties,
        userLanguage: language,
        userBrowser: browser,
        userOS: os,
        userDevice: device,
      }

      this.debug("User properties detected", this.userProperties)
    } catch (error) {
      console.error("Failed to detect user properties:", error)
    }
  }

  /**
   * Track a page view
   * @param path The page path
   * @param title The page title
   * @param properties Additional properties
   */
  public trackPageView(path: string, title?: string, properties?: Record<string, any>): void {
    if (!this.initialized) {
      this.init()
    }

    const event: AnalyticsEvent = {
      type: "page_view",
      name: "page_view",
      properties: {
        path,
        title: title || document.title,
        referrer: document.referrer,
        ...properties,
      },
      timestamp: Date.now(),
    }

    this.trackEvent(event)
  }

  /**
   * Track a custom event
   * @param event The event to track
   */
  public trackEvent(event: AnalyticsEvent): void {
    if (!this.initialized) {
      this.init()
    }

    // Add timestamp if not provided
    if (!event.timestamp) {
      event.timestamp = Date.now()
    }

    // Add user properties
    const eventWithUser = {
      ...event,
      properties: {
        ...this.userProperties,
        ...event.properties,
      },
    }

    this.debug("Tracking event", eventWithUser)

    // Send to Google Analytics if available
    this.sendToGoogleAnalytics(eventWithUser)

    // In a real application, you might send this to your own analytics backend
    // this.sendToBackend(eventWithUser);
  }

  /**
   * Send event to Google Analytics
   * @param event The event to send
   */
  private sendToGoogleAnalytics(event: AnalyticsEvent): void {
    if (typeof window === "undefined" || !window.gtag) {
      return
    }

    try {
      if (event.type === "page_view") {
        // @ts-ignore
        window.gtag("event", "page_view", {
          page_title: event.properties?.title,
          page_location: window.location.href,
          page_path: event.properties?.path,
          send_to: window.GA_MEASUREMENT_ID,
        })
      } else {
        // @ts-ignore
        window.gtag("event", event.name, {
          event_category: event.type,
          ...event.properties,
        })
      }
    } catch (error) {
      console.error("Failed to send event to Google Analytics:", error)
    }
  }

  /**
   * Set user ID for tracking
   * @param userId The user ID
   */
  public setUserId(userId: string): void {
    this.userProperties.userId = userId

    if (typeof window !== "undefined" && window.gtag) {
      try {
        // @ts-ignore
        window.gtag("set", { user_id: userId })
      } catch (error) {
        console.error("Failed to set user ID in Google Analytics:", error)
      }
    }

    this.debug("User ID set", { userId })
  }

  /**
   * Set user properties
   * @param properties User properties to set
   */
  public setUserProperties(properties: UserProperties): void {
    this.userProperties = { ...this.userProperties, ...properties }
    this.debug("User properties updated", this.userProperties)
  }

  /**
   * Log debug message if debug mode is enabled
   * @param message Debug message
   * @param data Additional data
   */
  private debug(message: string, data?: any): void {
    if (this.debugMode) {
      console.log(`[Analytics] ${message}`, data)
    }
  }
}

// Create singleton instance
export const analytics = new AnalyticsService()

// For TypeScript global window augmentation
declare global {
  interface Window {
    dataLayer: any[]
    gtag: (...args: any[]) => void
    GA_MEASUREMENT_ID?: string
  }
}

