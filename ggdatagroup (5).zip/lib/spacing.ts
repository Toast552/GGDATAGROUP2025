/**
 * Spacing utility for consistent padding and margins throughout the application
 */

// Define spacing scale
export const spacing = {
  0: "0",
  0.5: "0.125rem", // 2px
  1: "0.25rem", // 4px
  1.5: "0.375rem", // 6px
  2: "0.5rem", // 8px
  2.5: "0.625rem", // 10px
  3: "0.75rem", // 12px
  3.5: "0.875rem", // 14px
  4: "1rem", // 16px
  5: "1.25rem", // 20px
  6: "1.5rem", // 24px
  7: "1.75rem", // 28px
  8: "2rem", // 32px
  9: "2.25rem", // 36px
  10: "2.5rem", // 40px
  11: "2.75rem", // 44px
  12: "3rem", // 48px
  14: "3.5rem", // 56px
  16: "4rem", // 64px
  20: "5rem", // 80px
  24: "6rem", // 96px
  28: "7rem", // 112px
  32: "8rem", // 128px
  36: "9rem", // 144px
  40: "10rem", // 160px
  44: "11rem", // 176px
  48: "12rem", // 192px
  52: "13rem", // 208px
  56: "14rem", // 224px
  60: "15rem", // 240px
  64: "16rem", // 256px
  72: "18rem", // 288px
  80: "20rem", // 320px
  96: "24rem", // 384px
}

// Define spacing for different screen sizes
export const screenSizes = {
  sm: "640px",
  md: "768px",
  lg: "1024px",
  xl: "1280px",
  "2xl": "1536px",
}

// Helper function to generate responsive padding classes
export function getPadding(
  size: keyof typeof spacing,
  options?: {
    x?: boolean
    y?: boolean
    top?: boolean
    right?: boolean
    bottom?: boolean
    left?: boolean
    responsive?: boolean
  },
): string {
  const { x, y, top, right, bottom, left, responsive } = options || {}

  let classes = []

  if (x) classes.push(`px-${size}`)
  if (y) classes.push(`py-${size}`)
  if (top) classes.push(`pt-${size}`)
  if (right) classes.push(`pr-${size}`)
  if (bottom) classes.push(`pb-${size}`)
  if (left) classes.push(`pl-${size}`)
  if (!x && !y && !top && !right && !bottom && !left) classes.push(`p-${size}`)

  // Add responsive variants if requested
  if (responsive) {
    const responsiveClasses = []

    if (x) {
      responsiveClasses.push(`sm:px-${Math.min(Number(size) * 1.5, 96)}`)
      responsiveClasses.push(`md:px-${Math.min(Number(size) * 2, 96)}`)
      responsiveClasses.push(`lg:px-${Math.min(Number(size) * 2.5, 96)}`)
    }

    if (y) {
      responsiveClasses.push(`sm:py-${Math.min(Number(size) * 1.5, 96)}`)
      responsiveClasses.push(`md:py-${Math.min(Number(size) * 2, 96)}`)
      responsiveClasses.push(`lg:py-${Math.min(Number(size) * 2.5, 96)}`)
    }

    if (!x && !y && !top && !right && !bottom && !left) {
      responsiveClasses.push(`sm:p-${Math.min(Number(size) * 1.5, 96)}`)
      responsiveClasses.push(`md:p-${Math.min(Number(size) * 2, 96)}`)
      responsiveClasses.push(`lg:p-${Math.min(Number(size) * 2.5, 96)}`)
    }

    classes = [...classes, ...responsiveClasses]
  }

  return classes.join(" ")
}

// Helper function to generate responsive margin classes
export function getMargin(
  size: keyof typeof spacing,
  options?: {
    x?: boolean
    y?: boolean
    top?: boolean
    right?: boolean
    bottom?: boolean
    left?: boolean
    responsive?: boolean
  },
): string {
  const { x, y, top, right, bottom, left, responsive } = options || {}

  let classes = []

  if (x) classes.push(`mx-${size}`)
  if (y) classes.push(`my-${size}`)
  if (top) classes.push(`mt-${size}`)
  if (right) classes.push(`mr-${size}`)
  if (bottom) classes.push(`mb-${size}`)
  if (left) classes.push(`ml-${size}`)
  if (!x && !y && !top && !right && !bottom && !left) classes.push(`m-${size}`)

  // Add responsive variants if requested
  if (responsive) {
    const responsiveClasses = []

    if (x) {
      responsiveClasses.push(`sm:mx-${Math.min(Number(size) * 1.5, 96)}`)
      responsiveClasses.push(`md:mx-${Math.min(Number(size) * 2, 96)}`)
      responsiveClasses.push(`lg:mx-${Math.min(Number(size) * 2.5, 96)}`)
    }

    if (y) {
      responsiveClasses.push(`sm:my-${Math.min(Number(size) * 1.5, 96)}`)
      responsiveClasses.push(`md:my-${Math.min(Number(size) * 2, 96)}`)
      responsiveClasses.push(`lg:my-${Math.min(Number(size) * 2.5, 96)}`)
    }

    if (!x && !y && !top && !right && !bottom && !left) {
      responsiveClasses.push(`sm:m-${Math.min(Number(size) * 1.5, 96)}`)
      responsiveClasses.push(`md:m-${Math.min(Number(size) * 2, 96)}`)
      responsiveClasses.push(`lg:m-${Math.min(Number(size) * 2.5, 96)}`)
    }

    classes = [...classes, ...responsiveClasses]
  }

  return classes.join(" ")
}

// Helper function to generate container padding
export function getContainerPadding(size: keyof typeof spacing = 4): string {
  return `px-${size} sm:px-${Math.min(Number(size) * 1.5, 96)} md:px-${Math.min(Number(size) * 2, 96)} lg:px-${Math.min(Number(size) * 2.5, 96)}`
}

// Helper function to generate section padding
export function getSectionPadding(size: keyof typeof spacing = 8): string {
  return `py-${size} sm:py-${Math.min(Number(size) * 1.5, 96)} md:py-${Math.min(Number(size) * 2, 96)} lg:py-${Math.min(Number(size) * 2.5, 96)}`
}

