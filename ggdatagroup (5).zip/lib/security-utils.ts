import { createHash } from "crypto"

/**
 * Sanitizes user input to prevent XSS attacks
 * @param input The user input to sanitize
 * @returns Sanitized string
 */
export function sanitizeInput(input: string): string {
  if (!input) return ""

  // Replace HTML special characters with their entity equivalents
  return input
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;")
}

/**
 * Generates a CSRF token
 * @param secret Server secret for token generation
 * @param sessionId Unique session identifier
 * @returns CSRF token
 */
export function generateCsrfToken(secret: string, sessionId: string): string {
  const timestamp = Date.now().toString()
  const hash = createHash("sha256").update(`${secret}:${sessionId}:${timestamp}`).digest("hex")

  return `${timestamp}:${hash}`
}

/**
 * Validates a CSRF token
 * @param token The token to validate
 * @param secret Server secret used for token generation
 * @param sessionId Unique session identifier
 * @param maxAge Maximum age of token in milliseconds (default: 1 hour)
 * @returns Whether the token is valid
 */
export function validateCsrfToken(token: string, secret: string, sessionId: string, maxAge = 3600000): boolean {
  const [timestamp, hash] = token.split(":")

  if (!timestamp || !hash) return false

  // Check if token has expired
  const tokenTime = Number.parseInt(timestamp, 10)
  const now = Date.now()

  if (isNaN(tokenTime) || now - tokenTime > maxAge) return false

  // Verify hash
  const expectedHash = createHash("sha256").update(`${secret}:${sessionId}:${timestamp}`).digest("hex")

  return hash === expectedHash
}

/**
 * Rate limiting utility
 */
export class RateLimiter {
  private attempts: Map<string, { count: number; resetTime: number }>
  private maxAttempts: number
  private windowMs: number

  constructor(maxAttempts = 5, windowMs = 60000) {
    this.attempts = new Map()
    this.maxAttempts = maxAttempts
    this.windowMs = windowMs
  }

  /**
   * Check if a key has exceeded the rate limit
   * @param key Identifier for the rate limit (e.g., IP address)
   * @returns Whether the request should be limited
   */
  isRateLimited(key: string): boolean {
    const now = Date.now()
    const record = this.attempts.get(key)

    // If no record exists or the window has expired, create a new record
    if (!record || now > record.resetTime) {
      this.attempts.set(key, {
        count: 1,
        resetTime: now + this.windowMs,
      })
      return false
    }

    // Increment the count
    record.count++

    // Check if the count exceeds the maximum
    return record.count > this.maxAttempts
  }

  /**
   * Get remaining attempts for a key
   * @param key Identifier for the rate limit
   * @returns Number of attempts remaining
   */
  getRemainingAttempts(key: string): number {
    const record = this.attempts.get(key)
    if (!record) return this.maxAttempts

    return Math.max(0, this.maxAttempts - record.count)
  }

  /**
   * Reset rate limit for a key
   * @param key Identifier to reset
   */
  reset(key: string): void {
    this.attempts.delete(key)
  }
}

