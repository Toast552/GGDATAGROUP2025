/**
 * CSRF Protection Utilities
 */

// Generate a CSRF token
export function generateCSRFToken(): string {
  return Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15)
}

// Store CSRF token in session storage
export function storeCSRFToken(token: string): void {
  try {
    sessionStorage.setItem("csrf_token", token)
  } catch (error) {
    console.error("Error storing CSRF token:", error)
  }
}

// Retrieve CSRF token from session storage
export function getCSRFToken(): string | null {
  try {
    return sessionStorage.getItem("csrf_token")
  } catch (error) {
    console.error("Error retrieving CSRF token:", error)
    return null
  }
}

// Validate CSRF token
export function validateCSRFToken(token: string): boolean {
  const storedToken = getCSRFToken()
  return storedToken === token
}

// Initialize CSRF protection
export function initCSRFProtection(): string {
  const token = generateCSRFToken()
  storeCSRFToken(token)
  return token
}

// Add CSRF token to form data
export function addCSRFToFormData(formData: FormData): FormData {
  const token = getCSRFToken()
  if (token) {
    formData.append("csrf_token", token)
  }
  return formData
}

// Add CSRF token to request headers
export function addCSRFToHeaders(headers: Headers): Headers {
  const token = getCSRFToken()
  if (token) {
    headers.append("X-CSRF-Token", token)
  }
  return headers
}

