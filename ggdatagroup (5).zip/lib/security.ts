/**
 * Security utility functions for input sanitization and validation
 */

/**
 * Sanitizes user input to prevent XSS attacks
 * @param input The user input to sanitize
 * @returns Sanitized input string
 */
export function sanitizeInput(input: string | null | undefined): string {
  if (input === null || input === undefined) {
    return ""
  }

  // Convert to string if not already
  const str = String(input)

  // Replace HTML special characters with their entity equivalents
  return str
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;")
    .trim()
}

/**
 * Basic anomaly detection to prevent malicious input
 * @param input The user input to check
 * @returns An object indicating if an anomaly was detected and the reason
 */
export function detectAnomaly(input: string): { isAnomaly: boolean; reason?: string } {
  const lowerCaseInput = input.toLowerCase()

  if (lowerCaseInput.includes("<script>") || lowerCaseInput.includes("javascript:")) {
    return { isAnomaly: true, reason: "Potential XSS attack" }
  }

  if (lowerCaseInput.includes("union select") || lowerCaseInput.includes("drop table")) {
    return { isAnomaly: true, reason: "Potential SQL injection" }
  }

  // Add more checks as needed
  return { isAnomaly: false }
}

/**
 * Basic rate limiting mechanism
 * @param key Unique key for the action being rate limited (e.g., IP address + action)
 * @param limit Maximum number of allowed actions within the time window
 * @param windowMs Time window in milliseconds
 * @returns Boolean indicating if the rate limit has been exceeded
 */
const rateLimitStore: { [key: string]: number[] } = {}

export function checkRateLimit(key: string, limit: number, windowMs: number): boolean {
  const now = Date.now()

  // Initialize the key if it doesn't exist
  if (!rateLimitStore[key]) {
    rateLimitStore[key] = []
  }

  // Clean up older entries
  rateLimitStore[key] = rateLimitStore[key].filter((timestamp) => now - timestamp < windowMs)

  // Check if the limit is exceeded
  if (rateLimitStore[key].length >= limit) {
    return true
  }

  // Add the current timestamp
  rateLimitStore[key].push(now)
  return false
}

/**
 * Logs security-related events
 * @param event Object containing event details
 */
export function logSecurityEvent(event: { type: string; message: string; data?: Record<string, any> }): void {
  console.warn(`SECURITY EVENT: ${event.type} - ${event.message}`, event.data)
  // In a real application, you would send this to a security logging service
}

/**
 * Sanitizes and validates form data
 * @param formData The form data to sanitize and validate
 * @returns Object with sanitized values and validation errors
 */
export function sanitizeFormData(formData: Record<string, string>): {
  sanitized: Record<string, string>
  errors: Record<string, string>
} {
  const sanitized: Record<string, string> = {}
  const errors: Record<string, string> = {}

  for (const [key, value] of Object.entries(formData)) {
    // Sanitize all inputs
    sanitized[key] = sanitizeInput(value)

    // Validate required fields
    if (value.trim() === "" && key !== "message" && key !== "address") {
      errors[key] = `${key.charAt(0).toUpperCase() + key.slice(1)} is required`
    }

    // Validate email
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (key === "email" && value.trim() !== "" && !emailRegex.test(value)) {
      errors[key] = "Please enter a valid email address"
    }
  }

  return { sanitized, errors }
}

