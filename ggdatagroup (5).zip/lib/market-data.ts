"use client"

import { useState, useEffect } from "react"

// Types for market data
export interface MarketData {
  symbol: string
  price: number
  change: number
  changePercent: number
  volume: number
  marketCap?: number
  lastUpdated: Date
}

// Function to fetch market data from Yahoo Finance
export async function fetchMarketData(symbols: string[]): Promise<MarketData[]> {
  try {
    // Yahoo Finance API endpoint
    const symbolsString = symbols.join(",")
    const url = `https://query1.finance.yahoo.com/v7/finance/quote?symbols=${symbolsString}`

    const response = await fetch(url, {
      headers: {
        "Content-Type": "application/json",
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
      },
      next: { revalidate: 60 }, // Revalidate every 60 seconds
    })

    if (!response.ok) {
      throw new Error(`Failed to fetch market data: ${response.status}`)
    }

    const data = await response.json()

    if (!data.quoteResponse || !data.quoteResponse.result) {
      throw new Error("Invalid response format from Yahoo Finance")
    }

    return data.quoteResponse.result.map((quote: any) => ({
      symbol: quote.symbol,
      price: quote.regularMarketPrice,
      change: quote.regularMarketChange,
      changePercent: quote.regularMarketChangePercent,
      volume: quote.regularMarketVolume,
      marketCap: quote.marketCap,
      lastUpdated: new Date(),
    }))
  } catch (error) {
    console.error("Error fetching market data:", error)
    // Return fallback data in case of error
    return symbols.map((symbol) => ({
      symbol,
      price: 0,
      change: 0,
      changePercent: 0,
      volume: 0,
      lastUpdated: new Date(),
    }))
  }
}

// Hook for real-time market data
export function useMarketData(symbols: string[], interval = 60000) {
  const [marketData, setMarketData] = useState<MarketData[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<Error | null>(null)

  useEffect(() => {
    let isMounted = true

    const fetchData = async () => {
      try {
        setLoading(true)
        const data = await fetchMarketData(symbols)
        if (isMounted) {
          setMarketData(data)
          setError(null)
        }
      } catch (err) {
        if (isMounted) {
          setError(err instanceof Error ? err : new Error("Unknown error"))
        }
      } finally {
        if (isMounted) {
          setLoading(false)
        }
      }
    }

    // Initial fetch
    fetchData()

    // Set up interval for real-time updates
    const intervalId = setInterval(fetchData, interval)

    // Cleanup
    return () => {
      isMounted = false
      clearInterval(intervalId)
    }
  }, [symbols, interval])

  return { marketData, loading, error }
}

// Function to fetch Barron's headlines
export async function fetchBarronsHeadlines(): Promise<{ title: string; url: string; date: string }[]> {
  try {
    // This would typically use Barron's API, but for demo purposes we'll return mock data
    // In a real implementation, you would need to use their official API or implement a server-side scraper
    return [
      {
        title: "Market Rally Continues as Tech Stocks Lead Gains",
        url: "https://www.barrons.com/articles/market-rally-tech-stocks-lead-gains",
        date: new Date().toISOString(),
      },
      {
        title: "Federal Reserve Signals Potential Rate Cut in Coming Months",
        url: "https://www.barrons.com/articles/federal-reserve-rate-cut-signals",
        date: new Date().toISOString(),
      },
      {
        title: "Earnings Season Kicks Off with Strong Bank Results",
        url: "https://www.barrons.com/articles/earnings-season-bank-results",
        date: new Date().toISOString(),
      },
      {
        title: "Oil Prices Stabilize After Recent Volatility",
        url: "https://www.barrons.com/articles/oil-prices-stabilize-volatility",
        date: new Date().toISOString(),
      },
      {
        title: "Retail Sales Data Shows Consumer Resilience",
        url: "https://www.barrons.com/articles/retail-sales-consumer-resilience",
        date: new Date().toISOString(),
      },
    ]
  } catch (error) {
    console.error("Error fetching Barrons headlines:", error)
    return []
  }
}

