type LogLevel = "info" | "warn" | "error" | "debug"

interface LogEntry {
  timestamp: string
  level: LogLevel
  message: string
  data?: any
}

class Logger {
  private logs: LogEntry[] = []
  private maxLogs = 100
  private debugMode: boolean

  constructor() {
    this.debugMode = process.env.DEBUG_MODE === "true"
  }

  private createLogEntry(level: LogLevel, message: string, data?: any): LogEntry {
    return {
      timestamp: new Date().toISOString(),
      level,
      message,
      data,
    }
  }

  private addLog(entry: LogEntry): void {
    this.logs.push(entry)

    // Trim logs if they exceed the maximum
    if (this.logs.length > this.maxLogs) {
      this.logs = this.logs.slice(-this.maxLogs)
    }

    // Log to console
    const consoleMethod =
      entry.level === "error"
        ? console.error
        : entry.level === "warn"
          ? console.warn
          : entry.level === "debug"
            ? console.debug
            : console.log

    if (entry.data) {
      consoleMethod(`[${entry.level.toUpperCase()}] ${entry.message}`, entry.data)
    } else {
      consoleMethod(`[${entry.level.toUpperCase()}] ${entry.message}`)
    }

    // In a real app, you might send logs to a service like Sentry, LogRocket, etc.
    this.sendToAnalyticsService(entry)
  }

  private sendToAnalyticsService(entry: LogEntry): void {
    // Only send errors and warnings to analytics in production
    if (process.env.NODE_ENV === "production" && (entry.level === "error" || entry.level === "warn")) {
      // This would be an API call to your logging service
      // Example: Sentry.captureException(entry.data)
    }
  }

  info(message: string, data?: any): void {
    this.addLog(this.createLogEntry("info", message, data))
  }

  warn(message: string, data?: any): void {
    this.addLog(this.createLogEntry("warn", message, data))
  }

  error(message: string, data?: any): void {
    this.addLog(this.createLogEntry("error", message, data))
  }

  debug(message: string, data?: any): void {
    if (this.debugMode) {
      this.addLog(this.createLogEntry("debug", message, data))
    }
  }

  getLogs(): LogEntry[] {
    return [...this.logs]
  }

  clearLogs(): void {
    this.logs = []
  }
}

export const logger = new Logger()

